/*
Local Vault Agent — https://github.com/TonyPeonio/obsidian-local-vault-agent
This is a bundled build. The source is in the repository above.
*/

"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => LocalVaultAgentPlugin
});
module.exports = __toCommonJS(main_exports);

// src/dna-server.ts
var import_obsidian = require("obsidian");

// src/i18n-ko.ts
var ko = {
  "set.ui.name": "\uD654\uBA74 \uC5B8\uC5B4",
  "set.ui.desc": "\uD50C\uB7EC\uADF8\uC778\uC744 \uB2E4\uC2DC \uB85C\uB4DC\uD558\uBA74 \uBCC0\uACBD\uD55C \uC5B8\uC5B4\uAC00 \uC801\uC6A9\uB429\uB2C8\uB2E4.",
  "set.h.server": "\uBAA8\uB378 \uC11C\uBC84",
  "set.h.search": "\uAC80\uC0C9",
  "set.h.agent": "\uC5D0\uC774\uC804\uD2B8",
  "set.h.study": "\uD559\uC2B5",
  "set.h.schedule": "\uC608\uC57D \uC791\uC5C5",
  "set.h.help": "\uB3C4\uC6C0\uB9D0 \uBC0F \uC758\uACAC",
  "set.provider.name": "\uACF5\uAE09\uC790",
  "set.provider.desc": "\uC774 PC\uC5D0\uC11C \uC2E4\uD589 \uC911\uC778 Ollama \uB610\uB294 OpenAI \uD638\uD658 \uC11C\uBC84\uB97C \uC120\uD0DD\uD569\uB2C8\uB2E4.",
  "set.provider.ollama": "Ollama",
  "set.provider.openai": "OpenAI \uD638\uD658 (LM Studio, llama.cpp, Jan, vLLM)",
  "set.url.name": "Ollama \uC8FC\uC18C",
  "set.url.desc": "Ollama\uAC00 \uC694\uCCAD\uC744 \uBC1B\uB294 \uC8FC\uC18C\uC785\uB2C8\uB2E4.",
  "set.oaUrl.name": "\uC11C\uBC84 \uC8FC\uC18C",
  "set.oaUrl.desc": "/v1\uB85C \uB05D\uB098\uB294 OpenAI \uD638\uD658 API \uC8FC\uC18C\uC785\uB2C8\uB2E4. \uC774 \uAD6C\uC131\uC758 DNA \uC11C\uBC84\uB294 http://127.0.0.1:18081/v1\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4.",
  "set.oaKey.name": "API \uD0A4",
  "set.oaKey.desc": "\uB85C\uCEEC \uC11C\uBC84\uC5D0\uC11C \uC694\uAD6C\uD560 \uB54C\uB9CC \uC785\uB825\uD569\uB2C8\uB2E4. \uD0A4\uB294 \uD574\uB2F9 \uC11C\uBC84\uB85C\uB9CC \uC804\uC1A1\uB418\uBA70 \uBB38\uC81C \uBCF4\uACE0\uC5D0 \uD3EC\uD568\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  "set.test.button": "\uC5F0\uACB0 \uBC0F \uC18D\uB3C4 \uD14C\uC2A4\uD2B8",
  "set.lc.name": "Lecture Companion\uC758 Ollama \uC124\uC815 \uC0AC\uC6A9",
  "set.lc.desc": "Lecture Companion\uC774 {url}\uC5D0\uC11C {model}\uC744 \uC0AC\uC6A9\uD558\uACE0 \uC788\uC2B5\uB2C8\uB2E4. \uC774 \uC124\uC815\uC744 \uBCF5\uC0AC\uD558\uBA74 \uD55C \uC11C\uBC84\uC640 \uBAA8\uB378\uC744 \uACF5\uC720\uD569\uB2C8\uB2E4.",
  "set.model.name": "\uCC44\uD305 \uBAA8\uB378",
  "set.model.desc": "\uB3C4\uAD6C \uD638\uCD9C\uC744 \uC9C0\uC6D0\uD558\uB294 \uBAA8\uB378\uC744 \uC120\uD0DD\uD569\uB2C8\uB2E4. \uC774 \uAD6C\uC131\uC758 \uAE30\uBCF8 \uBAA8\uB378\uC740 DNA3.0-9B\uC785\uB2C8\uB2E4.",
  "set.model.placeholder": "\uB610\uB294 \uBAA8\uB378 \uC774\uB984 \uC785\uB825",
  "set.ctx.name": "\uCEE8\uD14D\uC2A4\uD2B8 \uD06C\uAE30 (num_ctx)",
  "set.ctx.desc": "\uBAA8\uB378\uC774 \uD55C \uBC88\uC5D0 \uCC98\uB9AC\uD560 \uC218 \uC788\uB294 \uD1A0\uD070 \uC218\uC785\uB2C8\uB2E4. OpenAI \uD638\uD658 \uC11C\uBC84\uB294 \uBAA8\uB378\uC744 \uB85C\uB529\uD560 \uB54C \uC11C\uBC84\uC5D0\uC11C \uC124\uC815\uD569\uB2C8\uB2E4.",
  "set.temp.name": "\uC0DD\uC131 \uC628\uB3C4",
  "set.temp.desc": "\uAC12\uC774 \uB192\uC744\uC218\uB85D \uC751\uB2F5\uC758 \uD45C\uD604\uACFC \uC120\uD0DD\uC774 \uB2E4\uC591\uD574\uC9D1\uB2C8\uB2E4. \uC774 \uAD6C\uC131\uC758 \uAE30\uBCF8\uAC12\uC740 0.2\uC785\uB2C8\uB2E4.",
  "set.think.name": "\uCD94\uB860 \uBAA8\uB4DC",
  "set.think.desc": "\uCD94\uB860 \uBAA8\uB4DC\uB97C \uC9C0\uC6D0\uD558\uB294 \uBAA8\uB378\uC5D0 \uC801\uC6A9\uB429\uB2C8\uB2E4. \uC790\uB3D9\uC740 \uBAA8\uB378 \uAE30\uBCF8 \uC124\uC815\uC744 \uB530\uB985\uB2C8\uB2E4.",
  "set.think.auto": "\uC790\uB3D9",
  "set.think.on": "\uCF1C\uAE30",
  "set.think.off": "\uB044\uAE30",
  "set.showThinking.name": "\uCC44\uD305\uC5D0 \uCD94\uB860 \uACFC\uC815 \uD45C\uC2DC",
  "set.keepAlive.name": "\uBAA8\uB378 \uC720\uC9C0 \uC2DC\uAC04",
  "set.keepAlive.desc": "Ollama\uAC00 \uC694\uCCAD \uC774\uD6C4 \uBAA8\uB378\uC744 \uBA54\uBAA8\uB9AC\uC5D0 \uC720\uC9C0\uD558\uB294 \uC2DC\uAC04\uC785\uB2C8\uB2E4. \uC608\uB97C \uB4E4\uC5B4 10m\uC740 10\uBD84\uC774\uACE0 -1\uC740 \uACC4\uC18D \uC720\uC9C0\uC785\uB2C8\uB2E4.",
  "set.vision.name": "\uC774\uBBF8\uC9C0 \uD310\uB3C5 \uBAA8\uB378",
  "set.vision.desc": "\uB178\uD2B8\uC5D0 \uCCA8\uBD80\uB41C \uC774\uBBF8\uC9C0\uC640 \uC2A4\uCE94\uB41C PDF \uD398\uC774\uC9C0\uB97C \uC77D\uC2B5\uB2C8\uB2E4. \uBE44\uC6CC \uB450\uBA74 \uC774\uBBF8\uC9C0 \uC785\uB825\uC744 \uC9C0\uC6D0\uD558\uB294 \uCC44\uD305 \uBAA8\uB378\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4.",
  "set.vision.placeholder": "(\uCC44\uD305 \uBAA8\uB378)",
  "set.vision.check": "\uD655\uC778",
  "set.lang.name": "\uB2F5\uBCC0 \uC5B8\uC5B4",
  "set.lang.desc": "\uB2F5\uBCC0\uC5D0 \uC0AC\uC6A9\uD560 \uC5B8\uC5B4\uB97C \uC785\uB825\uD569\uB2C8\uB2E4. \uBE44\uC6CC \uB450\uBA74 \uC9C8\uBB38\uACFC \uAC19\uC740 \uC5B8\uC5B4\uB85C \uB2F5\uD569\uB2C8\uB2E4.",
  "set.lang.placeholder": "(\uC9C8\uBB38\uC758 \uC5B8\uC5B4)",
  "set.semantic.name": "\uC758\uBBF8 \uAC80\uC0C9",
  "set.semantic.desc": "\uB85C\uCEEC \uC784\uBCA0\uB529 \uBAA8\uB378\uC744 \uC0AC\uC6A9\uD574 \uC758\uBBF8\uAC00 \uBE44\uC2B7\uD55C \uBB38\uC11C\uB97C \uCC3E\uC2B5\uB2C8\uB2E4. \uD0A4\uC6CC\uB4DC \uAC80\uC0C9\uC740 \uACC4\uC18D \uC0AC\uC6A9\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
  "set.embed.name": "\uC784\uBCA0\uB529 \uBAA8\uB378",
  "set.embed.desc": "\uBAA8\uB378\uC744 \uBCC0\uACBD\uD558\uBA74 \uC0C9\uC778\uC744 \uB2E4\uC2DC \uB9CC\uB4ED\uB2C8\uB2E4.",
  "set.index.name": "\uC0C9\uC778",
  "set.index.building": "\uC0C9\uC778 \uC0DD\uC131 \uC911\u2026 \uC644\uB8CC {done}\uAC1C, \uB300\uAE30 {pending}\uAC1C",
  "set.index.error": "\uC624\uB958 \xB7 {error}",
  "set.index.ready": "\uB178\uD2B8 {notes}\uAC1C, \uBB38\uB2E8 {chunks}\uAC1C \uC0C9\uC778 \uC644\uB8CC",
  "set.index.update": "\uAC31\uC2E0",
  "set.index.rebuild": "\uB2E4\uC2DC \uB9CC\uB4E4\uAE30",
  "set.excluded.name": "\uC81C\uC678 \uD3F4\uB354",
  "set.excluded.desc": "\uD55C \uC904\uC5D0 \uD55C \uD3F4\uB354\uB97C \uC785\uB825\uD569\uB2C8\uB2E4. \uC81C\uC678 \uD3F4\uB354\uB294 \uAC80\uC0C9, \uC0C9\uC778, \uD3B8\uC9D1 \uB300\uC0C1\uC5D0\uC11C \uBE60\uC9D1\uB2C8\uB2E4.",
  "set.gists.name": "\uB178\uD2B8 \uD55C \uC904 \uC694\uC57D",
  "set.gists.desc": "Vault \uAD6C\uC870\uB97C \uBAA8\uB378\uC5D0 \uC54C\uB824 \uC8FC\uB294 \uD55C \uC904 \uC694\uC57D\uC744 \uBC31\uADF8\uB77C\uC6B4\uB4DC\uC5D0\uC11C \uC0DD\uC131\uD569\uB2C8\uB2E4. \uCC44\uD305 \uC911\uC5D0\uB294 \uC77C\uC2DC \uC911\uC9C0\uB429\uB2C8\uB2E4.",
  "set.gists.rebuild": "\uB2E4\uC2DC \uB9CC\uB4E4\uAE30",
  "set.autoApprove.name": "\uC218\uC815 \uC790\uB3D9 \uC2B9\uC778",
  "set.autoApprove.desc": "\uCF1C\uBA74 \uBCC0\uACBD\uC0AC\uD56D \uBE44\uAD50\uC640 \uC2B9\uC778 \uCC3D\uC744 \uAC74\uB108\uB701\uB2C8\uB2E4. \uCC44\uD305\uC5D0\uC11C\uB9CC \uBAA8\uB450 \uC2B9\uC778\uD558\uB3C4\uB85D \uC120\uD0DD\uD560 \uC218\uB3C4 \uC788\uC2B5\uB2C8\uB2E4.",
  "set.autoContinue.name": "\uBAA8\uB378\uC774 \uC9C4\uD589 \uC5EC\uBD80\uB97C \uBB3B\uB294 \uACBD\uC6B0 \uC790\uB3D9\uC73C\uB85C \uACC4\uC18D",
  "set.autoContinue.desc": "\uD55C \uBA54\uC2DC\uC9C0\uB2F9 \uCD5C\uB300 \uC138 \uBC88 \uACC4\uC18D \uC9C4\uD589\uD558\uB3C4\uB85D \uC751\uB2F5\uD569\uB2C8\uB2E4. \uBB38\uC11C\uB97C \uC4F0\uAE30 \uC804\uC5D0\uB294 \uC2B9\uC778 \uC124\uC815\uC744 \uB530\uB985\uB2C8\uB2E4.",
  "set.maxIter.name": "\uBA54\uC2DC\uC9C0\uB2F9 \uCD5C\uB300 \uB3C4\uAD6C \uD638\uCD9C \uD69F\uC218",
  "set.maxIter.desc": "\uB3C4\uAD6C \uD638\uCD9C\uC774 \uBC18\uBCF5\uB418\uB294 \uAC83\uC744 \uC81C\uD55C\uD569\uB2C8\uB2E4. \uC5EC\uB7EC \uB178\uD2B8\uB97C \uC815\uB9AC\uD558\uB294 \uACBD\uC6B0 \uD638\uCD9C \uD69F\uC218\uAC00 \uB354 \uD544\uC694\uD569\uB2C8\uB2E4.",
  "set.maxChars.name": "\uB3C4\uAD6C \uACB0\uACFC\uB2F9 \uCD5C\uB300 \uBB38\uC790 \uC218",
  "set.maxChars.desc": "\uAE34 \uB178\uD2B8\uB294 \uB098\uB204\uC5B4 \uC77D\uC2B5\uB2C8\uB2E4. \uCEE8\uD14D\uC2A4\uD2B8\uAC00 \uC791\uC73C\uBA74 \uAC12\uC744 \uC904\uC774\uC138\uC694.",
  "set.conventions.name": "Vault \uC791\uC5C5 \uADDC\uCE59 \uB178\uD2B8",
  "set.conventions.desc": "\uD3F4\uB354 \uC6A9\uB3C4, \uC774\uB984 \uADDC\uCE59, \uC218\uC815 \uAE08\uC9C0 \uB300\uC0C1 \uB4F1\uC744 \uC801\uC5B4 \uB450\uBA74 \uC5D0\uC774\uC804\uD2B8\uAC00 \uB9E4 \uC694\uCCAD\uC5D0\uC11C \uCC38\uC870\uD569\uB2C8\uB2E4.",
  "set.conventions.button": "\uB9CC\uB4E4\uAE30 \uB610\uB294 \uC5F4\uAE30",
  "set.inbox.name": "\uC77C\uC77C \uB178\uD2B8\uC758 \uC218\uC9D1 \uC81C\uBAA9",
  "set.inbox.desc": "\uC77C\uC77C \uB178\uD2B8 \uC815\uB9AC\uC5D0\uC11C \uC77D\uC744 \uC139\uC158 \uC81C\uBAA9\uC744 # \uC5C6\uC774 \uC785\uB825\uD569\uB2C8\uB2E4.",
  "set.topics.name": "\uC8FC\uC81C \uB178\uD2B8 \uD3F4\uB354",
  "set.topics.desc": "\uC77C\uC77C \uB178\uD2B8\uB97C \uD1B5\uD569\uD574 \uB9CC\uB4E0 \uC8FC\uC81C \uB178\uD2B8\uB97C \uC800\uC7A5\uD560 \uACF3\uC785\uB2C8\uB2E4. \uBE44\uC6CC \uB450\uBA74 Vault \uCD5C\uC0C1\uC704\uC5D0 \uC800\uC7A5\uD569\uB2C8\uB2E4.",
  "set.citations.name": "\uBB38\uB2E8 \uCD9C\uCC98 \uD45C\uC2DC",
  "set.citations.desc": "\uB2F5\uBCC0\uC5D0 \uC0AC\uC6A9\uD55C \uBB38\uB2E8\uC73C\uB85C \uC5F0\uACB0\uD569\uB2C8\uB2E4. \uBE14\uB85D ID\uAC00 \uC5C6\uB294 \uBB38\uB2E8\uC5D0 ID\uB97C \uCD94\uAC00\uD560 \uB54C\uB294 \uBCC0\uACBD \uC2B9\uC778\uC744 \uC694\uCCAD\uD569\uB2C8\uB2E4. \uC81C\uBAA9 \uBC29\uC2DD\uC740 \uAE30\uC874 \uC81C\uBAA9\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4.",
  "set.citations.blocks": "\uBE14\uB85D ID \uC0AC\uC6A9 (\uCD94\uAC00 \uC2DC \uC2B9\uC778)",
  "set.citations.headings": "\uC81C\uBAA9\uB9CC \uC0AC\uC6A9 (\uBB38\uC11C \uC218\uC815 \uC5C6\uC74C)",
  "set.citations.off": "\uB044\uAE30",
  "set.extra.name": "\uCD94\uAC00 \uC9C0\uCE68",
  "set.extra.desc": "Vault \uADDC\uCE59, \uB9D0\uD22C, \uBB38\uC11C \uC591\uC2DD \uB4F1\uC744 \uC785\uB825\uD558\uBA74 \uC2DC\uC2A4\uD15C \uC9C0\uCE68\uC5D0 \uCD94\uAC00\uB429\uB2C8\uB2E4.",
  "set.concepts.name": "\uAC1C\uB150 \uB178\uD2B8 \uD3F4\uB354",
  "set.concepts.desc": "\uAC1C\uB150 \uB9C1\uD06C \uC81C\uC548\uC5D0 \uC0AC\uC6A9\uD560 \uD3F4\uB354\uB97C \uD55C \uC904\uC5D0 \uD558\uB098\uC529 \uC785\uB825\uD569\uB2C8\uB2E4. #concept, #topic \uB610\uB294 type: concept\uAC00 \uC788\uB294 \uB178\uD2B8\uB3C4 \uD3EC\uD568\uD569\uB2C8\uB2E4.",
  "set.quizN.name": "\uD034\uC988 \uBB38\uD56D \uC218",
  "set.quizN.desc": "\uD034\uC988\uC5D0 \uCD9C\uC81C\uD560 \uAE30\uBCF8 \uBB38\uD56D \uC218\uC785\uB2C8\uB2E4.",
  "set.quizFolder.name": "\uD034\uC988 \uBCF5\uC2B5 \uD3F4\uB354",
  "set.quizFolder.desc": "\uC2B9\uC778 \uD6C4 \uD2C0\uB9B0 \uBB38\uC81C\uB97C \uBCF5\uC2B5 \uB178\uD2B8\uC5D0 \uC800\uC7A5\uD560 \uACF3\uC785\uB2C8\uB2E4.",
  "set.lcStatus.name": "Lecture Companion",
  "set.lcStatus.on": "\uC124\uCE58\uB418\uC5B4 \uC788\uC2B5\uB2C8\uB2E4. \uAC15\uC758 \uBAA9\uB85D\uACFC \uC2DC\uAC04 \uC815\uBCF4\uAC00 \uC788\uB294 \uC790\uB9C9, \uACFC\uBAA9\uBCC4 \uD034\uC988, \uC74C\uC131 \uBC1B\uC544\uC4F0\uAE30\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
  "set.lcStatus.off": "\uC124\uCE58\uD558\uBA74 \uAC15\uC758 \uBC0F \uC790\uB9C9 \uC77D\uAE30, \uACFC\uBAA9\uBCC4 \uD034\uC988, \uC74C\uC131 \uC785\uB825\uC744 \uC0AC\uC6A9\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
  "set.schedule.about": "\uC608\uC57D \uC2DC\uAC01 \uC774\uD6C4 Obsidian\uC774 \uC5F4\uB824 \uC788\uC73C\uBA74 \uC791\uC5C5\uC774 \uC2E4\uD589\uB429\uB2C8\uB2E4. \uC0DD\uC131\uB41C \uBCC0\uACBD\uC548\uC740 \uAC80\uD1A0 \uB300\uAE30 \uBAA9\uB85D\uC5D0 \uB4E4\uC5B4\uAC11\uB2C8\uB2E4.",
  "set.nightly.name": "\uB9E4\uC77C \uBC24 \uC77C\uC77C \uB178\uD2B8 \uC815\uB9AC",
  "set.nightly.desc": "\uCD5C\uADFC \uC774\uD2C0\uC758 \uC77C\uC77C \uB178\uD2B8\uB97C \uC8FC\uC81C\uBCC4\uB85C \uC815\uB9AC\uD558\uACE0 \uBCC0\uACBD\uC548\uC744 \uAC80\uD1A0 \uB300\uAE30 \uBAA9\uB85D\uC5D0 \uB123\uC2B5\uB2C8\uB2E4.",
  "set.nightlyTime.name": "\uC57C\uAC04 \uC791\uC5C5 \uC2DC\uAC01",
  "set.nightlyTime.desc": "\uC57C\uAC04 \uC791\uC5C5\uC744 \uC2E4\uD589\uD560 \uD604\uC9C0 \uC2DC\uAC01\uC785\uB2C8\uB2E4.",
  "set.digest.name": "\uC8FC\uAC04 \uC694\uC57D",
  "set.digest.desc": "\uC774\uBC88 \uC8FC\uC5D0 \uB9CC\uB4E4\uAC70\uB098 \uC218\uC815\uD55C \uB178\uD2B8\uB97C \uB9C1\uD06C\uC640 \uD568\uAED8 \uC694\uC57D\uD558\uACE0 \uAC80\uD1A0\uB97C \uC694\uCCAD\uD569\uB2C8\uB2E4.",
  "set.digestDay.name": "\uC8FC\uAC04 \uC694\uC57D \uC694\uC77C",
  "set.digestTime.name": "\uC8FC\uAC04 \uC694\uC57D \uC2DC\uAC01",
  "set.digestTime.desc": "\uC120\uD0DD\uD55C \uC694\uC77C\uC5D0 \uC694\uC57D\uC744 \uC791\uC131\uD560 \uD604\uC9C0 \uC2DC\uAC01\uC785\uB2C8\uB2E4.",
  "set.digestFolder.name": "\uC8FC\uAC04 \uC694\uC57D \uD3F4\uB354",
  "set.pending.name": "\uAC80\uD1A0 \uB300\uAE30",
  "set.pending.some": "\uC608\uC57D \uC791\uC5C5 \uBCC0\uACBD\uC548 {n}\uAC1C\uAC00 \uB300\uAE30 \uC911\uC785\uB2C8\uB2E4.",
  "set.pending.none": "\uB300\uAE30 \uC911\uC778 \uBCC0\uACBD\uC548\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.",
  "set.pending.button": "\uC9C0\uAE08 \uAC80\uD1A0",
  "day.0": "\uC77C\uC694\uC77C",
  "day.1": "\uC6D4\uC694\uC77C",
  "day.2": "\uD654\uC694\uC77C",
  "day.3": "\uC218\uC694\uC77C",
  "day.4": "\uBAA9\uC694\uC77C",
  "day.5": "\uAE08\uC694\uC77C",
  "day.6": "\uD1A0\uC694\uC77C",
  "set.setup.name": "\uCD08\uAE30 \uC124\uC815 \uD655\uC778",
  "set.setup.desc": "\uBAA8\uB378 \uC11C\uBC84, \uCC44\uD305 \uBAA8\uB378, \uC784\uBCA0\uB529 \uBAA8\uB378, \uC0C9\uC778 \uC0C1\uD0DC\uB97C \uD655\uC778\uD569\uB2C8\uB2E4.",
  "set.setup.button": "\uC810\uAC80\uD45C \uC5F4\uAE30",
  "set.sample.name": "\uC608\uC81C \uB178\uD2B8 \uC0AC\uC6A9\uD574 \uBCF4\uAE30",
  "set.sample.desc": "\uC608\uC81C \uB178\uD2B8 \uD3F4\uB354\uB97C \uB9CC\uB4E4\uACE0 \uCC44\uD305\uC5D0 \uC9C8\uBB38 \uC138 \uAC00\uC9C0\uB97C \uD45C\uC2DC\uD569\uB2C8\uB2E4.",
  "set.sample.button": "\uC608\uC81C \uB178\uD2B8 \uB9CC\uB4E4\uAE30",
  "set.report.name": "\uBB38\uC81C \uC2E0\uACE0",
  "set.report.desc": "\uBC84\uC804, \uC124\uC815, \uCD5C\uADFC \uC624\uB958\uB97C \uB2F4\uC740 GitHub \uC774\uC288 \uCD08\uC548\uC744 \uB9CC\uB4ED\uB2C8\uB2E4. \uD0A4, \uACBD\uB85C, \uB178\uD2B8\uB294 \uAE30\uBCF8\uC801\uC73C\uB85C \uC81C\uC678\uB418\uBA70 \uC804\uC1A1 \uC804\uC5D0 \uCD08\uC548\uC744 \uD655\uC778\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
  "set.report.button": "\uBB38\uC81C \uC2E0\uACE0",
  "cmd.openChat": "\uCC44\uD305 \uC5F4\uAE30",
  "cmd.askSelection": "\uC120\uD0DD\uD55C \uD14D\uC2A4\uD2B8\uC5D0 \uB300\uD574 \uC9C8\uBB38",
  "cmd.reformat": "\uD604\uC7AC \uB178\uD2B8 \uC815\uB9AC",
  "cmd.summarize": "\uD604\uC7AC \uB178\uD2B8 \uC694\uC57D",
  "cmd.editSelection": "\uC9C0\uC2DC\uB97C \uC785\uB825\uD574 \uC120\uD0DD \uC601\uC5ED \uD3B8\uC9D1",
  "cmd.daily": "\uC77C\uC77C \uB178\uD2B8\uB97C \uC8FC\uC81C\uBCC4\uB85C \uC815\uB9AC",
  "cmd.garden": "Vault \uAC1C\uC120 \uC0AC\uD56D \uC81C\uC548",
  "cmd.undoLast": "\uCD5C\uADFC \uBCC0\uACBD \uC2E4\uD589 \uCDE8\uC18C",
  "cmd.undoTurn": "\uB9C8\uC9C0\uB9C9 \uC751\uB2F5\uC758 \uBCC0\uACBD \uBAA8\uB450 \uC2E4\uD589 \uCDE8\uC18C",
  "cmd.history": "\uBCC0\uACBD \uAE30\uB85D \uBCF4\uAE30",
  "cmd.quiz": "\uC8FC\uC81C\uB098 \uACFC\uBAA9\uC73C\uB85C \uD034\uC988 \uC2DC\uC791",
  "cmd.concepts": "\uC774 \uB178\uD2B8\uC758 \uAC1C\uB150 \uB9C1\uD06C \uC81C\uC548",
  "cmd.review": "\uC608\uC57D \uC791\uC5C5\uC758 \uBCC0\uACBD\uC548 \uAC80\uD1A0",
  "cmd.runNightly": "\uC57C\uAC04 \uC791\uC5C5 \uC9C0\uAE08 \uC2E4\uD589 (\uBCC0\uACBD\uC548 \uAC80\uD1A0 \uD544\uC694)",
  "cmd.runDigest": "\uC774\uBC88 \uC8FC \uC694\uC57D \uC791\uC131 (\uAC80\uD1A0 \uD544\uC694)",
  "cmd.gists": "\uB178\uD2B8 \uD55C \uC904 \uC694\uC57D \uB2E4\uC2DC \uB9CC\uB4E4\uAE30",
  "cmd.index": "\uC758\uBBF8 \uAC80\uC0C9 \uC0C9\uC778 \uB2E4\uC2DC \uB9CC\uB4E4\uAE30",
  "cmd.report": "\uBB38\uC81C \uC2E0\uACE0",
  "cmd.setup": "\uCD08\uAE30 \uC124\uC815 \uD655\uC778",
  "cmd.sample": "\uC608\uC81C \uB178\uD2B8 \uC0AC\uC6A9\uD574 \uBCF4\uAE30",
  "ribbon.open": "Local Vault Agent \uC5F4\uAE30",
  "view.title": "Local Vault Agent",
  "view.newChat": "\uC0C8 \uCC44\uD305",
  "view.copyChat": "\uB300\uD654\uB97C Markdown\uC73C\uB85C \uBCF5\uC0AC",
  "view.refreshModels": "\uBAA8\uB378 \uBAA9\uB85D \uC0C8\uB85C\uACE0\uCE68",
  "view.modelSelect": "\uCC44\uD305 \uBAA8\uB378",
  "view.messages": "\uB300\uD654",
  "view.input.placeholder": "\uB178\uD2B8\uC5D0 \uB300\uD574 \uC9C8\uBB38\uD558\uC138\uC694. @\uB85C \uB178\uD2B8 \uCCA8\uBD80, /\uB85C \uBA85\uB839 \uC5F4\uAE30, Shift+Enter\uB85C \uC904\uBC14\uAFC8",
  "view.input.label": "\uBA54\uC2DC\uC9C0",
  "view.send": "\uBCF4\uB0B4\uAE30",
  "view.stop": "\uC911\uC9C0",
  "view.mic": "\uC74C\uC131 \uC785\uB825 (Lecture Companion \uC0AC\uC6A9)",
  "view.mic.stop": "\uC911\uC9C0\uD558\uACE0 \uBC1B\uC544\uC4F0\uAE30",
  "view.mic.busy": "\uBC1B\uC544\uC4F0\uB294 \uC911\u2026",
  "view.welcome": "\uB178\uD2B8\uC5D0 \uB300\uD574 \uC9C8\uBB38\uD558\uAC70\uB098, \uC5EC\uB7EC \uBB38\uC11C\uB97C \uD1B5\uD569\uD558\uACE0 \uD3B8\uC9D1\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uBB38\uC11C \uBCC0\uACBD\uC740 \uC801\uC6A9 \uC804\uC5D0 \uBE44\uAD50\uD558\uACE0 \uB098\uC911\uC5D0 \uC2E4\uD589 \uCDE8\uC18C\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
  "view.welcome.hint": "@ \uB178\uD2B8 \uCCA8\uBD80 \xB7 / \uBA85\uB839 \uBAA9\uB85D \xB7 Shift+Enter \uC904\uBC14\uAFC8",
  "view.welcome.sample": "\uC608\uC81C \uB178\uD2B8 \uC0AC\uC6A9\uD574 \uBCF4\uAE30",
  "view.welcome.setup": "\uCD08\uAE30 \uC124\uC815 \uD655\uC778",
  "view.chip.written": "\u2026\uC5D0 \uB300\uD574 \uC5B4\uB5A4 \uB0B4\uC6A9\uC744 \uC801\uC5C8\uC9C0?",
  "view.chip.compile": "\u2026\uC5D0 \uB300\uD55C \uB0B4\uC6A9\uC744 \uC0C8 \uB178\uD2B8\uB85C \uD1B5\uD569\uD574 \uC918",
  "view.chip.cleanup": "\u2026\uC5D0 \uD574\uB2F9\uD558\uB294 \uB178\uD2B8\uB97C \uC815\uB9AC\uD574 \uC918",
  "view.chip.reformat": "\uD604\uC7AC \uB178\uD2B8\uB97C \uC815\uB9AC\uD574 \uC918",
  "view.copy": "\uBCF5\uC0AC",
  "view.insert": "\uCEE4\uC11C \uC704\uCE58\uC5D0 \uC0BD\uC785",
  "view.undo": "\uC2E4\uD589 \uCDE8\uC18C",
  "view.undone": "\uC2E4\uD589 \uCDE8\uC18C\uB428",
  "view.restored": "\uC774\uC804 \uB300\uD654\uB97C \uBCF5\uC6D0\uD588\uC2B5\uB2C8\uB2E4.",
  "view.stopped": "\uC911\uC9C0\uD588\uC2B5\uB2C8\uB2E4.",
  "view.autoContinued": "\uBAA8\uB378\uC774 \uC9C4\uD589 \uC5EC\uBD80\uB97C \uBB3C\uC5B4 \uC790\uB3D9\uC73C\uB85C \uACC4\uC18D\uD558\uB3C4\uB85D \uC751\uB2F5\uD588\uC2B5\uB2C8\uB2E4.",
  "view.groundingNudge": "\uB2F5\uBCC0\uC5D0 \uC874\uC7AC\uD558\uC9C0 \uC54A\uB294 \uB178\uD2B8\uAC00 \uC778\uC6A9\uB418\uC5B4 Vault\uB97C \uBA3C\uC800 \uAC80\uC0C9\uD558\uB3C4\uB85D \uC694\uCCAD\uD588\uC2B5\uB2C8\uB2E4.",
  "view.report": "\uC774 \uBB38\uC81C \uC2E0\uACE0",
  "view.partial": "\uC751\uB2F5\uC774 \uB05D\uB098\uAE30 \uC804 {n}\uAC1C \uBCC0\uACBD\uC744 \uC801\uC6A9\uD588\uC2B5\uB2C8\uB2E4. \uAC01 \uBCC0\uACBD\uC740 \uC2B9\uC778\uB418\uC5C8\uC73C\uBA70 \uC2E4\uD589 \uCDE8\uC18C\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
  "view.partial.undo": "\uC774 \uBCC0\uACBD\uB4E4 \uC2E4\uD589 \uCDE8\uC18C",
  "view.status.keyword": "\uD0A4\uC6CC\uB4DC \uAC80\uC0C9",
  "view.status.indexing": "\uC0C9\uC778 \uC0DD\uC131 \uC911\u2026 \uC644\uB8CC {done}\uAC1C, \uB300\uAE30 {pending}\uAC1C",
  "view.status.index": "\uC0C9\uC778 \xB7 \uB178\uD2B8 {notes}\uAC1C, \uBB38\uB2E8 {chunks}\uAC1C",
  "view.status.indexError": "\uC0C9\uC778 \uC624\uB958 \xB7 {error}",
  "view.status.working": "\uC791\uC5C5 \uC911\u2026 \uB3C4\uAD6C \uD638\uCD9C {calls}\uD68C \xB7 {secs}\uCD08",
  "view.status.context": "\uCEE8\uD14D\uC2A4\uD2B8 {used} / {total} ({pct}%)",
  "approve.approve": "\uC2B9\uC778",
  "approve.all": "\uC774 \uCC44\uD305\uC5D0\uC11C \uBAA8\uB450 \uC2B9\uC778",
  "approve.reject": "\uAC70\uC808",
  "approve.hint": "Enter \uC2B9\uC778 \xB7 A \uC774 \uCC44\uD305\uC5D0\uC11C \uBAA8\uB450 \uC2B9\uC778 \xB7 Esc \uAC70\uC808",
  "approve.diff": "\uBCC0\uACBD\uC548 \uC904\uBCC4 \uBE44\uAD50",
  "report.title": "\uBB38\uC81C \uC2E0\uACE0",
  "report.help": "\uC774\uC288\uC5D0 \uD3EC\uD568\uD560 \uB0B4\uC6A9\uC744 \uD655\uC778\uD558\uACE0 \uC218\uC815\uD558\uC138\uC694. GitHub\uC5D0\uC11C \uC9C1\uC811 \uC5F4\uAE30 \uC804\uAE4C\uC9C0 \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4. \uD0A4, \uD1A0\uD070, Vault \uACBD\uB85C\uAC00 \uC81C\uAC70\uB418\uBA70 \uB178\uD2B8\uC640 \uCC44\uD305 \uB0B4\uC6A9\uC740 \uC120\uD0DD\uD560 \uB54C\uB9CC \uD3EC\uD568\uB429\uB2C8\uB2E4.",
  "report.what": "\uC5B4\uB5A4 \uBB38\uC81C\uAC00 \uBC1C\uC0DD\uD588\uB098\uC694?",
  "report.what.placeholder": "\uC5B4\uB5A4 \uC791\uC5C5\uC744 \uD588\uACE0, \uBB34\uC5C7\uC744 \uAE30\uB300\uD588\uC73C\uBA70, \uC2E4\uC81C\uB85C \uC5B4\uB5A4 \uC77C\uC774 \uBC1C\uC0DD\uD588\uB098\uC694?",
  "report.chat": "\uB9C8\uC9C0\uB9C9 \uB300\uD654 \uD3EC\uD568 (\uC9C8\uBB38, \uB2F5\uBCC0, \uB3C4\uAD6C \uACB0\uACFC \uBC0F \uB178\uD2B8 \uB0B4\uC6A9\uC774 \uD3EC\uD568\uB420 \uC218 \uC788\uC74C)",
  "report.copy": "\uBCF5\uC0AC",
  "report.open": "GitHub\uC5D0\uC11C \uC5F4\uAE30",
  "report.copied": "\uC2E0\uACE0 \uB0B4\uC6A9\uC744 \uD074\uB9BD\uBCF4\uB4DC\uC5D0 \uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4.",
  "report.tooLong": "\uC2E0\uACE0 \uB0B4\uC6A9\uC774 \uAE38\uC5B4 \uD074\uB9BD\uBCF4\uB4DC\uC5D0 \uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4. \uC5F4\uB9B0 \uC774\uC288\uC5D0 \uBD99\uC5EC \uB123\uC73C\uC138\uC694.",
  "setup.title": "\uCD08\uAE30 \uC124\uC815 \uD655\uC778",
  "setup.help": "\uBAA8\uB378 \uC11C\uBC84, \uCC44\uD305 \uBAA8\uB378\uACFC \uAC80\uC0C9 \uC900\uBE44 \uC0C1\uD0DC\uB97C \uD655\uC778\uD569\uB2C8\uB2E4. \uBAA8\uB378 \uB2E4\uC6B4\uB85C\uB4DC\uB294 \uC9C1\uC811 \uC120\uD0DD\uD560 \uB54C\uB9CC \uC9C4\uD589\uB429\uB2C8\uB2E4.",
  "setup.server": "\uBAA8\uB378 \uC11C\uBC84 \uC5F0\uACB0",
  "setup.chat": "\uB3C4\uAD6C \uD638\uCD9C\uC744 \uC9C0\uC6D0\uD558\uB294 \uCC44\uD305 \uBAA8\uB378",
  "setup.embed": "\uC758\uBBF8 \uAC80\uC0C9\uC6A9 \uC784\uBCA0\uB529 \uBAA8\uB378",
  "setup.index": "\uB178\uD2B8 \uC0C9\uC778",
  "setup.checking": "\uD655\uC778 \uC911\u2026",
  "setup.recheck": "\uB2E4\uC2DC \uD655\uC778",
  "setup.pull": "{model} \uB2E4\uC6B4\uB85C\uB4DC",
  "setup.pulling": "{model} \uB2E4\uC6B4\uB85C\uB4DC \uC911 \xB7 {pct}",
  "setup.useModel": "{model} \uC0AC\uC6A9",
  "setup.buildIndex": "\uC0C9\uC778 \uB9CC\uB4E4\uAE30",
  "setup.openSettings": "\uC124\uC815 \uC5F4\uAE30",
  "setup.recommend": "\uC7A5\uBE44\uC5D0 \uB9DE\uB294 \uCD94\uCC9C \uBAA8\uB378",
  "setup.rec.24": "GPU \uBA54\uBAA8\uB9AC 24 GB \uC774\uC0C1",
  "setup.rec.12": "GPU \uBA54\uBAA8\uB9AC 12~16 GB",
  "setup.rec.8": "GPU \uBA54\uBAA8\uB9AC 8 GB",
  "setup.rec.cpu": "\uB178\uD2B8\uBD81 \uB610\uB294 \uC678\uC7A5 GPU \uC5C6\uC74C",
  "setup.sample": "\uC608\uC81C \uB178\uD2B8 \uC0AC\uC6A9\uD574 \uBCF4\uAE30",
  "setup.done": "\uC900\uBE44\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uB178\uD2B8\uC5D0 \uB300\uD574 \uC9C8\uBB38\uD574 \uBCF4\uC138\uC694.",
  "survey.question": "Local Vault Agent\uB97C \uC5B4\uB5BB\uAC8C \uC0AC\uC6A9\uD558\uACE0 \uACC4\uC2E0\uAC00\uC694?",
  "survey.great": "\uC798 \uC791\uB3D9\uD569\uB2C8\uB2E4",
  "survey.problems": "\uBB38\uC81C\uAC00 \uC788\uC2B5\uB2C8\uB2E4",
  "survey.notUseful": "\uB3C4\uC6C0\uC774 \uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4",
  "survey.dismiss": "\uB2E4\uC2DC \uBB3B\uC9C0 \uC54A\uAE30",
  "survey.thanks": "\uAC10\uC0AC\uD569\uB2C8\uB2E4. \uB9C1\uD06C\uB97C \uC5F4\uC5B4\uB3C4 \uC815\uBCF4\uAC00 \uC790\uB3D9 \uC804\uC1A1\uB418\uC9C0\uB294 \uC54A\uC2B5\uB2C8\uB2E4.",
  "notice.openNote": "\uBA3C\uC800 Markdown \uB178\uD2B8\uB97C \uC5EC\uC138\uC694.",
  "notice.selectText": "\uB178\uD2B8\uC5D0\uC11C \uD14D\uC2A4\uD2B8\uB97C \uBA3C\uC800 \uC120\uD0DD\uD558\uC138\uC694.",
  "notice.nothingUndo": "\uC2E4\uD589 \uCDE8\uC18C\uD560 \uBCC0\uACBD\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.",
  "notice.wait": "\uD604\uC7AC \uB2F5\uBCC0\uC774 \uB05D\uB0A0 \uB54C\uAE4C\uC9C0 \uAE30\uB2E4\uB9AC\uAC70\uB098 \uC751\uB2F5\uC744 \uC911\uC9C0\uD558\uC138\uC694.",
  "notice.sampleCreated": "{folder}\uC5D0 \uC608\uC81C \uB178\uD2B8 {n}\uAC1C\uB97C \uB9CC\uB4E4\uC5C8\uC2B5\uB2C8\uB2E4.",
  "notice.sampleExists": "\uC608\uC81C \uB178\uD2B8\uAC00 \uC774\uBBF8 {folder}\uC5D0 \uC788\uC2B5\uB2C8\uB2E4."
};

// src/i18n.ts
var en = {
  "set.ui.name": "Interface language",
  "set.ui.desc": "Reload the plugin to apply the change.",
  // Settings: headings
  "set.h.server": "Model server",
  "set.h.search": "Search",
  "set.h.agent": "Agent",
  "set.h.study": "Study",
  "set.h.schedule": "Scheduled jobs",
  "set.h.help": "Help and feedback",
  // Settings: server
  "set.provider.name": "Provider",
  "set.provider.desc": "Ollama (the default, what the benchmark measures), or any server with an OpenAI-compatible API on your machine: LM Studio, llama.cpp server, Jan, vLLM.",
  "set.provider.ollama": "Ollama",
  "set.provider.openai": "OpenAI-compatible (LM Studio, llama.cpp, Jan, vLLM)",
  "set.url.name": "Ollama URL",
  "set.url.desc": "Where Ollama is listening. Use a LAN address on mobile.",
  "set.oaUrl.name": "Server URL",
  "set.oaUrl.desc": "Base URL of the OpenAI-compatible API, ending in /v1. LM Studio: http://localhost:1234/v1 \xB7 llama.cpp: http://localhost:8080/v1 \xB7 Jan: http://localhost:1337/v1 \xB7 vLLM: http://localhost:8000/v1.",
  "set.oaKey.name": "API key",
  "set.oaKey.desc": "Only if your local server asks for one. Stored in the plugin's settings, never sent anywhere but that server, and never included in a problem report.",
  "set.test.button": "Test connection and speed",
  "set.lc.name": "Use Lecture Companion's Ollama settings",
  "set.lc.desc": "Lecture Companion is installed and uses {url} with {model}. Copy them here so both plugins share one Ollama and one model in memory.",
  "set.model.name": "Chat model",
  "set.model.desc": "Must support tool calling. Recommended: qwen3.5:9b (12 GB GPUs), qwen3.5:4b (8 GB), qwen3.5:35b-a3b (24 GB).",
  "set.model.placeholder": "or type a model name",
  "set.ctx.name": "Context window (num_ctx)",
  "set.ctx.desc": "Tokens the model can see at once. 32768 is the default and the benchmark's setting; 16384 on an 8 GB card. Larger is not faster or more accurate: the conversation is capped at the 32k budget regardless, and the KV cache grows with the window. (Ollama only; other servers set this when loading the model.)",
  "set.temp.name": "Temperature",
  "set.temp.desc": "0.6 is the default. Lower looks more precise but near-greedy decoding makes small models repeat themselves; Qwen's own guidance is 0.6\u20130.7.",
  "set.think.name": "Thinking mode",
  "set.think.desc": "For models that support reasoning (Qwen3, DeepSeek-R1). 'Off' (the default) answered as accurately as thinking in the benchmark and two to three times faster. 'Auto' uses the model default.",
  "set.think.auto": "Auto",
  "set.think.on": "On",
  "set.think.off": "Off",
  "set.showThinking.name": "Show thinking in chat",
  "set.keepAlive.name": "Keep model loaded",
  "set.keepAlive.desc": "How long Ollama keeps the model in memory after a request (e.g. 10m, 1h, -1 for forever).",
  "set.vision.name": "Vision model",
  "set.vision.desc": "Reads images notes embed and scanned PDF pages (the read_image tool), e.g. qwen2.5vl:7b. Empty: the chat model, when it can see (qwen3.5 can). Without one the agent is simply not offered the tool.",
  "set.vision.placeholder": "(the chat model)",
  "set.vision.check": "Check",
  "set.lang.name": "Answer language",
  "set.lang.desc": "Empty: answer in the language of each question. Or name a language (e.g. Deutsch, Espa\xF1ol, \u65E5\u672C\u8A9E) to always answer in it.",
  "set.lang.placeholder": "(the question's language)",
  // Settings: search
  "set.semantic.name": "Semantic search",
  "set.semantic.desc": "Embed your notes with a local model so search understands meaning, not just keywords. Keyword search always works as a fallback.",
  "set.embed.name": "Embedding model",
  "set.embed.desc": "Changing this rebuilds the index. nomic-embed-text is small and good.",
  "set.index.name": "Index",
  "set.index.building": "Indexing\u2026 {done} notes done, {pending} pending",
  "set.index.error": "Error: {error}",
  "set.index.ready": "{notes} notes indexed ({chunks} chunks)",
  "set.index.update": "Update",
  "set.index.rebuild": "Rebuild",
  "set.excluded.name": "Excluded folders",
  "set.excluded.desc": "One folder per line. These are never searched, indexed or edited by the agent.",
  "set.gists.name": "Note gists",
  "set.gists.desc": "Write a one-sentence gist of every note with the chat model (in the background, paused while you chat) for the vault outline the agent sees. Off by default: the benchmark scored the same without it, and on a modest GPU it is an hour for a large vault.",
  "set.gists.rebuild": "Rebuild",
  // Settings: agent
  "set.autoApprove.name": "Auto-approve edits",
  "set.autoApprove.desc": "Skip the diff approval dialog and let the agent write to notes directly. Not recommended; you can also choose 'Approve all' per chat.",
  "set.autoContinue.name": "Keep going when the model asks for permission",
  "set.autoContinue.desc": "Small models like to stop with 'Would you like me to proceed?'. When on, the agent answers yes for you (up to three times per message) so multi-note tasks run to the end. Every write still goes through approval.",
  "set.maxIter.name": "Max tool calls per message",
  "set.maxIter.desc": "Stops runaway loops. Multi-note clean-ups need 2\u20133 calls per note, so keep this generous.",
  "set.maxChars.name": "Max characters per tool result",
  "set.maxChars.desc": "Longer notes are paged. Lower this for small context windows.",
  "set.conventions.name": "Conventions note",
  "set.conventions.desc": "A note in your vault that is given to the agent on every message, like a CLAUDE.md: folder meanings, naming rules, things to never touch.",
  "set.conventions.button": "Create / open",
  "set.inbox.name": "Daily notes inbox heading",
  "set.inbox.desc": "For 'Process my daily notes': the section of each daily note where loose captures land, without the #.",
  "set.topics.name": "Topic notes folder",
  "set.topics.desc": "For 'Process my daily notes': where compiled topic notes are created. Empty means the vault root.",
  "set.citations.name": "Paragraph citations",
  "set.citations.desc": "Answers end with links to the exact paragraphs they used. 'Block ids' links by ^id; a paragraph without one gets an id added, shown as one diff per note for you to approve (rejecting falls back to the heading). 'Headings' never writes.",
  "set.citations.blocks": "Block ids (added on approval)",
  "set.citations.headings": "Headings only (no writes)",
  "set.citations.off": "Off",
  "set.extra.name": "Extra instructions",
  "set.extra.desc": "Appended to the system prompt. Tell the agent about your vault's conventions, preferred tone, note templates, etc.",
  // Settings: study
  "set.concepts.name": "Concept folders",
  "set.concepts.desc": "For 'Suggest concept links': folders whose notes are concept or topic notes, one per line. Notes tagged #concept or #topic, or with type: concept, count too.",
  "set.quizN.name": "Quiz questions",
  "set.quizN.desc": "How many questions 'Quiz me' asks by default.",
  "set.quizFolder.name": "Quiz review folder",
  "set.quizFolder.desc": "Missed questions go to 'Quiz review - <topic>' here, after you approve the diff.",
  "set.lcStatus.name": "Lecture Companion",
  "set.lcStatus.on": "Installed: the agent lists lectures and reads timestamped transcripts from it directly, quizzes draw on its courses, and the chat has a mic button that transcribes through its whisper server.",
  "set.lcStatus.off": "Not installed. With Lecture Companion the agent reads lectures and transcripts as structured data, quizzes know your courses, and the chat gets voice input.",
  // Settings: schedule
  "set.schedule.about": "Obsidian has no background service, so a job runs when Obsidian is open at or after its time. A job never writes: what it would change waits until you review it (a notice when you are back, and a badge in the status bar), as ordinary diffs.",
  "set.nightly.name": "Nightly: process my daily notes",
  "set.nightly.desc": "Compiles the last two days' daily inboxes into topic notes, as the command does, and queues the changes for your review.",
  "set.nightlyTime.name": "Nightly time",
  "set.nightlyTime.desc": "When the nightly job runs (local time).",
  "set.digest.name": "Weekly digest",
  "set.digest.desc": "A note summarising the notes you created or changed that week, with links, queued for your review.",
  "set.digestDay.name": "Digest day",
  "set.digestTime.name": "Digest time",
  "set.digestTime.desc": "When on that day the digest is written (local time).",
  "set.digestFolder.name": "Digest folder",
  "set.pending.name": "Waiting for review",
  "set.pending.some": "{n} change(s) from scheduled jobs.",
  "set.pending.none": "Nothing waiting.",
  "set.pending.button": "Review now",
  "day.0": "Sunday",
  "day.1": "Monday",
  "day.2": "Tuesday",
  "day.3": "Wednesday",
  "day.4": "Thursday",
  "day.5": "Friday",
  "day.6": "Saturday",
  // Settings: help
  "set.setup.name": "Setup checklist",
  "set.setup.desc": "Checks the model server, the chat and embedding models and the index, with a button to fix each.",
  "set.setup.button": "Open the checklist",
  "set.sample.name": "Try it on sample notes",
  "set.sample.desc": "Creates a small folder of sample notes and opens the chat with three questions to ask about them.",
  "set.sample.button": "Create sample notes",
  "set.report.name": "Report a problem",
  "set.report.desc": "Prepares a GitHub issue with your versions, settings (no keys, no paths, no notes) and recent errors. You review it; nothing is sent automatically.",
  "set.report.button": "Report a problem",
  // Commands
  "cmd.openChat": "Open chat",
  "cmd.askSelection": "Ask about the selected text",
  "cmd.reformat": "Reformat the current note",
  "cmd.summarize": "Summarize the current note",
  "cmd.editSelection": "Edit the selected text with an instruction",
  "cmd.daily": "Process my daily notes (compile inboxes into topic notes)",
  "cmd.garden": "Suggest vault improvements (report in the chat)",
  "cmd.undoLast": "Undo the agent's last change",
  "cmd.undoTurn": "Undo every change from the agent's last message",
  "cmd.history": "Show change history (undo any approved change)",
  "cmd.quiz": "Quiz me on a topic or course",
  "cmd.concepts": "Suggest concept links for this note",
  "cmd.review": "Review changes from scheduled jobs",
  "cmd.runNightly": "Run the nightly daily-notes job now (changes wait for review)",
  "cmd.runDigest": "Write this week's digest now (waits for review)",
  "cmd.gists": "Rebuild note gists",
  "cmd.index": "Rebuild semantic index",
  "cmd.report": "Report a problem",
  "cmd.setup": "Setup checklist",
  "cmd.sample": "Try it on sample notes",
  "ribbon.open": "Open Local Vault Agent",
  // Chat view
  "view.title": "Local Vault Agent",
  "view.newChat": "New chat",
  "view.copyChat": "Copy conversation as markdown",
  "view.refreshModels": "Refresh model list",
  "view.modelSelect": "Chat model",
  "view.messages": "Conversation",
  "view.input.placeholder": "Ask about your notes\u2026 (@ to attach a note, / for commands, Shift+Enter for a new line)",
  "view.input.label": "Message",
  "view.send": "Send",
  "view.stop": "Stop",
  "view.mic": "Dictate (Lecture Companion transcribes it)",
  "view.mic.stop": "Stop and transcribe",
  "view.mic.busy": "Transcribing\u2026",
  "view.welcome": "Ask questions about your notes, compile topics, or ask for edits across many notes. Every change is shown as a diff before it is written and can be undone.",
  "view.welcome.hint": "@ attaches a note to your message \xB7 / lists commands \xB7 Shift+Enter for a new line",
  "view.welcome.sample": "New here? Try it on sample notes",
  "view.welcome.setup": "Setup checklist",
  "view.chip.written": "What have I written about \u2026?",
  "view.chip.compile": "Compile everything about \u2026 into a new note",
  "view.chip.cleanup": "Clean up every note that \u2026",
  "view.chip.reformat": "Reformat the current note",
  "view.copy": "Copy",
  "view.insert": "Insert at cursor",
  "view.undo": "Undo",
  "view.undone": "Undone",
  "view.restored": "Restored from the previous session.",
  "view.stopped": "Stopped.",
  "view.autoContinued": "The model asked whether to continue \u2014 answered yes automatically.",
  "view.groundingNudge": "The reply cited notes that do not exist \u2014 sent it back to search the vault first.",
  "view.report": "Report this problem",
  "view.partial": "{n} change(s) were applied before the turn ended. Each was approved on its own and is complete; you can take them all back.",
  "view.partial.undo": "Undo these changes",
  "view.status.keyword": "Keyword search only",
  "view.status.indexing": "Indexing\u2026 {done} notes ({pending} left)",
  "view.status.index": "Index: {notes} notes, {chunks} chunks",
  "view.status.indexError": "Index: {error}",
  "view.status.working": "Working\u2026 {calls} tool call(s) \xB7 {secs} s",
  "view.status.context": "Context {used} / {total} ({pct}%)",
  // Approval dialog
  "approve.approve": "Approve",
  "approve.all": "Approve all in this chat",
  "approve.reject": "Reject",
  "approve.hint": "Enter approves \xB7 A approves all in this chat \xB7 Esc rejects",
  "approve.diff": "Proposed change, line by line",
  // Report a problem
  "report.title": "Report a problem",
  "report.help": "This is what will go into the issue. Read it and edit anything you like; nothing is sent until you open it on GitHub yourself. Keys, tokens and your vault's paths are removed; note contents and chat text are left out unless you tick the box.",
  "report.what": "What happened?",
  "report.what.placeholder": "What did you do, what did you expect, what happened instead?",
  "report.chat": "Include the last chat (questions, answers and tool results; may contain note text)",
  "report.copy": "Copy",
  "report.open": "Open on GitHub",
  "report.copied": "Report copied to the clipboard.",
  "report.tooLong": "The report is long, so it was copied to the clipboard: paste it into the issue that just opened.",
  // Setup checklist
  "setup.title": "Setup checklist",
  "setup.help": "Everything the agent needs, checked live. Fix buttons only download models you choose; nothing else is installed.",
  "setup.server": "Model server reachable",
  "setup.chat": "A chat model that can call tools",
  "setup.embed": "Embedding model for semantic search",
  "setup.index": "Notes indexed",
  "setup.checking": "Checking\u2026",
  "setup.recheck": "Check again",
  "setup.pull": "Download {model}",
  "setup.pulling": "Downloading {model}: {pct}",
  "setup.useModel": "Use {model}",
  "setup.buildIndex": "Build the index",
  "setup.openSettings": "Open settings",
  "setup.recommend": "Which model fits your machine?",
  "setup.rec.24": "24 GB GPU or more",
  "setup.rec.12": "12\u201316 GB GPU",
  "setup.rec.8": "8 GB GPU",
  "setup.rec.cpu": "Laptop or no discrete GPU",
  "setup.sample": "Try it on sample notes",
  "setup.done": "All set. Ask your notes anything.",
  // Survey
  "survey.question": "Quick question: how is Local Vault Agent working for you?",
  "survey.great": "It works well",
  "survey.problems": "It has problems",
  "survey.notUseful": "Not useful for me",
  "survey.dismiss": "Don't ask again",
  "survey.thanks": "Thank you. The link opens GitHub; nothing was sent.",
  // Notices (common)
  "notice.openNote": "Open a markdown note first.",
  "notice.selectText": "Select some text in a note first.",
  "notice.nothingUndo": "Nothing to undo.",
  "notice.wait": "Wait for the current reply to finish, or stop it, first.",
  "notice.sampleCreated": "Created {n} sample notes in {folder}.",
  "notice.sampleExists": "The sample notes are already in {folder}."
};
var LOCALES = { en, ko };
var current = en;
var currentLocale = "en";
function ui(english, korean) {
  return currentLocale === "ko" ? korean : english;
}
function setLocale(locale) {
  const l = (locale ?? "en").toLowerCase();
  const base = l.split(/[-_]/)[0];
  currentLocale = LOCALES[l] ? l : LOCALES[base] ? base : "en";
  current = LOCALES[currentLocale];
  return currentLocale;
}
function t(key, vars = {}) {
  const s = current[key] ?? en[key];
  return s.replace(/\{(\w+)\}/g, (m, k) => k in vars ? String(vars[k]) : m);
}
function hasKey(key) {
  return key in en;
}
function answerLanguageLine(language) {
  const l = language.trim();
  return l ? `Always write your answers in ${l}, whatever language the question or the notes are in (quotes from notes stay as written).` : "Answer in the language the user writes in (quotes from notes stay as written).";
}

// src/dna-server.ts
var endpoint = "http://127.0.0.1:18081/v1";
var DnaServer = class {
  child;
  starting;
  activeConfig = "";
  ensureStarted(listModels, paths) {
    this.starting ??= this.start(listModels, paths).finally(() => {
      this.starting = void 0;
    });
    return this.starting;
  }
  async start(listModels, paths) {
    const config = JSON.stringify(paths);
    if (this.child && config !== this.activeConfig) {
      const previous = this.child;
      await new Promise((resolve, reject) => {
        const timer = window.setTimeout(() => reject(new Error("\uC11C\uBC84 \uC885\uB8CC \uB300\uAE30 \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.")), 1e4);
        previous.once("close", () => {
          window.clearTimeout(timer);
          resolve();
        });
        previous.kill();
      });
    }
    const verifyModel = async () => {
      const models = await listModels();
      if (!models.some((model2) => model2.name === paths.alias)) {
        throw new Error(ui("The server returned a different model.", "\uC11C\uBC84\uC758 \uBAA8\uB378\uACFC \uC120\uD0DD\uD55C \uBAA8\uB378 \uC774\uB984\uC774 \uB2E4\uB985\uB2C8\uB2E4. \uC678\uBD80 \uC11C\uBC84\uB97C \uC885\uB8CC\uD558\uAC70\uB098 \uBAA8\uB378 \uC124\uC815\uC744 \uD655\uC778\uD558\uC138\uC694."));
      }
    };
    const reachable = await listModels().then(() => true, () => false);
    if (reachable) {
      await verifyModel();
      return ui("Local model server is already running.", "\uB85C\uCEEC \uBAA8\uB378 \uC11C\uBC84\uAC00 \uC774\uBBF8 \uC2E4\uD589 \uC911\uC785\uB2C8\uB2E4.");
    }
    if (this.child) throw new Error(ui("The server is starting.", "\uC11C\uBC84\uB97C \uC2DC\uC791\uD558\uB294 \uC911\uC785\uB2C8\uB2E4."));
    if (!import_obsidian.Platform.isDesktop || !import_obsidian.Platform.isWin) {
      throw new Error(ui("Automatic local model startup requires Windows desktop.", "\uB85C\uCEEC \uBAA8\uB378 \uC790\uB3D9 \uC2DC\uC791\uC740 Windows \uB370\uC2A4\uD06C\uD1B1\uC5D0\uC11C \uC0AC\uC6A9\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4."));
    }
    const { spawn } = require("child_process");
    const path = require("path");
    const { stat } = require("fs").promises;
    const engine = paths.engine || path.join(paths.pluginDir, "engine", "llama-server.exe");
    const model = paths.model || path.join(paths.pluginDir, "models", "DNA3.0-9B.Q4_K_M.gguf");
    for (const file of [engine, model]) {
      if (!path.isAbsolute(file) || !await stat(file).then((info) => info.isFile(), () => false)) {
        throw new Error(ui("Check the absolute file path in Local Vault Agent settings.", "Local Vault Agent \uC124\uC815\uC5D0\uC11C \uD30C\uC77C\uC758 \uC808\uB300 \uACBD\uB85C\uB97C \uD655\uC778\uD558\uC138\uC694.") + " " + file);
      }
    }
    const child = spawn(engine, [
      "-m",
      model,
      "--alias",
      paths.alias,
      "--host",
      "127.0.0.1",
      "--port",
      "18081",
      "-ngl",
      "99",
      "-c",
      String(paths.context),
      "-np",
      "1",
      "--no-webui",
      "--jinja",
      "--reasoning-budget",
      "0"
    ], { windowsHide: true, stdio: ["ignore", "ignore", "pipe"] });
    this.child = child;
    this.activeConfig = config;
    let error;
    let diagnostics = "";
    child.stderr?.on("data", (chunk) => {
      diagnostics = (diagnostics + chunk.toString()).slice(-2e3);
    });
    child.once("error", (err) => {
      error = err;
    });
    child.once("close", () => {
      if (this.child === child) this.child = void 0;
    });
    try {
      const deadline = Date.now() + 9e4;
      while (this.child === child && !error && child.exitCode === null && Date.now() < deadline) {
        const online = await listModels().then(() => true, () => false);
        if (online) {
          await verifyModel();
          return ui("Local model server ready.", "\uB85C\uCEEC \uBAA8\uB378 \uC11C\uBC84\uAC00 \uC900\uBE44\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
        }
        await new Promise((resolve) => window.setTimeout(resolve, 1e3));
      }
      console.error("Local Vault Agent Local model server:", error ?? diagnostics);
      throw new Error(ui("The Local model server could not start. Check the model file, port, and GPU memory.", "\uB85C\uCEEC \uBAA8\uB378 \uC11C\uBC84\uB97C \uC2DC\uC791\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uBAA8\uB378 \uD30C\uC77C, \uD3EC\uD2B8, GPU \uBA54\uBAA8\uB9AC\uB97C \uD655\uC778\uD558\uC138\uC694."));
    } catch (err) {
      if (this.child === child) this.stop();
      throw err;
    }
  }
  stop() {
    return this.child?.kill() ?? false;
  }
};
function isDnaEndpoint(url) {
  return url.replace(/\/+$/, "") === endpoint;
}

// src/main.ts
var import_obsidian9 = require("obsidian");

// src/openai.ts
function toOpenAIMessages(messages) {
  const out = [];
  let open = [];
  let n = 0;
  for (const m of messages) {
    if (m.role === "assistant") {
      const calls = (m.tool_calls ?? []).map((c) => ({ ...c, id: c.id ?? `call_${n++}` }));
      open = calls.map((c) => c.id);
      const msg = { role: "assistant", content: m.content || (calls.length ? null : "") };
      if (calls.length) msg.tool_calls = calls.map((c) => ({ id: c.id, type: "function", function: { name: c.function.name, arguments: JSON.stringify(c.function.arguments ?? {}) } }));
      out.push(msg);
    } else if (m.role === "tool") {
      const id = m.tool_call_id && open.includes(m.tool_call_id) ? m.tool_call_id : open[0] ?? `call_${n++}`;
      open = open.filter((x) => x !== id);
      out.push({ role: "tool", tool_call_id: id, content: m.content });
    } else if (m.images?.length) {
      out.push({ role: m.role, content: [{ type: "text", text: m.content }, ...m.images.map((b64) => ({ type: "image_url", image_url: { url: `data:image/png;base64,${b64}` } }))] });
    } else out.push({ role: m.role, content: m.content });
  }
  return out;
}
async function* sse(body, signal) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    for (; ; ) {
      if (signal?.aborted) {
        await reader.cancel();
        throw new DOMException("Aborted", "AbortError");
      }
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let idx;
      while ((idx = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx + 1);
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (data === "[DONE]") return;
        if (data) yield JSON.parse(data);
      }
    }
    const rest = buffer.trim();
    if (rest.startsWith("data:") && rest.slice(5).trim() !== "[DONE]") yield JSON.parse(rest.slice(5).trim());
  } finally {
    reader.releaseLock();
  }
}
var ToolCallAccumulator = class {
  parts = /* @__PURE__ */ new Map();
  add(deltas) {
    if (!Array.isArray(deltas)) return;
    for (const [pos, raw] of deltas.entries()) {
      const d = raw;
      const i = typeof d.index === "number" ? d.index : pos;
      const cur = this.parts.get(i) ?? { name: "", args: "" };
      if (d.id) cur.id = d.id;
      if (d.function?.name) cur.name += d.function.name;
      if (typeof d.function?.arguments === "string") cur.args += d.function.arguments;
      this.parts.set(i, cur);
    }
  }
  calls() {
    return Array.from(this.parts.entries()).sort(([a], [b]) => a - b).filter(([, p]) => p.name).map(([i, p]) => {
      let args = {};
      try {
        args = p.args.trim() ? JSON.parse(p.args) : {};
      } catch {
        args = {};
      }
      if (!args || typeof args !== "object" || Array.isArray(args)) args = {};
      return { id: p.id ?? `call_${i}`, function: { name: p.name, arguments: args } };
    });
  }
};
function fromOpenAIChoice(json) {
  const choice = Array.isArray(json.choices) ? json.choices[0] : void 0;
  const m = choice?.message ?? {};
  const out = { role: "assistant", content: typeof m.content === "string" ? m.content : "" };
  if (typeof m.reasoning_content === "string" && m.reasoning_content) out.thinking = m.reasoning_content;
  const acc = new ToolCallAccumulator();
  acc.add(m.tool_calls);
  const calls = acc.calls();
  if (calls.length) out.tool_calls = calls;
  return out;
}
function openAIOptions(options = {}) {
  const out = {};
  if (options.temperature !== void 0) out.temperature = options.temperature;
  if (options.top_p !== void 0) out.top_p = options.top_p;
  if (options.presence_penalty !== void 0) out.presence_penalty = options.presence_penalty;
  if (options.num_predict !== void 0) out.max_tokens = options.num_predict;
  if (options.top_k !== void 0) out.top_k = options.top_k;
  return out;
}
function modelIds(json) {
  return Array.isArray(json.data) ? json.data.map((m) => typeof m.id === "string" ? m.id : "").filter(Boolean) : [];
}
function embeddingVectors(json, count) {
  if (!Array.isArray(json.data)) return null;
  const rows = json.data.slice().sort((a, b) => (a.index ?? 0) - (b.index ?? 0));
  const vecs = rows.map((r) => r.embedding).filter((e) => Array.isArray(e));
  return vecs.length === count ? vecs : null;
}

// src/ollama.ts
var OllamaError = class extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
    this.name = "OllamaError";
  }
};
var streamingFetch = (...args) => window.fetch(...args);
var OllamaClient = class {
  constructor(getBaseUrl, fetchImpl = streamingFetch, fallbackPost, plainRequest, getProvider = () => ({ kind: "ollama" })) {
    this.getBaseUrl = getBaseUrl;
    this.fetchImpl = fetchImpl;
    this.fallbackPost = fallbackPost;
    this.plainRequest = plainRequest;
    this.getProvider = getProvider;
  }
  get baseUrl() {
    return this.getBaseUrl().replace(/\/+$/, "");
  }
  /** "ollama" or "openai" (an OpenAI-compatible server: LM Studio, llama.cpp, Jan, vLLM). */
  get provider() {
    return this.getProvider().kind;
  }
  headers() {
    const key = this.getProvider().apiKey?.trim();
    return key ? { Authorization: `Bearer ${key}` } : {};
  }
  async version() {
    if (this.provider === "openai") {
      await this.openAIModels();
      return "OpenAI-compatible";
    }
    const res = await this.get("/api/version");
    return typeof res.version === "string" ? res.version : "unknown";
  }
  /**
   * `/models` of an OpenAI-compatible server. A 2xx reply that is not a model list (some other
   * route or server answering, typically a URL without /v1) is an error, not "0 models".
   */
  async openAIModels() {
    const res = await this.get("/models");
    if (!Array.isArray(res.data)) throw new OllamaError(`${this.baseUrl} did not return a model list. Does the URL end in /v1?`);
    return res;
  }
  async listModels() {
    if (this.provider === "openai") return modelIds(await this.openAIModels()).map((name) => ({ name, size: 0 }));
    const res = await this.get("/api/tags");
    const models = Array.isArray(res.models) ? res.models : [];
    return models.map((m) => {
      const details = m.details ?? {};
      return {
        name: String(m.name),
        size: Number(m.size ?? 0),
        parameterSize: typeof details.parameter_size === "string" ? details.parameter_size : void 0,
        capabilities: Array.isArray(m.capabilities) ? m.capabilities : void 0
      };
    });
  }
  /** Models Ollama currently has loaded, with how much of each sits on the GPU. */
  async ps() {
    if (this.provider === "openai") return [];
    const res = await this.get("/api/ps");
    const models = Array.isArray(res.models) ? res.models : [];
    return models.map((m) => ({
      name: typeof m.name === "string" ? m.name : typeof m.model === "string" ? m.model : "",
      size: Number(m.size ?? 0),
      sizeVram: Number(m.size_vram ?? 0),
      contextLength: typeof m.context_length === "number" ? m.context_length : void 0
    }));
  }
  /** Returns capability tags for a model ("tools", "thinking", "embedding", ...). */
  async showCapabilities(model) {
    if (this.provider === "openai") return ["completion", "tools"];
    const res = await this.post("/api/show", { model });
    return Array.isArray(res.capabilities) ? res.capabilities : [];
  }
  async embed(model, inputs, signal) {
    if (inputs.length === 0) return [];
    if (this.provider === "openai") {
      const vecs = embeddingVectors(await this.post("/embeddings", { model, input: inputs }, signal), inputs.length);
      if (!vecs) throw new OllamaError("The server returned an unexpected embeddings payload");
      return vecs;
    }
    const res = await this.post("/api/embed", { model, input: inputs }, signal);
    const embeddings = res.embeddings;
    if (!Array.isArray(embeddings) || embeddings.length !== inputs.length) {
      throw new OllamaError("Ollama returned an unexpected embeddings payload");
    }
    return embeddings;
  }
  async chat(req) {
    if (this.provider === "openai") {
      try {
        return await this.chatOpenAI(req);
      } catch (err) {
        if (req.format && err instanceof OllamaError && err.status === 400 && /response_format/i.test(err.message)) {
          return this.chatOpenAI({ ...req, format: void 0 });
        }
        throw err;
      }
    }
    const body = {
      model: req.model,
      messages: req.messages.map(toWireMessage),
      stream: true,
      options: req.options ?? {}
    };
    if (req.tools && req.tools.length > 0) body.tools = req.tools;
    if (req.think !== void 0) body.think = req.think;
    if (req.keep_alive) body.keep_alive = req.keep_alive;
    if (req.format) body.format = req.format;
    const url = `${this.baseUrl}/api/chat`;
    let response;
    try {
      response = await this.fetchImpl(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: req.signal
      });
    } catch (err) {
      if (req.signal?.aborted) throw err;
      if (this.fallbackPost) {
        body.stream = false;
        let r;
        try {
          r = await abortable(this.fallbackPost(url, JSON.stringify(body)), req.signal);
        } catch (e) {
          if (req.signal?.aborted) throw e;
          throw new OllamaError(`Cannot reach Ollama at ${this.baseUrl}. Is it running? (${e.message})`);
        }
        if (r.status >= 400) throw new OllamaError(extractError(r.text, r.status), r.status);
        const json = JSON.parse(r.text);
        const message2 = fromWireMessage(json.message ?? {});
        req.onDelta?.({ content: message2.content, thinking: message2.thinking });
        return {
          message: message2,
          doneReason: typeof json.done_reason === "string" ? json.done_reason : void 0,
          promptTokens: typeof json.prompt_eval_count === "number" ? json.prompt_eval_count : void 0,
          completionTokens: typeof json.eval_count === "number" ? json.eval_count : void 0,
          ...durations(json)
        };
      }
      throw new OllamaError(
        `Cannot reach Ollama at ${this.baseUrl}. Is it running? (${err.message})`
      );
    }
    if (!response.ok) {
      const text = await response.text();
      throw new OllamaError(extractError(text, response.status), response.status);
    }
    if (!response.body) throw new OllamaError("Ollama returned an empty response body");
    const message = { role: "assistant", content: "" };
    let thinking = "";
    const toolCalls = [];
    let doneReason;
    let promptTokens;
    let completionTokens;
    let timing = {};
    for await (const chunk of ndjson(response.body, req.signal)) {
      if (chunk.error) {
        throw new OllamaError(typeof chunk.error === "string" ? chunk.error : JSON.stringify(chunk.error));
      }
      const m = chunk.message ?? {};
      if (typeof m.content === "string" && m.content.length > 0) {
        message.content += m.content;
        req.onDelta?.({ content: m.content });
      }
      if (typeof m.thinking === "string" && m.thinking.length > 0) {
        thinking += m.thinking;
        req.onDelta?.({ thinking: m.thinking });
      }
      if (Array.isArray(m.tool_calls)) {
        for (const tc of m.tool_calls) {
          const call = normalizeToolCall(tc);
          if (call) toolCalls.push(call);
        }
      }
      if (chunk.done) {
        doneReason = chunk.done_reason;
        promptTokens = chunk.prompt_eval_count;
        completionTokens = chunk.eval_count;
        timing = durations(chunk);
      }
    }
    if (thinking) message.thinking = thinking;
    if (toolCalls.length) message.tool_calls = toolCalls;
    return { message, doneReason, promptTokens, completionTokens, ...timing };
  }
  /**
   * Downloads a model into Ollama (`/api/pull`), reporting progress as a fraction (0–1, or null while
   * the size is not known yet) and the status line Ollama sends.
   */
  async pull(model, onProgress, signal) {
    if (this.provider !== "ollama") throw new OllamaError("Downloading models works with Ollama only; load the model in your server's own app.");
    let response;
    try {
      response = await this.fetchImpl(`${this.baseUrl}/api/pull`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model, stream: true }), signal });
    } catch (err) {
      if (signal?.aborted) throw err;
      throw new OllamaError(`Cannot reach Ollama at ${this.baseUrl}. Is it running? (${err.message})`);
    }
    if (!response.ok) throw new OllamaError(extractError(await response.text(), response.status), response.status);
    if (!response.body) throw new OllamaError("Ollama returned an empty response body");
    for await (const chunk of ndjson(response.body, signal)) {
      if (chunk.error) throw new OllamaError(typeof chunk.error === "string" ? chunk.error : JSON.stringify(chunk.error));
      const total = typeof chunk.total === "number" ? chunk.total : 0;
      const done = typeof chunk.completed === "number" ? chunk.completed : 0;
      onProgress(total > 0 ? Math.min(1, done / total) : null, typeof chunk.status === "string" ? chunk.status : "");
    }
  }
  /** Chat through `/v1/chat/completions`, streamed (server-sent events), with tool calls. */
  async chatOpenAI(req) {
    const body = {
      model: req.model,
      messages: toOpenAIMessages(req.messages),
      stream: true,
      stream_options: { include_usage: true },
      ...openAIOptions(req.options)
    };
    if (req.tools?.length) body.tools = req.tools;
    if (req.format === "json") body.response_format = { type: "json_object" };
    const url = `${this.baseUrl}/chat/completions`;
    const headers = { "Content-Type": "application/json", ...this.headers() };
    let response;
    try {
      response = await this.fetchImpl(url, { method: "POST", headers, body: JSON.stringify(body), signal: req.signal });
    } catch (err) {
      if (req.signal?.aborted) throw err;
      if (this.plainRequest || this.fallbackPost) {
        body.stream = false;
        delete body.stream_options;
        const payload = JSON.stringify(body);
        let r;
        try {
          r = await abortable(this.plainRequest ? this.plainRequest(url, "POST", payload, this.headers()) : this.fallbackPost(url, payload), req.signal);
        } catch (e) {
          if (req.signal?.aborted) throw e;
          throw new OllamaError(`Cannot reach the server at ${this.baseUrl}. Is it running? (${e.message})`);
        }
        if (r.status >= 400) throw new OllamaError(extractError(r.text, r.status), r.status);
        return wholeOpenAIReply(parseJsonBody(r.text), req);
      }
      throw new OllamaError(`Cannot reach the server at ${this.baseUrl}. Is it running? (${err.message})`);
    }
    if (!response.ok) throw new OllamaError(extractError(await response.text(), response.status), response.status);
    if (!response.body) throw new OllamaError("The server returned an empty response body");
    if ((response.headers.get("content-type") ?? "").includes("application/json")) return wholeOpenAIReply(parseJsonBody(await response.text()), req);
    const message = { role: "assistant", content: "" };
    let thinking = "";
    const calls = new ToolCallAccumulator();
    let doneReason;
    let promptTokens;
    let completionTokens;
    for await (const chunk of sse(response.body, req.signal)) {
      if (chunk.error) throw new OllamaError(typeof chunk.error === "string" ? chunk.error : JSON.stringify(chunk.error));
      const choice = Array.isArray(chunk.choices) ? chunk.choices[0] : void 0;
      const d = choice?.delta ?? {};
      if (typeof d.content === "string" && d.content) {
        message.content += d.content;
        req.onDelta?.({ content: d.content });
      }
      if (typeof d.reasoning_content === "string" && d.reasoning_content) {
        thinking += d.reasoning_content;
        req.onDelta?.({ thinking: d.reasoning_content });
      }
      calls.add(d.tool_calls);
      if (typeof choice?.finish_reason === "string") doneReason = choice.finish_reason;
      const usage = chunk.usage;
      if (usage) {
        promptTokens = usage.prompt_tokens;
        completionTokens = usage.completion_tokens;
      }
    }
    if (thinking) message.thinking = thinking;
    const toolCalls = calls.calls();
    if (toolCalls.length) message.tool_calls = toolCalls;
    return { message, doneReason, promptTokens, completionTokens };
  }
  async get(path) {
    const url = `${this.baseUrl}${path}`;
    if (this.plainRequest) return this.viaPlain(url, "GET");
    try {
      const res = await this.fetchImpl(url, { headers: this.headers() });
      if (!res.ok) throw new OllamaError(extractError(await res.text(), res.status), res.status);
      return await res.json();
    } catch (err) {
      if (err instanceof OllamaError) throw err;
      if (this.fallbackPost) {
        const r = await this.fallbackPost(url, "");
        if (r.status >= 400) throw new OllamaError(extractError(r.text, r.status), r.status);
        return JSON.parse(r.text);
      }
      throw new OllamaError(
        `Cannot reach Ollama at ${this.baseUrl}. Is it running? (${err.message})`
      );
    }
  }
  async post(path, body, signal) {
    const url = `${this.baseUrl}${path}`;
    const payload = JSON.stringify(body);
    if (this.plainRequest) return this.viaPlain(url, "POST", payload);
    try {
      const res = await this.fetchImpl(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...this.headers() },
        body: payload,
        signal
      });
      if (!res.ok) throw new OllamaError(extractError(await res.text(), res.status), res.status);
      return await res.json();
    } catch (err) {
      if (err instanceof OllamaError) throw err;
      if (signal?.aborted) throw err;
      if (this.fallbackPost) {
        const r = await this.fallbackPost(url, payload);
        if (r.status >= 400) throw new OllamaError(extractError(r.text, r.status), r.status);
        return JSON.parse(r.text);
      }
      throw new OllamaError(
        `Cannot reach Ollama at ${this.baseUrl}. Is it running? (${err.message})`
      );
    }
  }
  async viaPlain(url, method, body) {
    let r;
    try {
      r = await this.plainRequest(url, method, body, this.headers());
    } catch (err) {
      throw new OllamaError(`Cannot reach ${this.baseUrl}. Is it running? (${err.message})`);
    }
    if (r.status >= 400) throw new OllamaError(extractError(r.text, r.status), r.status);
    return parseJsonBody(r.text);
  }
};
function parseJsonBody(text) {
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new OllamaError(`Unexpected reply from the server: ${text.slice(0, 200)}`);
  }
  if (json && typeof json === "object" && json.error) {
    const e = json.error;
    throw new OllamaError(typeof e === "string" ? e : typeof e.message === "string" ? e.message : JSON.stringify(e));
  }
  return json;
}
function wholeOpenAIReply(json, req) {
  const message = fromOpenAIChoice(json);
  req.onDelta?.({ content: message.content, thinking: message.thinking });
  const usage = json.usage ?? {};
  return { message, promptTokens: usage.prompt_tokens, completionTokens: usage.completion_tokens };
}
function abortable(p, signal) {
  if (!signal) return p;
  return new Promise((resolve, reject) => {
    const onAbort = () => reject(new DOMException("Aborted", "AbortError"));
    if (signal.aborted) {
      p.catch(() => {
      });
      onAbort();
      return;
    }
    signal.addEventListener("abort", onAbort, { once: true });
    p.then(resolve, reject).finally(() => signal.removeEventListener("abort", onAbort));
  });
}
function durations(chunk) {
  const num = (k) => {
    const v = chunk[k];
    return typeof v === "number" ? v : void 0;
  };
  const out = {};
  const load = num("load_duration");
  const prompt = num("prompt_eval_duration");
  const evalD = num("eval_duration");
  if (load !== void 0) out.loadDuration = load;
  if (prompt !== void 0) out.promptEvalDuration = prompt;
  if (evalD !== void 0) out.evalDuration = evalD;
  return out;
}
function toWireMessage(m) {
  const out = { role: m.role, content: m.content };
  if (m.thinking) out.thinking = m.thinking;
  if (m.tool_calls?.length) out.tool_calls = m.tool_calls;
  if (m.role === "tool" && m.tool_name) out.tool_name = m.tool_name;
  if (m.images?.length) out.images = m.images;
  return out;
}
function fromWireMessage(m) {
  const out = {
    role: "assistant",
    content: typeof m.content === "string" ? m.content : ""
  };
  if (typeof m.thinking === "string" && m.thinking) out.thinking = m.thinking;
  if (Array.isArray(m.tool_calls)) {
    const calls = m.tool_calls.map(normalizeToolCall).filter((c) => c !== null);
    if (calls.length) out.tool_calls = calls;
  }
  return out;
}
function normalizeToolCall(raw) {
  const fn = raw.function ?? raw;
  const name = fn.name;
  if (typeof name !== "string" || !name) return null;
  let args = fn.arguments;
  if (typeof args === "string") {
    try {
      args = JSON.parse(args);
    } catch {
      args = {};
    }
  }
  if (!args || typeof args !== "object" || Array.isArray(args)) args = {};
  return {
    id: typeof raw.id === "string" ? raw.id : void 0,
    function: { name, arguments: args }
  };
}
function extractError(text, status) {
  try {
    const json = JSON.parse(text);
    if (json && typeof json.error === "string") return json.error;
  } catch {
  }
  return text?.trim() ? `${status}: ${text.trim().slice(0, 300)}` : `Ollama returned HTTP ${status}`;
}
async function* ndjson(body, signal) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    while (true) {
      if (signal?.aborted) {
        await reader.cancel();
        throw new DOMException("Aborted", "AbortError");
      }
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let idx;
      while ((idx = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx + 1);
        if (!line) continue;
        yield JSON.parse(line);
      }
    }
    const rest = buffer.trim();
    if (rest) yield JSON.parse(rest);
  } finally {
    reader.releaseLock();
  }
}
function canonicalModelName(name) {
  const n = name.trim().toLowerCase();
  return n.endsWith(":latest") ? n.slice(0, -":latest".length) : n;
}
function sameModel(a, b) {
  return canonicalModelName(a) === canonicalModelName(b);
}
function placementWarning(running, model) {
  const m = running.find((r) => sameModel(r.name, model));
  if (!m || m.size <= 0 || m.sizeVram >= m.size * 0.98) return void 0;
  const gb2 = (n) => (n / 1e9).toFixed(1);
  const ctx = m.contextLength ? ` at a ${Math.round(m.contextLength / 1024)}k context` : "";
  return `${model} is only partly on the GPU (${gb2(m.sizeVram)} of ${gb2(m.size)} GB${ctx}); the rest runs from system RAM, several times slower. Lower the context window in settings (32768, or 16384 on an 8 GB card) or pick a smaller model such as qwen3.5:4b.`;
}

// src/chunker.ts
var DEFAULTS = { target: 1400, max: 2200 };
function stripFrontmatter(content) {
  const m = content.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (!m) return { frontmatter: "", body: content };
  return { frontmatter: m[1], body: content.slice(m[0].length) };
}
function chunkMarkdown(content, opts = {}) {
  const { target, max } = { ...DEFAULTS, ...opts };
  const { body } = stripFrontmatter(content);
  const lines = body.split(/\r?\n/);
  const sections = [{ heading: "", lines: [] }];
  let inFence = false;
  for (const line of lines) {
    if (/^\s*(```|~~~)/.test(line)) inFence = !inFence;
    const h = !inFence && line.match(/^(#{1,6})\s+(.+?)\s*#*\s*$/);
    if (h) {
      sections.push({ heading: h[2].trim(), lines: [] });
    } else {
      sections[sections.length - 1].lines.push(line);
    }
  }
  const chunks = [];
  for (const section of sections) {
    const text = section.lines.join("\n").trim();
    if (!text) continue;
    const paragraphs2 = text.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
    let current2 = "";
    const flush = () => {
      if (current2.trim()) chunks.push({ heading: section.heading, text: current2.trim() });
      current2 = "";
    };
    for (const para of paragraphs2) {
      const pieces = para.length > max ? splitLong(para, max) : [para];
      for (const piece of pieces) {
        if (current2 && current2.length + piece.length + 2 > target) flush();
        current2 = current2 ? `${current2}

${piece}` : piece;
      }
    }
    flush();
  }
  return chunks;
}
function splitSentences(text) {
  const out = [];
  let start = 0;
  const re = /[.!?]+\s+/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    out.push(text.slice(start, m.index + m[0].length).trimEnd());
    start = m.index + m[0].length;
  }
  if (start < text.length) out.push(text.slice(start));
  return out.filter((s) => s.length > 0);
}
function splitLong(text, max) {
  const out = [];
  const sentences = splitSentences(text);
  let current2 = "";
  for (const s of sentences) {
    if (s.length > max) {
      if (current2) out.push(current2);
      current2 = "";
      for (let i = 0; i < s.length; i += max) out.push(s.slice(i, i + max));
      continue;
    }
    if (current2 && current2.length + s.length + 1 > max) {
      out.push(current2);
      current2 = s;
    } else {
      current2 = current2 ? `${current2} ${s}` : s;
    }
  }
  if (current2) out.push(current2);
  return out;
}

// src/citations.ts
var BLOCK_ID = /\s\^([A-Za-z0-9-]+)\s*$/;
var TIMESTAMP_START = /^\s*(?:\*\*)?\[(\d{1,2}:\d{2}(?::\d{2})?)\](?:\*\*)?/;
var LIST_ITEM = /^\s*(?:[-*+]|\d+[.)])\s/;
function paragraphs(content) {
  const lines = content.split("\n");
  const out = [];
  let heading = null;
  let i = 0;
  if (/^---\r?$/.test(lines[0] ?? "")) {
    const close = lines.findIndex((l, j) => j > 0 && /^---\r?$/.test(l));
    if (close > 0) i = close + 1;
  }
  let fence = null;
  let cur = null;
  const flush = (end) => {
    if (!cur) return;
    const raw = cur.lines.join("\n").replace(/\r/g, "");
    const id = BLOCK_ID.exec(cur.lines[cur.lines.length - 1].replace(/\r$/, ""));
    const text = id ? raw.replace(BLOCK_ID, "").trimEnd() : raw.trimEnd();
    if (text.trim()) out.push({ start: cur.start, end, text, heading, blockId: id ? id[1] : null, timestamp: TIMESTAMP_START.exec(text)?.[1] ?? null });
    cur = null;
  };
  for (; i < lines.length; i++) {
    const line = lines[i].replace(/\r$/, "");
    const f = /^\s*(```|~~~)/.exec(line);
    if (fence) {
      if (f && f[1] === fence) fence = null;
      continue;
    }
    if (f) {
      flush(i - 1);
      fence = f[1];
      continue;
    }
    const h = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(line);
    if (h) {
      flush(i - 1);
      heading = h[2].trim();
      continue;
    }
    if (!line.trim() || /^\s*\|/.test(line) || /^\s*\^[A-Za-z0-9-]+\s*$/.test(line)) {
      flush(i - 1);
      continue;
    }
    if (cur && (LIST_ITEM.test(line) || TIMESTAMP_START.test(line))) flush(i - 1);
    if (!cur) cur = { start: i, lines: [] };
    cur.lines.push(line);
  }
  flush(lines.length - 1);
  return out;
}
function plainText(s) {
  return s.replace(/^\s*>\s?/gm, "").replace(/\*\*|__|[*_`"“”]/g, "").replace(/\s+/g, " ").trim().toLowerCase();
}
function quotable(answer) {
  const out = [];
  for (const m of answer.matchAll(/["“]([^"”\n]{20,})["”]/g)) out.push(plainText(m[1]));
  for (const line of answer.split("\n")) {
    const plain = plainText(line.replace(/^\s*(?:[-*+]|\d+\.)\s+/, ""));
    for (const sentence of splitSentences(plain)) if (sentence.length >= 30) out.push(sentence);
  }
  return out;
}
function timestampSeconds(raw) {
  const m = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/.exec(raw.trim());
  if (!m) return null;
  return m[3] === void 0 ? Number(m[1]) * 60 + Number(m[2]) : Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
}
function contentWords(text) {
  return new Set((plainText(text).match(/[\p{L}\p{N}]{5,}/gu) ?? []).filter((w) => !/^\d+$/.test(w)));
}
function matchPassages(answer, content, max = 3) {
  const paras = paragraphs(content).filter((p) => p.text.length >= 20);
  if (paras.length === 0 || !answer.trim()) return [];
  const plains = paras.map((p) => plainText(p.text));
  const chosen = /* @__PURE__ */ new Set();
  for (const f of quotable(answer)) {
    const i = plains.findIndex((p) => p.includes(f));
    if (i >= 0) chosen.add(i);
  }
  const stamps = /* @__PURE__ */ new Set();
  for (const m of answer.matchAll(/(^|[^\d:])(\d{1,2}:\d{2}(?::\d{2})?)(?![\d:])/g)) {
    const s = timestampSeconds(m[2]);
    if (s !== null) stamps.add(s);
  }
  if (stamps.size) {
    paras.forEach((p, i) => {
      const s = p.timestamp ? timestampSeconds(p.timestamp) : null;
      if (s !== null && stamps.has(s)) chosen.add(i);
    });
  }
  if (chosen.size === 0) {
    const paraWords = paras.map((p) => contentWords(p.text));
    for (const line of answer.split("\n")) {
      for (const sentence of splitSentences(line)) {
        const words = contentWords(sentence);
        if (words.size < 4) continue;
        let best = -1;
        let bestShared = 0;
        paraWords.forEach((pw, i) => {
          let shared = 0;
          for (const w of words) if (pw.has(w)) shared++;
          if (shared > bestShared) {
            bestShared = shared;
            best = i;
          }
        });
        if (best >= 0 && bestShared >= 4 && bestShared / words.size >= 0.6) chosen.add(best);
      }
    }
  }
  return Array.from(chosen).sort((a, b) => a - b).slice(0, max).map((i) => paras[i]);
}
function blockIds(content) {
  const out = /* @__PURE__ */ new Set();
  for (const m of content.matchAll(/(?:^|\s)\^([A-Za-z0-9-]+)[ \t]*\r?$/gm)) out.add(m[1]);
  return out;
}
function shortHash(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h.toString(36).padStart(6, "0").slice(0, 6);
}
function newBlockId(p, taken) {
  const base = p.timestamp ? `t${p.timestamp.replace(/:/g, "-")}` : `c${shortHash(p.text)}`;
  let id = base;
  for (let n = 2; taken.has(id); n++) id = `${base}-${n}`;
  taken.add(id);
  return id;
}
function addBlockIds(content, items) {
  const lines = content.split("\n");
  for (const { end, id } of items) {
    if (end < 0 || end >= lines.length) continue;
    const cr = lines[end].endsWith("\r") ? "\r" : "";
    lines[end] = `${lines[end].replace(/\r$/, "").trimEnd()} ^${id}${cr}`;
  }
  return lines.join("\n");
}
function headingSubpath(h) {
  return h.replace(/[#|^[\]]/g, " ").replace(/\s+/g, " ").trim();
}
function passageLink(path, p, id) {
  const target = path.replace(/\.md$/i, "");
  const name = target.split("/").pop() ?? target;
  const where = p.timestamp ?? (p.heading ? headingSubpath(p.heading) : "");
  const alias = where ? `${name} \u203A ${where}` : name;
  if (id) return `[[${target}#^${id}|${alias}]]`;
  if (p.heading && headingSubpath(p.heading)) return `[[${target}#${headingSubpath(p.heading)}|${alias}]]`;
  return `[[${target}|${alias}]]`;
}
function planCitations(answer, notes, perNote = 3) {
  const out = [];
  for (const note of notes) {
    const taken = blockIds(note.content);
    for (const p of matchPassages(answer, note.content, perNote)) {
      if (out.length >= 6) return out;
      if (p.blockId) out.push({ path: note.path, paragraph: p, id: p.blockId, isNew: false });
      else out.push({ path: note.path, paragraph: p, id: newBlockId(p, taken), isNew: true });
    }
  }
  return out;
}
function blockIdEdits(citations, contents) {
  const out = /* @__PURE__ */ new Map();
  const byNote = /* @__PURE__ */ new Map();
  for (const c of citations) if (c.isNew) byNote.set(c.path, [...byNote.get(c.path) ?? [], c]);
  for (const [path, cites] of byNote) {
    const before = contents.get(path);
    if (before === void 0) continue;
    out.set(path, addBlockIds(before, cites.map((c) => ({ end: c.paragraph.end, id: c.id }))));
  }
  return out;
}
function withPassages(answer, citations, written) {
  if (citations.length === 0) return answer;
  const links = citations.map((c) => passageLink(c.path, c.paragraph, !c.isNew || written.has(c.path) ? c.id : null));
  const unique = Array.from(new Set(links));
  return `${answer.trimEnd()}

Passages: ${unique.join(", ")}`;
}
function linkedTargets(answer) {
  const out = [];
  const prose = answer.replace(/```[\s\S]*?```/g, "").replace(/`[^`\n]*`/g, "");
  for (const m of prose.matchAll(/(!?)\[\[([^\]|#]+)(?:[#|][^\]]*)?\]\]/g)) {
    if (m[1] === "!") continue;
    const t2 = m[2].trim();
    if (t2 && !out.includes(t2)) out.push(t2);
  }
  return out;
}

// src/outline.ts
function buildOutline(vault, opts) {
  const { budgetChars, gist } = typeof opts === "number" ? { budgetChars: opts, gist: void 0 } : opts;
  const notes = vault.listNotes().slice().sort((a, b) => a.path.localeCompare(b.path));
  if (notes.length === 0) return "(the vault has no markdown notes)";
  const byRecency = notes.slice().sort((a, b) => b.mtime - a.mtime);
  const metaCache = /* @__PURE__ */ new Map();
  const metaOf = (path) => {
    let m = metaCache.get(path);
    if (!m) {
      m = vault.getMetadata(path);
      metaCache.set(path, m);
    }
    return m;
  };
  const namesAlone = notes.reduce((n, note) => n + note.basename.length + 6, 0);
  const render = (detail, limit, gistCount) => {
    const gisted = new Set(byRecency.slice(0, gistCount).map((n) => n.path));
    const lines = [];
    let folder = null;
    for (const note of notes.slice(0, limit)) {
      if (note.folder !== folder) {
        folder = note.folder;
        lines.push(folder === "" ? "/" : `${folder}/`);
      }
      let line = `  ${note.basename}.md`;
      if (detail !== "none") {
        const meta = metaOf(note.path);
        const g = detail === "gists" && gisted.has(note.path) ? gist?.(note.path) : void 0;
        if (g) {
          line += ` \u2014 ${g}`;
        } else {
          const headings = meta.headings.map((h) => h.replace(/^#+\s*/, "").trim()).filter(Boolean).slice(0, 6).map((h) => h.length > 40 ? h.slice(0, 39) + "\u2026" : h);
          if (headings.length) line += ` \u2014 ${headings.join(" \u203A ")}`;
          if (meta.headings.length > 6) line += ` (+${meta.headings.length - 6})`;
        }
        const tags = meta.tags.slice(0, 4);
        if (tags.length) line += ` ${tags.map((t2) => t2.startsWith("#") ? t2 : `#${t2}`).join(" ")}`;
      }
      lines.push(line);
    }
    if (limit < notes.length) lines.push(`\u2026and ${notes.length - limit} more notes (use list_notes or search_notes).`);
    return lines.join("\n");
  };
  const fits = (s) => s.length <= budgetChars;
  const hasGists = namesAlone <= budgetChars && gist !== void 0 && notes.some((n) => gist(n.path));
  if (hasGists) {
    const all = render("gists", notes.length, notes.length);
    if (fits(all)) return all;
    const k2 = largest(notes.length, (n) => fits(render("gists", notes.length, n)));
    if (k2 > 0) return render("gists", notes.length, k2);
  }
  if (namesAlone <= budgetChars) {
    const withHeadings = render("headings", notes.length, 0);
    if (fits(withHeadings)) return withHeadings;
    const bare = render("none", notes.length, 0);
    if (fits(bare)) return bare;
  }
  const folders = groupByFolder(notes);
  const biggest = Math.max(...folders.map((f) => f.notes.length));
  const k = largest(biggest, (n) => fits(renderFolders(folders, n)));
  const collapsed = renderFolders(folders, fits(renderFolders(folders, k)) ? k : 0);
  if (fits(collapsed)) return collapsed;
  const prefix = largest(notes.length, (n) => fits(render("none", n, 0)));
  return render("none", Math.max(prefix, 1), 0);
}
function groupByFolder(notes) {
  const groups = [];
  for (const note of notes) {
    const last = groups[groups.length - 1];
    if (last && last.folder === note.folder) last.notes.push(note);
    else groups.push({ folder: note.folder, notes: [note] });
  }
  return groups;
}
function renderFolders(folders, maxListed) {
  const lines = [];
  for (const { folder, notes } of folders) {
    const name = folder === "" ? "/" : `${folder}/`;
    if (notes.length <= Math.max(maxListed, 1)) {
      lines.push(name, ...notes.map((n) => `  ${n.basename}.md`));
    } else {
      lines.push(`${name} (${notes.length} notes, ${notes[0].basename} \u2026 ${notes[notes.length - 1].basename}; list_notes shows them)`);
    }
  }
  return lines.join("\n");
}
function largest(max, ok) {
  let lo = 0;
  let hi = max;
  while (lo < hi) {
    const mid = Math.ceil((lo + hi) / 2);
    if (ok(mid)) lo = mid;
    else hi = mid - 1;
  }
  return lo;
}
function outlineBudget(numCtx, withGists = false) {
  return Math.floor(numCtx * 3.2 * (withGists ? 0.18 : 0.12));
}

// node_modules/diff/libesm/diff/base.js
var Diff = class {
  diff(oldStr, newStr, options = {}) {
    let callback;
    if (typeof options === "function") {
      callback = options;
      options = {};
    } else if ("callback" in options) {
      callback = options.callback;
    }
    const oldString = this.castInput(oldStr, options);
    const newString = this.castInput(newStr, options);
    const oldTokens = this.removeEmpty(this.tokenize(oldString, options));
    const newTokens = this.removeEmpty(this.tokenize(newString, options));
    return this.diffWithOptionsObj(oldTokens, newTokens, options, callback);
  }
  diffWithOptionsObj(oldTokens, newTokens, options, callback) {
    var _a;
    const done = (value) => {
      value = this.postProcess(value, options);
      if (callback) {
        setTimeout(function() {
          callback(value);
        }, 0);
        return void 0;
      } else {
        return value;
      }
    };
    const newLen = newTokens.length, oldLen = oldTokens.length;
    let editLength = 1;
    let maxEditLength = newLen + oldLen;
    if (options.maxEditLength != null) {
      maxEditLength = Math.min(maxEditLength, options.maxEditLength);
    }
    const maxExecutionTime = (_a = options.timeout) !== null && _a !== void 0 ? _a : Infinity;
    const abortAfterTimestamp = Date.now() + maxExecutionTime;
    const bestPath = [{ oldPos: -1, lastComponent: void 0 }];
    let newPos = this.extractCommon(bestPath[0], newTokens, oldTokens, 0, options);
    if (bestPath[0].oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
      return done(this.buildValues(bestPath[0].lastComponent, newTokens, oldTokens));
    }
    let minDiagonalToConsider = -Infinity, maxDiagonalToConsider = Infinity;
    const execEditLength = () => {
      for (let diagonalPath = Math.max(minDiagonalToConsider, -editLength); diagonalPath <= Math.min(maxDiagonalToConsider, editLength); diagonalPath += 2) {
        let basePath;
        const removePath = bestPath[diagonalPath - 1], addPath = bestPath[diagonalPath + 1];
        if (removePath) {
          bestPath[diagonalPath - 1] = void 0;
        }
        let canAdd = false;
        if (addPath) {
          const addPathNewPos = addPath.oldPos - diagonalPath;
          canAdd = addPath && 0 <= addPathNewPos && addPathNewPos < newLen;
        }
        const canRemove = removePath && removePath.oldPos + 1 < oldLen;
        if (!canAdd && !canRemove) {
          bestPath[diagonalPath] = void 0;
          continue;
        }
        if (!canRemove || canAdd && removePath.oldPos < addPath.oldPos) {
          basePath = this.addToPath(addPath, true, false, 0, options);
        } else {
          basePath = this.addToPath(removePath, false, true, 1, options);
        }
        newPos = this.extractCommon(basePath, newTokens, oldTokens, diagonalPath, options);
        if (basePath.oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
          return done(this.buildValues(basePath.lastComponent, newTokens, oldTokens)) || true;
        } else {
          bestPath[diagonalPath] = basePath;
          if (basePath.oldPos + 1 >= oldLen) {
            maxDiagonalToConsider = Math.min(maxDiagonalToConsider, diagonalPath - 1);
          }
          if (newPos + 1 >= newLen) {
            minDiagonalToConsider = Math.max(minDiagonalToConsider, diagonalPath + 1);
          }
        }
      }
      editLength++;
    };
    if (callback) {
      (function exec() {
        setTimeout(function() {
          if (editLength > maxEditLength || Date.now() > abortAfterTimestamp) {
            return callback(void 0);
          }
          if (!execEditLength()) {
            exec();
          }
        }, 0);
      })();
    } else {
      while (editLength <= maxEditLength && Date.now() <= abortAfterTimestamp) {
        const ret = execEditLength();
        if (ret) {
          return ret;
        }
      }
    }
  }
  addToPath(path, added, removed, oldPosInc, options) {
    const last = path.lastComponent;
    if (last && !options.oneChangePerToken && last.added === added && last.removed === removed) {
      return {
        oldPos: path.oldPos + oldPosInc,
        lastComponent: { count: last.count + 1, added, removed, previousComponent: last.previousComponent }
      };
    } else {
      return {
        oldPos: path.oldPos + oldPosInc,
        lastComponent: { count: 1, added, removed, previousComponent: last }
      };
    }
  }
  extractCommon(basePath, newTokens, oldTokens, diagonalPath, options) {
    const newLen = newTokens.length, oldLen = oldTokens.length;
    let oldPos = basePath.oldPos, newPos = oldPos - diagonalPath, commonCount = 0;
    while (newPos + 1 < newLen && oldPos + 1 < oldLen && this.equals(oldTokens[oldPos + 1], newTokens[newPos + 1], options)) {
      newPos++;
      oldPos++;
      commonCount++;
      if (options.oneChangePerToken) {
        basePath.lastComponent = { count: 1, previousComponent: basePath.lastComponent, added: false, removed: false };
      }
    }
    if (commonCount && !options.oneChangePerToken) {
      basePath.lastComponent = { count: commonCount, previousComponent: basePath.lastComponent, added: false, removed: false };
    }
    basePath.oldPos = oldPos;
    return newPos;
  }
  equals(left, right, options) {
    if (options.comparator) {
      return options.comparator(left, right);
    } else {
      return left === right || !!options.ignoreCase && left.toLowerCase() === right.toLowerCase();
    }
  }
  removeEmpty(array) {
    const ret = [];
    for (let i = 0; i < array.length; i++) {
      if (array[i]) {
        ret.push(array[i]);
      }
    }
    return ret;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  castInput(value, options) {
    return value;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  tokenize(value, options) {
    return Array.from(value);
  }
  join(chars) {
    return chars.join("");
  }
  postProcess(changeObjects, options) {
    return changeObjects;
  }
  get useLongestToken() {
    return false;
  }
  buildValues(lastComponent, newTokens, oldTokens) {
    const components = [];
    let nextComponent;
    while (lastComponent) {
      components.push(lastComponent);
      nextComponent = lastComponent.previousComponent;
      delete lastComponent.previousComponent;
      lastComponent = nextComponent;
    }
    components.reverse();
    const componentLen = components.length;
    let componentPos = 0, newPos = 0, oldPos = 0;
    for (; componentPos < componentLen; componentPos++) {
      const component = components[componentPos];
      if (!component.removed) {
        if (!component.added && this.useLongestToken) {
          let value = newTokens.slice(newPos, newPos + component.count);
          value = value.map(function(value2, i) {
            const oldValue = oldTokens[oldPos + i];
            return oldValue.length > value2.length ? oldValue : value2;
          });
          component.value = this.join(value);
        } else {
          component.value = this.join(newTokens.slice(newPos, newPos + component.count));
        }
        newPos += component.count;
        if (!component.added) {
          oldPos += component.count;
        }
      } else {
        component.value = this.join(oldTokens.slice(oldPos, oldPos + component.count));
        oldPos += component.count;
      }
    }
    return components;
  }
};

// node_modules/diff/libesm/util/string.js
function hasOnlyWinLineEndings(string) {
  return string.includes("\r\n") && !string.startsWith("\n") && !string.match(/[^\r]\n/);
}
function hasOnlyUnixLineEndings(string) {
  return !string.includes("\r\n") && string.includes("\n");
}

// node_modules/diff/libesm/diff/line.js
var LineDiff = class extends Diff {
  constructor() {
    super(...arguments);
    this.tokenize = tokenize;
  }
  equals(left, right, options) {
    if (options.ignoreWhitespace) {
      if (!options.newlineIsToken || !left.includes("\n")) {
        left = left.trim();
      }
      if (!options.newlineIsToken || !right.includes("\n")) {
        right = right.trim();
      }
    } else if (options.ignoreNewlineAtEof && !options.newlineIsToken) {
      if (left.endsWith("\n")) {
        left = left.slice(0, -1);
      }
      if (right.endsWith("\n")) {
        right = right.slice(0, -1);
      }
    }
    return super.equals(left, right, options);
  }
};
var lineDiff = new LineDiff();
function diffLines(oldStr, newStr, options) {
  return lineDiff.diff(oldStr, newStr, options);
}
function tokenize(value, options) {
  if (options.stripTrailingCr) {
    value = value.replace(/\r\n/g, "\n");
  }
  const retLines = [], linesAndNewlines = value.split(/(\n|\r\n)/);
  if (!linesAndNewlines[linesAndNewlines.length - 1]) {
    linesAndNewlines.pop();
  }
  for (let i = 0; i < linesAndNewlines.length; i++) {
    const line = linesAndNewlines[i];
    if (i % 2 && !options.newlineIsToken) {
      retLines[retLines.length - 1] += line;
    } else {
      retLines.push(line);
    }
  }
  return retLines;
}

// node_modules/diff/libesm/patch/line-endings.js
function unixToWin(patch) {
  if (Array.isArray(patch)) {
    return patch.map((p) => unixToWin(p));
  }
  return Object.assign(Object.assign({}, patch), { hunks: patch.hunks.map((hunk) => Object.assign(Object.assign({}, hunk), { lines: hunk.lines.map((line, i) => {
    var _a;
    return line.startsWith("\\") || line.endsWith("\r") || ((_a = hunk.lines[i + 1]) === null || _a === void 0 ? void 0 : _a.startsWith("\\")) ? line : line + "\r";
  }) })) });
}
function winToUnix(patch) {
  if (Array.isArray(patch)) {
    return patch.map((p) => winToUnix(p));
  }
  return Object.assign(Object.assign({}, patch), { hunks: patch.hunks.map((hunk) => Object.assign(Object.assign({}, hunk), { lines: hunk.lines.map((line) => line.endsWith("\r") ? line.substring(0, line.length - 1) : line) })) });
}
function isUnix(patch) {
  if (!Array.isArray(patch)) {
    patch = [patch];
  }
  return !patch.some((index) => index.hunks.some((hunk) => hunk.lines.some((line) => !line.startsWith("\\") && line.endsWith("\r"))));
}
function isWin(patch) {
  if (!Array.isArray(patch)) {
    patch = [patch];
  }
  return patch.some((index) => index.hunks.some((hunk) => hunk.lines.some((line) => line.endsWith("\r")))) && patch.every((index) => index.hunks.every((hunk) => hunk.lines.every((line, i) => {
    var _a;
    return line.startsWith("\\") || line.endsWith("\r") || ((_a = hunk.lines[i + 1]) === null || _a === void 0 ? void 0 : _a.startsWith("\\"));
  })));
}

// node_modules/diff/libesm/patch/parse.js
function parsePatch(uniDiff) {
  const diffstr = uniDiff.split(/\n/), list = [];
  let i = 0;
  function parseIndex() {
    const index = {};
    list.push(index);
    while (i < diffstr.length) {
      const line = diffstr[i];
      if (/^(---|\+\+\+|@@)\s/.test(line)) {
        break;
      }
      const headerMatch = /^(?:Index:|diff(?: -r \w+)+)\s+/.exec(line);
      if (headerMatch) {
        index.index = line.substring(headerMatch[0].length).trim();
      }
      i++;
    }
    parseFileHeader(index);
    parseFileHeader(index);
    index.hunks = [];
    while (i < diffstr.length) {
      const line = diffstr[i];
      if (/^(Index:\s|diff\s|---\s|\+\+\+\s|===================================================================)/.test(line)) {
        break;
      } else if (/^@@/.test(line)) {
        index.hunks.push(parseHunk());
      } else if (line) {
        throw new Error("Unknown line " + (i + 1) + " " + JSON.stringify(line));
      } else {
        i++;
      }
    }
  }
  function parseFileHeader(index) {
    const fileHeaderMatch = /^(---|\+\+\+)\s+/.exec(diffstr[i]);
    if (fileHeaderMatch) {
      const prefix = fileHeaderMatch[1], data = diffstr[i].substring(3).trim().split("	", 2), header = (data[1] || "").trim();
      let fileName = data[0].replace(/\\\\/g, "\\");
      if (fileName.startsWith('"') && fileName.endsWith('"')) {
        fileName = fileName.substr(1, fileName.length - 2);
      }
      if (prefix === "---") {
        index.oldFileName = fileName;
        index.oldHeader = header;
      } else {
        index.newFileName = fileName;
        index.newHeader = header;
      }
      i++;
    }
  }
  function parseHunk() {
    var _a;
    const chunkHeaderIndex = i, chunkHeaderLine = diffstr[i++], chunkHeader = chunkHeaderLine.split(/@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
    const hunk = {
      oldStart: +chunkHeader[1],
      oldLines: typeof chunkHeader[2] === "undefined" ? 1 : +chunkHeader[2],
      newStart: +chunkHeader[3],
      newLines: typeof chunkHeader[4] === "undefined" ? 1 : +chunkHeader[4],
      lines: []
    };
    if (hunk.oldLines === 0) {
      hunk.oldStart += 1;
    }
    if (hunk.newLines === 0) {
      hunk.newStart += 1;
    }
    let addCount = 0, removeCount = 0;
    for (; i < diffstr.length && (removeCount < hunk.oldLines || addCount < hunk.newLines || ((_a = diffstr[i]) === null || _a === void 0 ? void 0 : _a.startsWith("\\"))); i++) {
      const operation = diffstr[i].length == 0 && i != diffstr.length - 1 ? " " : diffstr[i][0];
      if (operation === "+" || operation === "-" || operation === " " || operation === "\\") {
        hunk.lines.push(diffstr[i]);
        if (operation === "+") {
          addCount++;
        } else if (operation === "-") {
          removeCount++;
        } else if (operation === " ") {
          addCount++;
          removeCount++;
        }
      } else {
        throw new Error(`Hunk at line ${chunkHeaderIndex + 1} contained invalid line ${diffstr[i]}`);
      }
    }
    if (!addCount && hunk.newLines === 1) {
      hunk.newLines = 0;
    }
    if (!removeCount && hunk.oldLines === 1) {
      hunk.oldLines = 0;
    }
    if (addCount !== hunk.newLines) {
      throw new Error("Added line count did not match for hunk at line " + (chunkHeaderIndex + 1));
    }
    if (removeCount !== hunk.oldLines) {
      throw new Error("Removed line count did not match for hunk at line " + (chunkHeaderIndex + 1));
    }
    return hunk;
  }
  while (i < diffstr.length) {
    parseIndex();
  }
  return list;
}

// node_modules/diff/libesm/util/distance-iterator.js
function distance_iterator_default(start, minLine, maxLine) {
  let wantForward = true, backwardExhausted = false, forwardExhausted = false, localOffset = 1;
  return function iterator() {
    if (wantForward && !forwardExhausted) {
      if (backwardExhausted) {
        localOffset++;
      } else {
        wantForward = false;
      }
      if (start + localOffset <= maxLine) {
        return start + localOffset;
      }
      forwardExhausted = true;
    }
    if (!backwardExhausted) {
      if (!forwardExhausted) {
        wantForward = true;
      }
      if (minLine <= start - localOffset) {
        return start - localOffset++;
      }
      backwardExhausted = true;
      return iterator();
    }
    return void 0;
  };
}

// node_modules/diff/libesm/patch/apply.js
function applyPatch(source, patch, options = {}) {
  let patches;
  if (typeof patch === "string") {
    patches = parsePatch(patch);
  } else if (Array.isArray(patch)) {
    patches = patch;
  } else {
    patches = [patch];
  }
  if (patches.length > 1) {
    throw new Error("applyPatch only works with a single input.");
  }
  return applyStructuredPatch(source, patches[0], options);
}
function applyStructuredPatch(source, patch, options = {}) {
  if (options.autoConvertLineEndings || options.autoConvertLineEndings == null) {
    if (hasOnlyWinLineEndings(source) && isUnix(patch)) {
      patch = unixToWin(patch);
    } else if (hasOnlyUnixLineEndings(source) && isWin(patch)) {
      patch = winToUnix(patch);
    }
  }
  const lines = source.split("\n"), hunks = patch.hunks, compareLine = options.compareLine || ((lineNumber, line, operation, patchContent) => line === patchContent), fuzzFactor = options.fuzzFactor || 0;
  let minLine = 0;
  if (fuzzFactor < 0 || !Number.isInteger(fuzzFactor)) {
    throw new Error("fuzzFactor must be a non-negative integer");
  }
  if (!hunks.length) {
    return source;
  }
  let prevLine = "", removeEOFNL = false, addEOFNL = false;
  for (let i = 0; i < hunks[hunks.length - 1].lines.length; i++) {
    const line = hunks[hunks.length - 1].lines[i];
    if (line[0] == "\\") {
      if (prevLine[0] == "+") {
        removeEOFNL = true;
      } else if (prevLine[0] == "-") {
        addEOFNL = true;
      }
    }
    prevLine = line;
  }
  if (removeEOFNL) {
    if (addEOFNL) {
      if (!fuzzFactor && lines[lines.length - 1] == "") {
        return false;
      }
    } else if (lines[lines.length - 1] == "") {
      lines.pop();
    } else if (!fuzzFactor) {
      return false;
    }
  } else if (addEOFNL) {
    if (lines[lines.length - 1] != "") {
      lines.push("");
    } else if (!fuzzFactor) {
      return false;
    }
  }
  function applyHunk(hunkLines, toPos, maxErrors, hunkLinesI = 0, lastContextLineMatched = true, patchedLines = [], patchedLinesLength = 0) {
    let nConsecutiveOldContextLines = 0;
    let nextContextLineMustMatch = false;
    for (; hunkLinesI < hunkLines.length; hunkLinesI++) {
      const hunkLine = hunkLines[hunkLinesI], operation = hunkLine.length > 0 ? hunkLine[0] : " ", content = hunkLine.length > 0 ? hunkLine.substr(1) : hunkLine;
      if (operation === "-") {
        if (compareLine(toPos + 1, lines[toPos], operation, content)) {
          toPos++;
          nConsecutiveOldContextLines = 0;
        } else {
          if (!maxErrors || lines[toPos] == null) {
            return null;
          }
          patchedLines[patchedLinesLength] = lines[toPos];
          return applyHunk(hunkLines, toPos + 1, maxErrors - 1, hunkLinesI, false, patchedLines, patchedLinesLength + 1);
        }
      }
      if (operation === "+") {
        if (!lastContextLineMatched) {
          return null;
        }
        patchedLines[patchedLinesLength] = content;
        patchedLinesLength++;
        nConsecutiveOldContextLines = 0;
        nextContextLineMustMatch = true;
      }
      if (operation === " ") {
        nConsecutiveOldContextLines++;
        patchedLines[patchedLinesLength] = lines[toPos];
        if (compareLine(toPos + 1, lines[toPos], operation, content)) {
          patchedLinesLength++;
          lastContextLineMatched = true;
          nextContextLineMustMatch = false;
          toPos++;
        } else {
          if (nextContextLineMustMatch || !maxErrors) {
            return null;
          }
          return lines[toPos] && (applyHunk(hunkLines, toPos + 1, maxErrors - 1, hunkLinesI + 1, false, patchedLines, patchedLinesLength + 1) || applyHunk(hunkLines, toPos + 1, maxErrors - 1, hunkLinesI, false, patchedLines, patchedLinesLength + 1)) || applyHunk(hunkLines, toPos, maxErrors - 1, hunkLinesI + 1, false, patchedLines, patchedLinesLength);
        }
      }
    }
    patchedLinesLength -= nConsecutiveOldContextLines;
    toPos -= nConsecutiveOldContextLines;
    patchedLines.length = patchedLinesLength;
    return {
      patchedLines,
      oldLineLastI: toPos - 1
    };
  }
  const resultLines = [];
  let prevHunkOffset = 0;
  for (let i = 0; i < hunks.length; i++) {
    const hunk = hunks[i];
    let hunkResult;
    const maxLine = lines.length - hunk.oldLines + fuzzFactor;
    let toPos;
    for (let maxErrors = 0; maxErrors <= fuzzFactor; maxErrors++) {
      toPos = hunk.oldStart + prevHunkOffset - 1;
      const iterator = distance_iterator_default(toPos, minLine, maxLine);
      for (; toPos !== void 0; toPos = iterator()) {
        hunkResult = applyHunk(hunk.lines, toPos, maxErrors);
        if (hunkResult) {
          break;
        }
      }
      if (hunkResult) {
        break;
      }
    }
    if (!hunkResult) {
      return false;
    }
    for (let i2 = minLine; i2 < toPos; i2++) {
      resultLines.push(lines[i2]);
    }
    for (let i2 = 0; i2 < hunkResult.patchedLines.length; i2++) {
      const line = hunkResult.patchedLines[i2];
      resultLines.push(line);
    }
    minLine = hunkResult.oldLineLastI + 1;
    prevHunkOffset = toPos + 1 - hunk.oldStart;
  }
  for (let i = minLine; i < lines.length; i++) {
    resultLines.push(lines[i]);
  }
  return resultLines.join("\n");
}

// node_modules/diff/libesm/patch/create.js
function structuredPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, options) {
  let optionsObj;
  if (!options) {
    optionsObj = {};
  } else if (typeof options === "function") {
    optionsObj = { callback: options };
  } else {
    optionsObj = options;
  }
  if (typeof optionsObj.context === "undefined") {
    optionsObj.context = 4;
  }
  const context = optionsObj.context;
  if (optionsObj.newlineIsToken) {
    throw new Error("newlineIsToken may not be used with patch-generation functions, only with diffing functions");
  }
  if (!optionsObj.callback) {
    return diffLinesResultToPatch(diffLines(oldStr, newStr, optionsObj));
  } else {
    const { callback } = optionsObj;
    diffLines(oldStr, newStr, Object.assign(Object.assign({}, optionsObj), { callback: (diff) => {
      const patch = diffLinesResultToPatch(diff);
      callback(patch);
    } }));
  }
  function diffLinesResultToPatch(diff) {
    if (!diff) {
      return;
    }
    diff.push({ value: "", lines: [] });
    function contextLines(lines) {
      return lines.map(function(entry) {
        return " " + entry;
      });
    }
    const hunks = [];
    let oldRangeStart = 0, newRangeStart = 0, curRange = [], oldLine = 1, newLine = 1;
    for (let i = 0; i < diff.length; i++) {
      const current2 = diff[i], lines = current2.lines || splitLines(current2.value);
      current2.lines = lines;
      if (current2.added || current2.removed) {
        if (!oldRangeStart) {
          const prev = diff[i - 1];
          oldRangeStart = oldLine;
          newRangeStart = newLine;
          if (prev) {
            curRange = context > 0 ? contextLines(prev.lines.slice(-context)) : [];
            oldRangeStart -= curRange.length;
            newRangeStart -= curRange.length;
          }
        }
        for (const line of lines) {
          curRange.push((current2.added ? "+" : "-") + line);
        }
        if (current2.added) {
          newLine += lines.length;
        } else {
          oldLine += lines.length;
        }
      } else {
        if (oldRangeStart) {
          if (lines.length <= context * 2 && i < diff.length - 2) {
            for (const line of contextLines(lines)) {
              curRange.push(line);
            }
          } else {
            const contextSize = Math.min(lines.length, context);
            for (const line of contextLines(lines.slice(0, contextSize))) {
              curRange.push(line);
            }
            const hunk = {
              oldStart: oldRangeStart,
              oldLines: oldLine - oldRangeStart + contextSize,
              newStart: newRangeStart,
              newLines: newLine - newRangeStart + contextSize,
              lines: curRange
            };
            hunks.push(hunk);
            oldRangeStart = 0;
            newRangeStart = 0;
            curRange = [];
          }
        }
        oldLine += lines.length;
        newLine += lines.length;
      }
    }
    for (const hunk of hunks) {
      for (let i = 0; i < hunk.lines.length; i++) {
        if (hunk.lines[i].endsWith("\n")) {
          hunk.lines[i] = hunk.lines[i].slice(0, -1);
        } else {
          hunk.lines.splice(i + 1, 0, "\\ No newline at end of file");
          i++;
        }
      }
    }
    return {
      oldFileName,
      newFileName,
      oldHeader,
      newHeader,
      hunks
    };
  }
}
function splitLines(text) {
  const hasTrailingNl = text.endsWith("\n");
  const result = text.split("\n").map((line) => line + "\n");
  if (hasTrailingNl) {
    result.pop();
  } else {
    result.push(result.pop().slice(0, -1));
  }
  return result;
}

// src/diff.ts
function computeDiff(before, after, context = 3) {
  const parts = diffLines(before, after);
  const all = [];
  let added = 0;
  let removed = 0;
  for (const part of parts) {
    const lines2 = part.value.replace(/\n$/, "").split("\n");
    if (part.value === "") continue;
    for (const text of lines2) {
      if (part.added) {
        all.push({ type: "add", text });
        added++;
      } else if (part.removed) {
        all.push({ type: "remove", text });
        removed++;
      } else {
        all.push({ type: "same", text });
      }
    }
  }
  const keep = new Array(all.length).fill(false);
  all.forEach((l, i) => {
    if (l.type !== "same") {
      for (let j = Math.max(0, i - context); j <= Math.min(all.length - 1, i + context); j++) {
        keep[j] = true;
      }
    }
  });
  const lines = [];
  let skipping = 0;
  all.forEach((l, i) => {
    if (keep[i]) {
      if (skipping > 0) {
        lines.push({ type: "same", text: `\u2026 ${skipping} unchanged line${skipping === 1 ? "" : "s"} \u2026` });
        skipping = 0;
      }
      lines.push(l);
    } else {
      skipping++;
    }
  });
  if (skipping > 0) {
    lines.push({ type: "same", text: `\u2026 ${skipping} unchanged line${skipping === 1 ? "" : "s"} \u2026` });
  }
  return { lines, added, removed };
}
function applyTextEdit(content, oldText, newText, replaceAll = false) {
  if (!oldText) return { ok: false, error: "old_text must not be empty" };
  let count = countOccurrences(content, oldText);
  let needle = oldText;
  if (count === 0) {
    const relaxed = findRelaxed(content, oldText);
    if (relaxed) {
      needle = relaxed;
      count = countOccurrences(content, needle);
    }
  }
  if (count === 0) {
    return {
      ok: false,
      error: "old_text was not found in the note. Read the note again and copy the exact text you want to replace."
    };
  }
  if (count > 1 && !replaceAll) {
    return {
      ok: false,
      error: `old_text occurs ${count} times. Include more surrounding context so it is unique, or set replace_all to true.`
    };
  }
  const out = replaceAll ? content.split(needle).join(newText) : content.replace(needle, () => newText);
  return { ok: true, content: out, count: replaceAll ? count : 1 };
}
function countOccurrences(haystack, needle) {
  let count = 0;
  let idx = 0;
  while ((idx = haystack.indexOf(needle, idx)) >= 0) {
    count++;
    idx += needle.length;
  }
  return count;
}
function findRelaxed(content, oldText) {
  const wanted = oldText.split("\n").map((l) => l.trimEnd());
  const lines = content.split("\n");
  for (let i = 0; i + wanted.length <= lines.length; i++) {
    let match = true;
    for (let j = 0; j < wanted.length; j++) {
      if (lines[i + j].trimEnd() !== wanted[j]) {
        match = false;
        break;
      }
    }
    if (match) return lines.slice(i, i + wanted.length).join("\n");
  }
  return null;
}

// src/embeds.ts
var IMAGE_EXTENSIONS = ["png", "jpg", "jpeg", "webp"];
function imageEmbeds(content) {
  const out = [];
  const add = (raw) => {
    let t2 = raw.trim();
    try {
      t2 = decodeURI(t2);
    } catch {
    }
    t2 = t2.replace(/[#|].*$/, "").trim();
    const ext = /\.([a-z0-9]+)$/i.exec(t2)?.[1]?.toLowerCase();
    if (t2 && ext && [...IMAGE_EXTENSIONS, "gif", "bmp", "svg"].includes(ext) && !out.includes(t2)) out.push(t2);
  };
  for (const m of content.matchAll(/!\[\[([^\]\n]+)\]\]/g)) add(m[1]);
  for (const m of content.matchAll(/!\[[^\]\n]*\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g)) if (!/^[a-z]+:\/\//i.test(m[1])) add(m[1]);
  return out;
}

// src/prompts.ts
function hasFrontmatter(content) {
  return /^---\r?\n[\s\S]*?\r?\n---(\r?\n|$)/.test(content);
}
function reformatPrompt(path, content) {
  const fm = hasFrontmatter(content) ? "Keep the YAML frontmatter block at the top exactly as it is." : "The note has no YAML frontmatter; do not add one.";
  return [
    `Reformat the note "${path}" into clean, well-structured markdown.`,
    "Read it with get_active_note or read_note, then write the whole tidied note with replace_note.",
    "Rules: keep every piece of content, every wikilink and every tag; fix the heading hierarchy; use '-' for bullet lists; normalise spacing and emphasis; do not add commentary, summaries or new sections that are not in the original.",
    fm
  ].join(" ");
}
function summarizePrompt(path) {
  return `Read the note "${path}" and give me a concise summary with the key points as bullets.`;
}
function processDailyNotesPrompt(o) {
  const folder = o.folder.replace(/^\/+|\/+$/g, "");
  const dest = o.destination.replace(/^\/+|\/+$/g, "");
  const destPrefix = dest ? `${dest}/` : "";
  const heading = o.heading.replace(/^#+\s*/, "").trim();
  const where = folder ? `the "${folder}/" folder` : "the vault root";
  const steps = [
    `Process the inbox sections of my daily notes: compile what is worth keeping into topic notes and leave the daily notes themselves as timelines. Daily notes live in ${where}; the inbox is the "## ${heading}" section of each.${o.since ? ` Only consider daily notes dated on or after ${o.since} (the date is the file name); ignore older ones.` : ""}`,
    `1. Survey every inbox with ONE call: list_sections with heading "${heading}"${folder ? ` and folder "${folder}"` : ""}, limit 400. It lists that section of every daily note with its size and first line. Do not grep, do not read daily notes one by one, do not guess paths.`,
    `2. Substantial inboxes are the ones with 3 or more lines, a list of names or deadlines, or a code block. Empty inboxes and one-liners are not substantial; leave those notes alone entirely. Then read_section (path, "${heading}") for each substantial inbox only, to get its full text.`,
    `3. Group the substantial inboxes by subject. For each subject create ONE note "${destPrefix}<Subject>.md" with create_note (if a note on that subject already exists there, use append_to_note instead): a title heading, the content rewritten as clean markdown that keeps every fact, name, number, date and link, and a final "## Sources" section listing a wikilink to EACH daily note it came from, e.g. [[${folder ? folder + "/" : ""}2026-09-21]]. The Sources section is required in every note you create or extend: a fact without its day is lost. Code blocks go into "${destPrefix}Code snippets.md" grouped by language, each block followed by its source wikilink.`,
    o.move ? `4. Then take each compiled inbox out of its daily note: call replace_section with the daily note's path, heading "${heading}" and new_text "- Moved to [[${destPrefix}<Subject>]]" (one call per daily note, nothing else in that note changes). replace_section needs no old text, so do not read the daily notes before or after it; a successful result means it is done. Leave inboxes you did not compile untouched.` : `4. Leave the daily notes unchanged.`,
    `Do all of it in this turn without asking, then report: which topic notes you created or extended and from which daily notes, and which inboxes you left alone and why.`
  ];
  return steps.join("\n");
}
function editSelectionPrompt(path, selection, instruction) {
  return [
    `In the note "${path}", rewrite the selected passage below so that it ${instruction.trim().replace(/[.\s]+$/, "")}.`,
    `Call edit_note once with path "${path}", old_text copied exactly from the passage (every character, including line breaks) and new_text the rewritten passage. Keep every wikilink, tag and fact unless the instruction says otherwise; match the surrounding markdown style; do not add commentary or headings. Do not read the whole note unless old_text is not found. Then report in one line what you changed.`,
    "",
    "Selected passage:",
    '"""',
    selection,
    '"""'
  ].join("\n");
}
function conventionsTemplate() {
  return [
    "# Vault conventions for the agent",
    "",
    "Everything in this note is given to Local Vault Agent on every message, like a CLAUDE.md.",
    "Keep it short and concrete: what the folders mean, how notes are named, what to never touch.",
    "",
    "## Folders",
    "- `Daily/` \u2014 one note per day, named `YYYY-MM-DD`.",
    "- `Projects/` \u2014 one note per project; status lives under `## Status`.",
    "- `Templates/` \u2014 never edit or search.",
    "",
    "## Style",
    "- Headings in sentence case; `-` for bullets; wikilinks for every reference to another note.",
    "- Lecture notes keep one `## YYYY-MM-DD` section per class.",
    "",
    "## Never",
    "- Never add YAML frontmatter to a note that has none.",
    "- Never delete a note that has backlinks without saying so.",
    ""
  ].join("\n");
}

// src/tools/index.ts
var ToolError = class extends Error {
};
var MAX_UNDO_BINARY_BYTES = 100 * 1024 * 1024;
function str(args, key, required = true) {
  const v = args[key];
  if (v === void 0 || v === null || typeof v === "string" && v.trim() === "") {
    if (required) throw new ToolError(`Missing required argument "${key}".`);
    return "";
  }
  return typeof v === "string" ? v : typeof v === "number" || typeof v === "boolean" ? String(v) : JSON.stringify(v);
}
function int(args, key, fallback, min, max) {
  const v = args[key];
  const n = typeof v === "number" ? v : typeof v === "string" ? parseInt(v, 10) : NaN;
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.floor(n)));
}
function bool(args, key, fallback = false) {
  const v = args[key];
  if (typeof v === "boolean") return v;
  if (typeof v === "string") return v.toLowerCase() === "true";
  return fallback;
}
function normalizeFilePath(input, configDir) {
  let p = input.trim().replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+$/, "");
  p = p.replace(/^!?\[\[|\]\]$/g, "").replace(/\/{2,}/g, "/").replace(/^\.\//, "");
  if (p.split("/").some((seg) => seg === "..")) throw new ToolError("Paths may not contain '..'.");
  if (configDir) {
    const cfg = configDir.replace(/^\/+|\/+$/g, "").toLowerCase();
    if (cfg && p.toLowerCase().startsWith(cfg + "/")) throw new ToolError(`The ${configDir} folder is off limits.`);
  }
  return p;
}
function normalizeNotePath(input, configDir) {
  let p = input.trim().replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+$/, "");
  p = p.replace(/^\[\[|\]\]$/g, "");
  if (!/\.md$/i.test(p)) p += ".md";
  p = p.replace(/\/{2,}/g, "/").replace(/^\.\//, "");
  if (p.split("/").some((seg) => seg === "..")) throw new ToolError("Paths may not contain '..'.");
  if (configDir) {
    const cfg = configDir.replace(/^\/+|\/+$/g, "").toLowerCase();
    if (cfg && p.toLowerCase().startsWith(cfg + "/")) throw new ToolError(`The ${configDir} folder is off limits.`);
  }
  return p;
}
function stripOutlineDecoration(input) {
  return input.replace(/\s+(—|›|\|)\s.*$/, "").replace(/\s+#\S.*$/, "").replace(/\s+\(.*\)$/, "").trim();
}
function resolveAny(vault, input) {
  const direct = vault.resolveFile(input) ?? vault.resolve(input);
  if (direct) return direct;
  const stripped = stripOutlineDecoration(input);
  if (stripped && stripped !== input) return vault.resolveFile(stripped) ?? vault.resolve(stripped);
  return null;
}
function resolveExisting(vault, input) {
  let resolved = vault.resolve(input);
  if (!resolved) {
    const stripped = stripOutlineDecoration(input);
    if (stripped && stripped !== input) resolved = vault.resolve(stripped);
  }
  if (!resolved) throw new ToolError(`No note found for "${input}". ${missingNoteHint(vault, input)}`);
  return resolved;
}
var MISS_LIST_ALL = 80;
var MISS_NEAREST = 10;
function missingNoteHint(vault, input) {
  const cleaned = stripOutlineDecoration(input).replace(/\\/g, "/").replace(/^!?\[\[|\]\]$/g, "").replace(/^\/+|\/+$/g, "");
  const slash = cleaned.lastIndexOf("/");
  const folder = slash >= 0 ? cleaned.slice(0, slash) : "";
  const base = cleaned.slice(slash + 1).replace(/\.md$/i, "");
  const notes = vault.listNotes();
  const inFolder = notes.filter((n) => n.folder.toLowerCase() === folder.toLowerCase()).map((n) => n.basename).sort((a, b) => a.localeCompare(b));
  const label = folder ? `"${folder}/"` : "the vault root";
  if (inFolder.length > 0) {
    if (inFolder.length <= MISS_LIST_ALL) {
      return `${label} has ${inFolder.length} note${inFolder.length === 1 ? "" : "s"}: ${inFolder.map((b) => `${b}.md`).join(", ")}. Use one of these exact paths; do not guess others.`;
    }
    let at = inFolder.findIndex((b) => b.localeCompare(base) >= 0);
    if (at < 0) at = inFolder.length;
    const start = Math.max(0, Math.min(at - MISS_NEAREST / 2, inFolder.length - MISS_NEAREST));
    const near = inFolder.slice(start, start + MISS_NEAREST);
    return `${label} has ${inFolder.length} notes; the nearest by name are ${near.map((b) => `${b}.md`).join(", ")}. Call list_notes({folder: ${JSON.stringify(folder)}}) for all of them; do not guess paths.`;
  }
  const folders = Array.from(new Set(notes.map((n) => n.folder).filter(Boolean))).sort((a, b) => a.localeCompare(b));
  const similar = base ? notes.filter((n) => n.basename.toLowerCase().includes(base.toLowerCase()) || base.toLowerCase().includes(n.basename.toLowerCase())).slice(0, 5).map((n) => n.path) : [];
  const parts = [];
  parts.push(folder ? `There is no folder ${label} with notes.` : `No note is named "${base}" in the vault root.`);
  if (similar.length) parts.push(`Similar names: ${similar.join(", ")}.`);
  if (folders.length) parts.push(`Folders with notes: ${folders.slice(0, 40).map((f) => `${f}/`).join(", ")}${folders.length > 40 ? ", \u2026" : ""}.`);
  parts.push("Use list_notes or search_notes to find the exact path; do not guess.");
  return parts.join(" ");
}
function hashText(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return (h >>> 0).toString(36);
}
function truncate(text, max, offset = 0) {
  const total = text.length;
  const slice = text.slice(offset, offset + max);
  return { text: slice, truncated: offset + max < total, total };
}
async function requestApproval(ctx, req) {
  const decision = await ctx.approve(req);
  if (decision === "reject") {
    throw new ToolError("REJECTED: the user declined this change in the approval dialog, so nothing was written. Do not retry it or a variant of it. Tell the user which change was rejected and ask what they would like instead, then stop.");
  }
  if (ctx.signal?.aborted) throw new ToolError("Stopped before writing; nothing was written.");
  if (CONTENT_TOOLS.has(req.tool)) {
    const now = ctx.vault.exists(req.path) ? await ctx.vault.read(req.path) : null;
    const expected = req.tool === "create_note" ? null : req.before;
    if (now !== expected) {
      throw new ToolError(`${req.path} ${expected === null ? "was created" : "changed"} while the change was waiting for approval, so nothing was written. Read it again and redo the edit on the current text.`);
    }
  }
}
var CONTENT_TOOLS = /* @__PURE__ */ new Set(["create_note", "edit_note", "edit_notes", "append_to_note", "replace_section", "replace_note"]);
var searchNotes = {
  name: "search_notes",
  description: "Search the vault for notes relevant to a query by meaning and keywords. Returns note paths with a short snippet; results are ranked, not exhaustive. For every note containing an exact string, tag or frontmatter value (e.g. 'status: done'), use grep_vault instead.",
  parameters: {
    type: "object",
    properties: {
      query: { type: "string", description: "What to look for. A natural-language phrase or keywords." },
      limit: { type: "integer", description: "Maximum results to return (default 8, max 25)." }
    },
    required: ["query"]
  },
  mutates: false,
  async execute(args, ctx) {
    const query = str(args, "query");
    const limit = int(args, "limit", 8, 1, 25);
    const hits = await ctx.search(query, limit);
    if (hits.length === 0) return `No notes matched "${query}". Try different keywords or list_notes.`;
    return JSON.stringify(
      hits.map((h) => ({ path: h.path, heading: h.heading, snippet: h.snippet })),
      null,
      1
    );
  }
};
var searchPassages = {
  name: "search_passages",
  description: "Semantic search that returns the best-matching sections of notes verbatim (a heading's paragraphs, not a whole note). Usually enough to answer a question directly; cite the note path. Use search_notes instead when you only need to know which notes exist on a topic.",
  parameters: {
    type: "object",
    properties: {
      query: { type: "string", description: "What to look for, phrased like the content you expect (a question or a statement)." },
      limit: { type: "integer", description: "Maximum passages to return (default 6, max 20)." }
    },
    required: ["query"]
  },
  mutates: false,
  async execute(args, ctx) {
    const query = str(args, "query");
    const limit = int(args, "limit", 6, 1, 20);
    const passages = ctx.searchPassages ? await ctx.searchPassages(query, limit) : [];
    if (passages.length === 0) {
      const hits = await ctx.search(query, limit);
      if (hits.length === 0) return `No passages matched "${query}". Try other words, or list_notes.`;
      const rows2 = hits.map((h, i) => `--- [${i + 1}] ${h.path}${h.heading ? ` \u203A ${h.heading}` : ""}
${h.snippet}`);
      return `The semantic index is not available, so these are keyword matches with short snippets (use read_note or read_section for the text):
${rows2.join("\n")}`;
    }
    const maxEach = Math.max(600, Math.floor(ctx.maxResultChars / passages.length));
    const rows = passages.map((p, i) => {
      const text = p.text.length > maxEach ? p.text.slice(0, maxEach) + "\n[\u2026 section truncated; read_section for the rest]" : p.text;
      return `--- [${i + 1}] ${p.path}${p.heading ? ` \u203A ${p.heading}` : ""} (score ${p.score.toFixed(2)})
${text}`;
    });
    return `${passages.length} passage${passages.length === 1 ? "" : "s"}, best first. Each is one section of a note; cite the note path as a wikilink.
${rows.join("\n")}`;
  }
};
function extractSection(content, heading) {
  const lines = content.split("\n");
  const want = heading.replace(/^#+\s*/, "").trim().toLowerCase();
  if (!want) return null;
  let inFence = false;
  let start = -1;
  let level = 0;
  for (let i = 0; i < lines.length; i++) {
    if (/^\s*(```|~~~)/.test(lines[i])) inFence = !inFence;
    if (inFence) continue;
    const m = /^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(lines[i]);
    if (!m) continue;
    const text = m[2].trim().toLowerCase();
    if (start < 0) {
      if (text === want || text.startsWith(want)) {
        start = i;
        level = m[1].length;
      }
    } else if (m[1].length <= level) {
      return { text: lines.slice(start, i).join("\n").trimEnd(), startLine: start + 1, endLine: i };
    }
  }
  if (start < 0) return null;
  return { text: lines.slice(start).join("\n").trimEnd(), startLine: start + 1, endLine: lines.length };
}
var grepVault = {
  name: "grep_vault",
  description: "Search the text of every note for a literal string (case-insensitive) or a regular expression (set regex: true for ^, \\s, [A-Z], a|b and the like), like grep. Returns matching lines as `path:line [enclosing heading]: text` grouped by note, optionally with context lines. The right tool for 'every note that contains X', embeds, tags, headings or exact phrases; much cheaper than reading notes. With a heading as the pattern and context: 8 it shows the start of that section in every note at once.",
  parameters: {
    type: "object",
    properties: {
      pattern: { type: "string", description: "Literal text to look for, or a regular expression when regex is true." },
      regex: { type: "boolean", description: "Treat pattern as a JavaScript regular expression (default false)." },
      folder: { type: "string", description: "Only notes inside this folder (recursive)." },
      context: { type: "integer", description: "Lines of context to show after each match (default 0, max 8)." },
      limit: { type: "integer", description: "Maximum matching lines to return (default 60, max 200)." }
    },
    required: ["pattern"]
  },
  mutates: false,
  async execute(args, ctx) {
    const rawPattern = str(args, "pattern");
    const useRegex = bool(args, "regex");
    const folder = str(args, "folder", false).replace(/\\/g, "/").replace(/^\/+|\/+$/g, "").toLowerCase();
    const context = int(args, "context", 0, 0, 8);
    const limit = int(args, "limit", 60, 1, 200);
    let notes = ctx.vault.listNotes();
    if (folder) {
      const inFolder = notes.filter((n) => n.path.toLowerCase().startsWith(folder + "/"));
      if (inFolder.length) notes = inFolder;
      else {
        const single = ctx.vault.resolve(str(args, "folder", false));
        notes = single ? notes.filter((n) => n.path === single) : [];
      }
    }
    notes.sort((a, b) => a.path.localeCompare(b.path));
    const texts = await Promise.all(notes.map((n) => ctx.vault.read(n.path)));
    const scan = (test) => {
      const blocks2 = [];
      let shown3 = 0;
      let total2 = 0;
      let notesHit2 = 0;
      notes.forEach((n, k) => {
        const lines = texts[k].split("\n");
        const rows = [];
        let heading = "";
        let inFence = false;
        for (let i = 0; i < lines.length; i++) {
          if (/^\s*(```|~~~)/.test(lines[i])) inFence = !inFence;
          const h = !inFence && /^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(lines[i]);
          if (h) heading = `${h[1]} ${h[2].trim()}`;
          if (!test(lines[i])) continue;
          total2++;
          if (shown3 >= limit) continue;
          shown3++;
          rows.push(`${n.path}:${i + 1}${heading && !h ? ` [${heading}]` : ""}: ${lines[i]}`);
          for (let j = i + 1; j <= Math.min(lines.length - 1, i + context); j++) rows.push(`${n.path}:${j + 1}- ${lines[j]}`);
        }
        if (rows.length) {
          notesHit2++;
          blocks2.push(rows.join("\n"));
        }
      });
      return { blocks: blocks2, shown: shown3, total: total2, notesHit: notesHit2 };
    };
    const literal = (p) => {
      const lower = p.toLowerCase();
      return (line) => line.toLowerCase().includes(lower);
    };
    const compile = (p) => {
      try {
        return new RegExp(p, "i");
      } catch {
        return null;
      }
    };
    let note = "";
    let pattern = rawPattern;
    let result;
    if (useRegex) {
      pattern = tidyAlternation(rawPattern);
      const re = compile(pattern);
      if (re) {
        result = scan((line) => re.test(line));
      } else {
        note = `(The pattern is not a valid regular expression: ${tryRegexError(pattern)}. Searched for it as literal text instead.)
`;
        result = scan(literal(rawPattern));
      }
    } else {
      result = scan(literal(rawPattern));
      if (result.total === 0 && looksLikeRegex(rawPattern)) {
        pattern = tidyAlternation(rawPattern);
        const re = compile(pattern);
        if (re) {
          const asRegex = scan((line) => re.test(line));
          if (asRegex.total > 0) {
            note = `(No line contains that text literally; it looks like a regular expression, so it was searched as one${pattern !== rawPattern ? `, as ${JSON.stringify(pattern)}` : ""}.)
`;
            result = asRegex;
          } else {
            note = "(Searched both as literal text and as a regular expression.)\n";
          }
        }
      }
    }
    if (result.total === 0) return `${note}No note contains "${rawPattern}"${folder ? ` under ${folder}/` : ""}.`;
    const { blocks, shown: shown2, total, notesHit } = result;
    const more = total > shown2 ? `
\u2026${total - shown2} more matching lines not shown; narrow with folder or raise the limit.` : "";
    const hint = total >= 8 && context > 0 ? `
To know which of these sections also contain (or lack) another text, call list_sections({containing: [${JSON.stringify(rawPattern)}, "<other text>"]}) once instead of reading them.` : "";
    return `${note}${total} matching line${total === 1 ? "" : "s"} in ${notesHit} note${notesHit === 1 ? "" : "s"}:
${blocks.join("\n--\n")}${more}${hint}`;
  }
};
function tryRegexError(pattern) {
  try {
    new RegExp(pattern, "i");
    return "";
  } catch (err) {
    return err.message;
  }
}
function looksLikeRegex(pattern) {
  return /^\^|\$$|\\[sdwbSDWB]|\\[[\]().|+*?{}]|\[[^\]]+\]|\.[*+?]|\(\?|\||\{\d+(,\d*)?\}/.test(pattern);
}
function tidyAlternation(pattern) {
  if (!pattern.includes("|")) return pattern;
  const parts = pattern.split("|");
  if (!parts.some((p) => p !== p.trim())) return pattern;
  return parts.map((p) => p.trim()).join("|");
}
var listSections = {
  name: "list_sections",
  description: "Survey sections across many notes without reading them, in ONE call for the whole vault or folder. containing: ['![[Recording', '### Summary'] flags for every section which of those texts it has, so 'sections with X but not Y' is answered at once (pass all the texts you care about together; never one call per section or per note; then edit with edit_notes using heading + line_contains). heading: 'Capture' with a folder lists that section of every note with its size and first line \u2014 which daily notes have a full inbox and which are empty. Give containing, heading, or both.",
  parameters: {
    type: "object",
    properties: {
      heading: { type: "string", description: "Only sections whose heading starts with this text (case-insensitive), e.g. 'Capture'." },
      containing: { type: "array", description: "Up to 4 texts to test each section for (case-insensitive, literal).", items: { type: "string" } },
      folder: { type: "string", description: "Only notes inside this folder (recursive)." },
      path: { type: "string", description: "Only this note." },
      level: { type: "integer", description: "Only headings of this level (2 = '##'). Default: all levels." },
      only_matching: { type: "boolean", description: "With containing: only list sections that contain at least one of the texts (default true)." },
      limit: { type: "integer", description: "Maximum sections to return (default 150, max 400)." }
    }
  },
  mutates: false,
  async execute(args, ctx) {
    let raw = args.containing;
    if (typeof raw === "string" && /^\s*\[.*\]\s*$/s.test(raw)) {
      const text = raw;
      try {
        raw = JSON.parse(text.replace(/'/g, '"'));
      } catch {
        raw = text.trim().slice(1, -1).split(/\s*,\s*/).map((x) => x.trim().replace(/^['"]|['"]$/g, ""));
      }
    }
    const wantHeading = str(args, "heading", false).replace(/^#+\s*/, "").trim().toLowerCase();
    const needles = (Array.isArray(raw) ? raw : typeof raw === "string" ? [raw] : []).map((x) => String(x).trim()).filter(Boolean).filter((x) => !wantHeading || x.replace(/^#+\s*/, "").trim().toLowerCase() !== wantHeading).slice(0, 4);
    if (needles.length === 0 && !wantHeading) throw new ToolError("Give heading (a section to survey) and/or containing (1\u20134 texts to test for).");
    const folder = str(args, "folder", false).replace(/\\/g, "/").replace(/^\/+|\/+$/g, "").toLowerCase();
    const only = str(args, "path", false);
    const level = int(args, "level", 0, 0, 6);
    const onlyMatching = needles.length > 0 && bool(args, "only_matching", true);
    const limit = int(args, "limit", 150, 1, 400);
    let notes = ctx.vault.listNotes();
    if (only) {
      const p = resolveExisting(ctx.vault, only);
      notes = notes.filter((n) => n.path === p);
    }
    if (folder) notes = notes.filter((n) => n.path.toLowerCase().startsWith(folder + "/"));
    notes.sort((a, b) => a.path.localeCompare(b.path));
    const lowers = needles.map((n) => n.toLowerCase());
    const blocks = [];
    let shown2 = 0;
    let total = 0;
    let candidates = 0;
    let withAll = 0;
    const marked = [];
    const someBlocks = [];
    for (const n of notes) {
      const lines = (await ctx.vault.read(n.path)).split("\n");
      const heads = [];
      let inFence = false;
      for (let i = 0; i < lines.length; i++) {
        if (/^\s*(```|~~~)/.test(lines[i])) inFence = !inFence;
        const h = !inFence && /^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(lines[i]);
        if (h) heads.push({ heading: h[2].trim(), lvl: h[1].length, line: i });
      }
      const rows = [];
      const someRows = [];
      const grouped = needles.length > 1 && !wantHeading;
      const info = heads.map((s, k) => {
        let end = lines.length;
        for (let j = k + 1; j < heads.length; j++) {
          if (heads[j].lvl <= s.lvl) {
            end = heads[j].line;
            break;
          }
        }
        const bodyLines = lines.slice(s.line + 1, end);
        const body = bodyLines.join("\n");
        const flags = lowers.map((l) => body.toLowerCase().includes(l));
        return { s, end, bodyLines, body, flags };
      });
      const shadowed = (k) => {
        const { s, end, flags } = info[k];
        if (!needles.length || wantHeading || !flags.some(Boolean)) return false;
        return info.some((c) => c.s.line > s.line && c.s.line < end && c.s.lvl > s.lvl && c.flags.some(Boolean) && flags.every((f, i) => !f || c.flags[i]));
      };
      for (let k = 0; k < heads.length; k++) {
        const { s, bodyLines, body, flags } = info[k];
        if (level && s.lvl !== level) continue;
        if (wantHeading && !s.heading.toLowerCase().startsWith(wantHeading)) continue;
        if (shadowed(k)) continue;
        candidates++;
        if (onlyMatching && !flags.some(Boolean)) continue;
        total++;
        if (shown2 >= limit) continue;
        shown2++;
        let row = `  ${"#".repeat(s.lvl)} ${s.heading}`;
        if (wantHeading) {
          const nonEmpty = bodyLines.filter((l) => l.trim());
          const first = (nonEmpty[0] ?? "").trim();
          row += nonEmpty.length === 0 ? " (empty)" : ` (${nonEmpty.length} line${nonEmpty.length === 1 ? "" : "s"}, ${body.trim().length} chars): ${first.length > 100 ? first.slice(0, 99) + "\u2026" : first}`;
        }
        if (needles.length) row += `${wantHeading ? " |" : ":"} ${needles.map((t2, i) => `${t2} ${flags[i] ? "yes" : "no"}`).join(", ")}`;
        const hasAll = needles.length > 1 && flags.every(Boolean);
        if (hasAll) {
          row += " \u2192 all";
          withAll++;
          if (marked.length < 80) marked.push(`${n.path} \u203A ${s.heading}`);
        }
        if (grouped && !hasAll) someRows.push(row);
        else rows.push(row);
      }
      if (rows.length) blocks.push(`${n.path}
${rows.join("\n")}`);
      if (someRows.length) someBlocks.push(`${n.path}
${someRows.join("\n")}`);
    }
    if (total === 0) {
      const where = folder ? ` under ${folder}/` : "";
      const texts = needles.map((t2) => `"${t2}"`).join(", ");
      if (onlyMatching && candidates > 0) {
        return `${candidates} section${candidates === 1 ? "" : "s"}${wantHeading ? ` headed "${wantHeading}"` : ""}${where} exist, but none contains ${texts}. Call again without containing to survey them, or with other texts.`;
      }
      const what = wantHeading ? `No section headed "${wantHeading}"` : "No section";
      return `${what}${onlyMatching ? " contains any of " + texts : wantHeading ? "" : "s found"}${where}.`;
    }
    const more = total > shown2 ? `
\u2026${total - shown2} more sections not shown; narrow with folder/path or raise the limit.` : "";
    const legend = wantHeading ? "(non-empty lines, characters, first line)" : needles.length > 1 ? '(flags per text, in order; "\u2192 all" marks a section that has every text)' : "(flags per text, in order)";
    const verdict = needles.length > 1 ? `
${withAll} section${withAll === 1 ? "" : "s"} marked "\u2192 all" ${withAll === 1 ? "has" : "have"} every text. These flags are exact: act on the marked sections directly (for example edit_notes with path, heading and line_contains set to the text you searched for), without reading them first, and leave the unmarked sections alone.${marked.length ? `
Marked sections (path \u203A heading):
${marked.join("\n")}${withAll > marked.length ? `
\u2026and ${withAll - marked.length} more` : ""}` : ""}` : "";
    if (needles.length > 1 && !wantHeading) {
      const every = `Sections with EVERY text (${withAll}):
${blocks.length ? blocks.join("\n") : "(none)"}`;
      const partial = `Sections with only SOME of the texts (${total - withAll}) \u2014 leave these alone when the rule is "has both":
${someBlocks.length ? someBlocks.join("\n") : "(none)"}`;
      return `${total} section${total === 1 ? "" : "s"} ${legend}:
${every}
${partial}${more}${verdict}`;
    }
    return `${total} section${total === 1 ? "" : "s"} ${legend}:
${blocks.join("\n")}${more}${verdict}`;
  }
};
var readSection = {
  name: "read_section",
  description: "Read one section of a note: the heading and everything under it up to the next heading of the same or a higher level. Cheaper than read_note for long notes. Heading text is matched case-insensitively; a prefix is enough.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path of the note." },
      heading: { type: "string", description: "The heading text, e.g. 'Open problems' or '2026-11-05'." }
    },
    required: ["path", "heading"]
  },
  mutates: false,
  async execute(args, ctx) {
    const path = resolveExisting(ctx.vault, str(args, "path"));
    const heading = str(args, "heading");
    const content = await ctx.vault.read(path);
    const section = extractSection(content, heading);
    if (!section) {
      const available = ctx.vault.getMetadata(path).headings;
      return `No heading matching "${heading}" in ${path}.${available.length ? ` Headings in this note:
${available.join("\n")}` : " The note has no headings; use read_note."}`;
    }
    const page = truncate(section.text, ctx.maxResultChars);
    let out = `# ${path} (lines ${section.startLine}\u2013${section.endLine})
---
${page.text}`;
    if (page.truncated) out += `

[TRUNCATED at ${ctx.maxResultChars} characters of ${page.total}; use read_note with an offset for the rest.]`;
    return out;
  }
};
var readNote = {
  name: "read_note",
  description: "Read the full contents of one note by path (or exact note name), with its tags, links, backlinks and headings. Long notes are paged with `offset`. Costs context: to find which notes mention something use grep_vault or search_passages instead; to read one heading use read_section.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Vault-relative path like 'Projects/Chess Robot.md', or the note name." },
      offset: { type: "integer", description: "Character offset to start reading from (default 0)." }
    },
    required: ["path"]
  },
  mutates: false,
  async execute(args, ctx) {
    const path = resolveExisting(ctx.vault, str(args, "path"));
    const offset = int(args, "offset", 0, 0, 5e7);
    const content = await ctx.vault.read(path);
    const meta = ctx.vault.getMetadata(path);
    const stamp = `${content.length}:${hashText(content)}`;
    if (ctx.readLog) {
      const seen = ctx.readLog.get(path);
      if (seen === stamp && offset === 0 && content.length <= ctx.maxResultChars) {
        return `(unchanged since you read ${path} earlier in this turn; its full text is already above \u2014 do not read it again.)`;
      }
      if (offset === 0 && content.length <= ctx.maxResultChars) ctx.readLog.set(path, stamp);
    }
    const page = truncate(content, ctx.maxResultChars, offset);
    const header = [
      `# ${path}`,
      meta.tags.length ? `tags: ${meta.tags.join(", ")}` : null,
      meta.links.length ? `links to: ${meta.links.slice(0, 30).join(", ")}` : null,
      meta.backlinks.length ? `linked from: ${meta.backlinks.slice(0, 30).join(", ")}` : null,
      `length: ${page.total} characters`
    ].filter(Boolean).join("\n");
    let body = page.text;
    if (offset > 0) body = `[\u2026continuing from character ${offset}]
` + body;
    if (page.truncated) {
      body += `

[TRUNCATED at character ${offset + ctx.maxResultChars} of ${page.total}. Call read_note again with offset=${offset + ctx.maxResultChars} to continue.]`;
    }
    if (ctx.describeImage && offset === 0) {
      const images = imageEmbeds(content);
      if (images.length) body += `

[This note embeds ${images.length} image${images.length === 1 ? "" : "s"} (${images.slice(0, 8).join(", ")}${images.length > 8 ? ", \u2026" : ""}). Its text cannot see them; if what they show matters, read one with read_image.]`;
    }
    return `${header}
---
${body}`;
  }
};
var listNotes = {
  name: "list_notes",
  description: "List notes in the vault, optionally filtered by folder, tag or a substring of the name. Returns every matching path with its size and last-modified date, newest first. The way to learn which notes a folder contains (never guess paths), and the size tells you which notes are nearly empty before you read any.",
  parameters: {
    type: "object",
    properties: {
      folder: { type: "string", description: "Only notes inside this folder (recursive). Omit for the whole vault." },
      tag: { type: "string", description: "Only notes with this tag (with or without '#')." },
      name_contains: { type: "string", description: "Only notes whose name contains this text (case-insensitive)." },
      sort: { type: "string", description: "Sort order.", enum: ["modified", "created", "name", "path"] },
      modified_after: { type: "string", description: "Only notes modified on or after this date (YYYY-MM-DD)." },
      modified_before: { type: "string", description: "Only notes modified before this date (YYYY-MM-DD)." },
      limit: { type: "integer", description: "Maximum results (default 50, max 300)." }
    }
  },
  mutates: false,
  async execute(args, ctx) {
    const folder = str(args, "folder", false).replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
    const tag = str(args, "tag", false).replace(/^#/, "").toLowerCase();
    const nameContains = str(args, "name_contains", false).toLowerCase();
    const sort = str(args, "sort", false) || "modified";
    const limit = int(args, "limit", 50, 1, 300);
    const after = parseDate(str(args, "modified_after", false));
    const before = parseDate(str(args, "modified_before", false));
    let notes = ctx.vault.listNotes();
    if (after !== null) notes = notes.filter((n) => n.mtime >= after);
    if (before !== null) notes = notes.filter((n) => n.mtime < before);
    if (folder) {
      const prefix = folder.toLowerCase() + "/";
      notes = notes.filter((n) => n.path.toLowerCase().startsWith(prefix));
    }
    if (nameContains) notes = notes.filter((n) => n.basename.toLowerCase().includes(nameContains));
    if (tag) {
      notes = notes.filter(
        (n) => ctx.vault.getMetadata(n.path).tags.some((t2) => {
          const lower = t2.replace(/^#/, "").toLowerCase();
          return lower === tag || lower.startsWith(tag + "/");
        })
      );
    }
    switch (sort) {
      case "name":
        notes.sort((a, b) => a.basename.localeCompare(b.basename));
        break;
      case "path":
        notes.sort((a, b) => a.path.localeCompare(b.path));
        break;
      case "created":
        notes.sort((a, b) => b.ctime - a.ctime);
        break;
      default:
        notes.sort((a, b) => b.mtime - a.mtime);
    }
    const total = notes.length;
    const rows = notes.slice(0, limit).map((n) => `${n.path}  (${formatSize(n.size)}, modified ${isoDate(n.mtime)})`);
    if (rows.length === 0) return "No notes matched those filters.";
    const more = total > limit ? `
\u2026and ${total - limit} more. Narrow the filter or raise the limit.` : "";
    return `${total} note${total === 1 ? "" : "s"}:
${rows.join("\n")}${more}`;
  }
};
var vaultOverview = {
  name: "vault_overview",
  description: "Get a map of the vault: folders with note counts, total notes and the most used tags. Useful to orient yourself before browsing.",
  parameters: { type: "object", properties: {} },
  mutates: false,
  async execute(_args, ctx) {
    const notes = ctx.vault.listNotes();
    const folders = /* @__PURE__ */ new Map();
    const tags = /* @__PURE__ */ new Map();
    for (const n of notes) {
      const top = n.folder === "" ? "(root)" : n.folder.split("/")[0];
      folders.set(top, (folders.get(top) ?? 0) + 1);
      for (const t2 of ctx.vault.getMetadata(n.path).tags) tags.set(t2, (tags.get(t2) ?? 0) + 1);
    }
    const folderRows = Array.from(folders.entries()).sort((a, b) => b[1] - a[1]).map(([f, c]) => `  ${f}/  (${c})`);
    const tagRows = Array.from(tags.entries()).sort((a, b) => b[1] - a[1]).slice(0, 40).map(([t2, c]) => `${t2} (${c})`);
    return [
      `Total notes: ${notes.length}`,
      `Top-level folders:`,
      ...folderRows,
      tagRows.length ? `Most used tags: ${tagRows.join(", ")}` : "No tags in use."
    ].join("\n");
  }
};
var getActiveNote = {
  name: "get_active_note",
  description: "Return the note the user currently has open in the editor (path and contents), plus any text they have selected. Use this when the user says 'this note', 'the current note' or 'my selection'.",
  parameters: { type: "object", properties: {} },
  mutates: false,
  async execute(_args, ctx) {
    const path = ctx.vault.getActiveNotePath();
    if (!path) return "No note is currently open in the editor.";
    const content = await ctx.vault.read(path);
    const page = truncate(content, ctx.maxResultChars);
    const selection = ctx.vault.getSelection();
    let out = `# ${path}
---
${page.text}`;
    if (page.truncated) out += `

[TRUNCATED. Use read_note with offset=${ctx.maxResultChars} to read more.]`;
    if (selection && selection.trim()) out += `

--- SELECTED TEXT ---
${selection}`;
    return out;
  }
};
var createNote = {
  name: "create_note",
  description: "Create a new note. Fails if the note already exists. The user must approve the content before it is written.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Vault-relative path for the new note, e.g. 'Summaries/Chess Research.md'." },
      content: { type: "string", description: "Full markdown content of the note." }
    },
    required: ["path", "content"]
  },
  mutates: true,
  async execute(args, ctx) {
    const path = normalizeNotePath(str(args, "path"), ctx.configDir);
    const content = str(args, "content");
    if (ctx.vault.exists(path)) {
      throw new ToolError(`"${path}" already exists. Use edit_note, append_to_note or replace_note instead, or choose another path.`);
    }
    await requestApproval(ctx, { tool: "create_note", path, before: "", after: content, summary: `Create ${path}` });
    await ctx.vault.create(path, content);
    ctx.recordChange?.({ tool: "create_note", path, before: "", after: content });
    return `Created ${path} (${content.length} characters).`;
  }
};
var editNote = {
  name: "edit_note",
  description: "Make a targeted edit to a note by replacing an exact passage with new text. old_text must match the note exactly and be unique unless replace_all is true: use the smallest unique passage (usually one line), not a whole section. Prefer this over replace_note for small changes; use edit_notes for many edits at once.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path of the note to edit." },
      old_text: { type: "string", description: "The exact text to replace." },
      new_text: { type: "string", description: "The replacement text. Use an empty string to delete the passage." },
      replace_all: { type: "boolean", description: "Replace every occurrence instead of requiring a unique match (default false)." }
    },
    required: ["path", "old_text", "new_text"]
  },
  mutates: true,
  async execute(args, ctx) {
    const path = resolveExisting(ctx.vault, str(args, "path"));
    const oldText = str(args, "old_text");
    const newText = typeof args.new_text === "string" ? args.new_text : str(args, "new_text", false);
    const replaceAll = bool(args, "replace_all");
    const before = await ctx.vault.read(path);
    const result = applyTextEdit(before, oldText, newText, replaceAll);
    if (!result.ok) {
      const hint = /not found/.test(result.error) ? nearestLines(before, oldText) : null;
      throw new ToolError(hint ? `${result.error}
${hint}` : result.error);
    }
    if (result.content === before) return "The edit would not change anything; nothing written.";
    await requestApproval(ctx, {
      tool: "edit_note",
      path,
      before,
      after: result.content,
      summary: `Edit ${path} (${result.count} replacement${result.count === 1 ? "" : "s"})`
    });
    await ctx.vault.modify(path, result.content);
    ctx.recordChange?.({ tool: "edit_note", path, before, after: result.content });
    return `Edited ${path}: ${result.count} replacement${result.count === 1 ? "" : "s"} applied.`;
  }
};
var editNotes = {
  name: "edit_notes",
  description: 'Apply many small edits in one call, possibly across many notes; edits to the same note are combined into one approval. Each edit is {path, new_text} plus EITHER old_text (exact unique passage) OR line_contains (text that identifies one line; add heading to limit the search to that section). new_text replaces the passage or the whole line; an empty new_text deletes it. Example: {"path":"School/Lectures.md","heading":"2026-09-02","line_contains":"![[Recording 20260902","new_text":""}. Use this for clean-ups found with grep_vault instead of one edit_note call per match. Failed edits are reported individually; the rest still apply.',
  parameters: {
    type: "object",
    properties: {
      edits: {
        type: "array",
        description: "The edits to apply, at most 40.",
        items: {
          type: "object",
          properties: {
            path: { type: "string", description: "Path of the note." },
            old_text: { type: "string", description: "Exact text to replace (copy it from grep_vault / read_section). Omit when using line_contains." },
            line_contains: { type: "string", description: "Text that occurs in exactly one line (of the section, when heading is given); that whole line is replaced." },
            heading: { type: "string", description: "Optional heading text limiting line_contains to one section." },
            new_text: { type: "string", description: "Replacement; empty string deletes the passage or line." }
          },
          required: ["path", "new_text"]
        }
      }
    },
    required: ["edits"]
  },
  mutates: true,
  async execute(args, ctx) {
    const raw = args.edits;
    if (!Array.isArray(raw) || raw.length === 0) throw new ToolError("edits must be a non-empty array of {path, old_text, new_text}.");
    if (raw.length > 40) throw new ToolError("At most 40 edits per call; split the rest into another call.");
    const groups = /* @__PURE__ */ new Map();
    const report = [];
    raw.forEach((e, index) => {
      const item = e ?? {};
      const pathInput = typeof item.path === "string" ? item.path : "";
      const oldText = typeof item.old_text === "string" ? item.old_text : "";
      const lineContains = typeof item.line_contains === "string" && item.line_contains.trim() ? item.line_contains.trim() : void 0;
      const heading = typeof item.heading === "string" && item.heading.trim() ? item.heading.trim() : void 0;
      const newText = typeof item.new_text === "string" ? item.new_text : "";
      let path = null;
      try {
        path = pathInput ? resolveExisting(ctx.vault, pathInput) : null;
      } catch (err) {
        report.push(`#${index + 1} ${pathInput}: ${err.message}`);
        return;
      }
      if (!path) {
        report.push(`#${index + 1}: missing path.`);
        return;
      }
      if (!oldText && !lineContains) {
        report.push(`#${index + 1} ${path}: give old_text or line_contains.`);
        return;
      }
      const list = groups.get(path) ?? [];
      list.push({ index, oldText, newText, lineContains, heading });
      groups.set(path, list);
    });
    let applied = 0;
    for (const [path, edits] of groups) {
      const before = await ctx.vault.read(path);
      let content = before;
      const okIdx = [];
      for (const e of edits) {
        if (e.lineContains) {
          const r = replaceLine(content, e.lineContains, e.newText, e.heading);
          if (!r.ok) {
            report.push(`#${e.index + 1} ${path}: ${r.error}`);
            continue;
          }
          content = r.content;
          okIdx.push(e.index + 1);
          continue;
        }
        const result = applyTextEdit(content, e.oldText, e.newText, false);
        if (!result.ok) {
          const hint = /not found/.test(result.error) ? nearestLines(content, e.oldText) : "";
          report.push(`#${e.index + 1} ${path}: ${result.error}${hint ? `
${hint}` : ""}`);
          continue;
        }
        content = result.content;
        okIdx.push(e.index + 1);
      }
      if (content === before) continue;
      try {
        await requestApproval(ctx, {
          tool: "edit_notes",
          path,
          before,
          after: content,
          summary: `Edit ${path} (${okIdx.length} change${okIdx.length === 1 ? "" : "s"})`
        });
      } catch (err) {
        const message = err.message;
        report.push(`${path}: ${message}`);
        if (/^REJECTED/.test(message)) {
          report.push("Stopped: the user rejected a change. Do not retry it; ask what they want instead.");
          break;
        }
        if (/^Stopped/.test(message)) break;
        continue;
      }
      try {
        await ctx.vault.modify(path, content);
      } catch (err) {
        report.push(`${path}: the write failed (${err.message}); the note is unchanged.`);
        continue;
      }
      ctx.recordChange?.({ tool: "edit_note", path, before, after: content });
      applied += okIdx.length;
      report.push(`${path}: applied edit${okIdx.length === 1 ? "" : "s"} ${okIdx.map((i) => `#${i}`).join(", ")}.`);
    }
    return `${applied} of ${raw.length} edit${raw.length === 1 ? "" : "s"} applied.
${report.join("\n")}`;
  }
};
function replaceLine(content, needle, newText, heading) {
  const lines = content.split("\n");
  let from = 0;
  let to = lines.length;
  if (heading) {
    const section = extractSection(content, heading);
    if (!section) return { ok: false, error: `no heading matching "${heading}".` };
    from = section.startLine - 1;
    to = section.endLine;
  }
  const lower = needle.toLowerCase();
  const hits = [];
  for (let i2 = from; i2 < to; i2++) if (lines[i2].toLowerCase().includes(lower)) hits.push(i2);
  if (hits.length === 0) return { ok: false, error: `no line contains "${needle}"${heading ? ` under "${heading}"` : ""}.` };
  if (hits.length > 1) return { ok: false, error: `"${needle}" occurs on ${hits.length} lines${heading ? ` under "${heading}"` : ""} (${hits.map((i2) => i2 + 1).join(", ")}); add heading or use a longer text.` };
  const i = hits[0];
  if (newText === "") {
    const removeBlank = i + 1 < lines.length && lines[i + 1].trim() === "" && (i === 0 || lines[i - 1].trim() === "");
    lines.splice(i, removeBlank ? 2 : 1);
  } else {
    lines.splice(i, 1, ...newText.split("\n"));
  }
  return { ok: true, content: lines.join("\n") };
}
var appendToNote = {
  name: "append_to_note",
  description: "Append markdown to the end of an existing note. The user must approve before it is written.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path of the note to append to." },
      content: { type: "string", description: "Markdown to append." }
    },
    required: ["path", "content"]
  },
  mutates: true,
  async execute(args, ctx) {
    const path = resolveExisting(ctx.vault, str(args, "path"));
    const content = str(args, "content");
    const before = await ctx.vault.read(path);
    const sep = before.length === 0 ? "" : before.endsWith("\n\n") ? "" : before.endsWith("\n") ? "\n" : "\n\n";
    const after = before + sep + content.replace(/\s+$/, "") + "\n";
    await requestApproval(ctx, { tool: "append_to_note", path, before, after, summary: `Append to ${path}` });
    await ctx.vault.modify(path, after);
    ctx.recordChange?.({ tool: "append_to_note", path, before, after });
    return `Appended ${content.length} characters to ${path}.`;
  }
};
function replaceSectionBody(content, heading, body) {
  const section = extractSection(content, heading);
  if (!section) return null;
  const lines = content.split("\n");
  const start = section.startLine - 1;
  const headingLine = lines[start];
  const rest = lines.slice(section.endLine).join("\n");
  const trimmed = body.replace(/^\s*\n|\s+$/g, "");
  let text = trimmed ? `${headingLine}

${trimmed}
` : `${headingLine}
`;
  if (rest.trim()) text += "\n";
  const head = start > 0 ? lines.slice(0, start).join("\n") + "\n" : "";
  return head + text + rest;
}
var replaceSection = {
  name: "replace_section",
  description: "Replace everything under one heading of a note (up to the next heading of the same or a higher level) with new markdown; the heading line itself stays. The way to rewrite, empty or shorten a section without copying its old text: e.g. after compiling a daily note's inbox elsewhere, replace_section(path, 'Capture', '- Moved to [[Topics/X]]'). Heading matched case-insensitively, prefix is enough. The user must approve.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path of the note." },
      heading: { type: "string", description: "Heading text without the '#', e.g. 'Capture'." },
      new_text: { type: "string", description: "New body for the section; empty string empties it." }
    },
    required: ["path", "heading", "new_text"]
  },
  mutates: true,
  async execute(args, ctx) {
    const path = resolveExisting(ctx.vault, str(args, "path"));
    const heading = str(args, "heading");
    const body = str(args, "new_text", false);
    const before = await ctx.vault.read(path);
    const after = replaceSectionBody(before, heading, body);
    if (after === null) {
      const available = ctx.vault.getMetadata(path).headings;
      throw new ToolError(`No heading matching "${heading}" in ${path}.${available.length ? ` Headings in this note:
${available.join("\n")}` : " The note has no headings; use edit_note or replace_note."}`);
    }
    if (after === before) return `The section "${heading}" in ${path} already has that content; nothing written.`;
    await requestApproval(ctx, { tool: "replace_section", path, before, after, summary: `Replace section "${heading}" in ${path}` });
    await ctx.vault.modify(path, after);
    ctx.recordChange?.({ tool: "replace_section", path, before, after });
    return `Replaced the "${heading}" section of ${path} (${body.length} characters).`;
  }
};
var replaceNote = {
  name: "replace_note",
  description: "Replace the entire contents of an existing note. Use this for reformatting or rewriting a whole note. Always read_note first. If the note has a YAML frontmatter block keep it unchanged; if it has none, do not add one. The user must approve before it is written.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path of the note to rewrite." },
      content: { type: "string", description: "The complete new markdown content." }
    },
    required: ["path", "content"]
  },
  mutates: true,
  async execute(args, ctx) {
    const path = resolveExisting(ctx.vault, str(args, "path"));
    const content = str(args, "content");
    const before = await ctx.vault.read(path);
    if (content === before) return "The new content is identical to the current note; nothing written.";
    if (!hasFrontmatter(before) && /^---[ \t]*\r?\n/.test(content)) {
      throw new ToolError(
        "The note has no YAML frontmatter, but the new content starts with '---'. Resubmit it without that leading line (if the user explicitly asked for frontmatter, add it with edit_note instead)."
      );
    }
    if (before.length > 400 && content.length < before.length * 0.3) {
      throw new ToolError(
        `The new content (${content.length} chars) is less than 30% of the current note (${before.length} chars). If you really mean to shorten it this much, say so to the user and ask them to confirm first; otherwise use edit_note for a targeted change.`
      );
    }
    await requestApproval(ctx, { tool: "replace_note", path, before, after: content, summary: `Rewrite ${path}` });
    await ctx.vault.modify(path, content);
    ctx.recordChange?.({ tool: "replace_note", path, before, after: content });
    return `Rewrote ${path} (${before.length} \u2192 ${content.length} characters).`;
  }
};
var findInNote = {
  name: "find_in_note",
  description: "Find the lines of a note that contain a text (case-insensitive) or a regular expression. Returns 1-based line numbers with one line of context. Use it to locate the exact passage for edit_note in a long note instead of reading the whole note, or to check whether a note mentions something.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path of the note to search." },
      pattern: { type: "string", description: "Text to look for, or a JavaScript regular expression when regex is true." },
      regex: { type: "boolean", description: "Treat pattern as a regular expression (default false)." },
      limit: { type: "integer", description: "Maximum matches to return (default 20, max 100)." }
    },
    required: ["path", "pattern"]
  },
  mutates: false,
  async execute(args, ctx) {
    const path = resolveExisting(ctx.vault, str(args, "path"));
    const pattern = str(args, "pattern");
    const useRegex = bool(args, "regex");
    const limit = int(args, "limit", 20, 1, 100);
    const content = await ctx.vault.read(path);
    const lines = content.split("\n");
    let test;
    let note = "";
    let re = null;
    if (useRegex) {
      try {
        re = new RegExp(pattern, "i");
      } catch (err) {
        note = `(The pattern is not a valid regular expression: ${err.message}. Searched for it as literal text instead.)
`;
      }
    }
    if (re) {
      const compiled = re;
      test = (line) => compiled.test(line);
    } else {
      const lower = pattern.toLowerCase();
      test = (line) => line.toLowerCase().includes(lower);
    }
    const hits = [];
    for (let i = 0; i < lines.length; i++) if (test(lines[i])) hits.push(i);
    if (hits.length === 0) {
      return `${note}No lines in ${path} contain "${pattern}". The note has ${lines.length} lines (${content.length} characters).`;
    }
    const blocks = hits.slice(0, limit).map((i) => {
      const rows = [];
      for (let j = Math.max(0, i - 1); j <= Math.min(lines.length - 1, i + 1); j++) {
        rows.push(`${j === i ? ">" : " "} ${String(j + 1).padStart(4)} | ${lines[j]}`);
      }
      return rows.join("\n");
    });
    const more = hits.length > limit ? `
\u2026and ${hits.length - limit} more matches.` : "";
    return `${note}${hits.length} match${hits.length === 1 ? "" : "es"} in ${path} (${lines.length} lines). The matching line is marked with ">".
${blocks.join("\n---\n")}${more}`;
  }
};
var listFiles = {
  name: "list_files",
  description: "List the non-markdown files in the vault (attachments: audio and video recordings, images, PDFs, \u2026), optionally filtered by folder, extension or a substring of the name. Newest first. Use it when the user talks about recordings, media or files rather than notes. Attachments cannot be read or edited, only listed and deleted.",
  parameters: {
    type: "object",
    properties: {
      folder: { type: "string", description: "Only files inside this folder (recursive). Omit for the whole vault; use '/' for the vault root only." },
      extension: { type: "string", description: "Only files with this extension, e.g. 'webm', 'm4a', 'pdf' (without the dot)." },
      name_contains: { type: "string", description: "Only files whose name contains this text (case-insensitive)." },
      limit: { type: "integer", description: "Maximum results (default 50, max 300)." }
    }
  },
  mutates: false,
  async execute(args, ctx) {
    const folder = str(args, "folder", false).replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
    const rootOnly = str(args, "folder", false).trim() === "/";
    const extension = str(args, "extension", false).replace(/^\./, "").toLowerCase();
    const nameContains = str(args, "name_contains", false).toLowerCase();
    const limit = int(args, "limit", 50, 1, 300);
    let files = ctx.vault.listAttachments();
    if (rootOnly) files = files.filter((f) => f.folder === "");
    else if (folder) {
      const prefix = folder.toLowerCase() + "/";
      files = files.filter((f) => f.path.toLowerCase().startsWith(prefix));
    }
    if (extension) files = files.filter((f) => f.extension === extension);
    if (nameContains) files = files.filter((f) => f.basename.toLowerCase().includes(nameContains));
    files.sort((a, b) => b.mtime - a.mtime);
    const total = files.length;
    if (total === 0) return "No attachments matched those filters.";
    const rows = files.slice(0, limit).map((f) => `${f.path}  (${formatSize(f.size)}, modified ${isoDate(f.mtime)})`);
    const more = total > limit ? `
\u2026and ${total - limit} more. Narrow the filter or raise the limit.` : "";
    return `${total} file${total === 1 ? "" : "s"}:
${rows.join("\n")}${more}`;
  }
};
var deleteFile = {
  name: "delete_file",
  description: "Move a note or any other vault file (an attachment such as a recording, image or PDF) to the trash. Recoverable, never a permanent delete. The user must approve each deletion; if they reject it, do not try again \u2014 ask what they want instead.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Vault-relative path of the note or file to delete, e.g. 'Courses/CSCI578/2026-11-05.md' or 'Recordings/lecture.webm'." }
    },
    required: ["path"]
  },
  mutates: true,
  async execute(args, ctx) {
    const input = str(args, "path");
    const path = resolveAny(ctx.vault, input);
    if (!path) throw new ToolError(`No file found for "${input}". Use list_notes or list_files to find the exact path.`);
    const isNote = /\.md$/i.test(path);
    let before;
    let binary;
    if (isNote) before = await ctx.vault.read(path);
    else {
      const info = ctx.vault.listAttachments().find((f) => f.path === path);
      before = `(attachment${info ? `, ${formatSize(info.size)}` : ""})`;
      if (!info || info.size <= MAX_UNDO_BINARY_BYTES) {
        try {
          binary = await ctx.vault.readBinary(path);
        } catch {
          binary = void 0;
        }
      }
    }
    await requestApproval(ctx, { tool: "delete_file", path, before, after: "", summary: `Delete ${path} (move to trash)` });
    await ctx.vault.trash(path);
    ctx.recordChange?.({ tool: "delete_file", path, before, after: "", binary });
    return `Moved ${path} to the trash.`;
  }
};
var moveNote = {
  name: "move_note",
  description: "Move or rename a note (or an attachment) to a new path. Wikilinks to it in other notes are updated automatically; missing folders are created. Use it to organise the vault. The user must approve first.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Current path of the note or file." },
      new_path: { type: "string", description: "New vault-relative path, e.g. 'Archive/2025/Old Project.md'. Keep the extension." }
    },
    required: ["path", "new_path"]
  },
  mutates: true,
  async execute(args, ctx) {
    const input = str(args, "path");
    const path = resolveAny(ctx.vault, input);
    if (!path) throw new ToolError(`No file found for "${input}". Use list_notes or list_files to find the exact path.`);
    const isNote = /\.md$/i.test(path);
    const newPath = isNote ? normalizeNotePath(str(args, "new_path"), ctx.configDir) : normalizeFilePath(str(args, "new_path"), ctx.configDir);
    if (newPath === path) return "The new path is the same as the current one; nothing moved.";
    if (ctx.vault.resolveFile(newPath) || ctx.vault.exists(newPath)) throw new ToolError(`"${newPath}" already exists. Choose another path.`);
    await requestApproval(ctx, { tool: "move_note", path, before: path, after: newPath, summary: `Move ${path} \u2192 ${newPath}` });
    await ctx.vault.rename(path, newPath);
    ctx.recordChange?.({ tool: "move_note", path: newPath, before: path, after: newPath });
    return `Moved ${path} to ${newPath}. Links in other notes were updated. The note now exists only at ${newPath}; the old path is gone, so do not read it to verify.`;
  }
};
function formatSize(bytes) {
  if (bytes >= 1e9) return `${(bytes / 1e9).toFixed(2)} GB`;
  if (bytes >= 1e6) return `${(bytes / 1e6).toFixed(1)} MB`;
  if (bytes >= 1e3) return `${(bytes / 1e3).toFixed(0)} kB`;
  return `${bytes} B`;
}
function nearestLines(content, oldText) {
  const lines = content.split("\n");
  const tokens = Array.from(new Set(oldText.split(/[^\p{L}\p{N}_.-]+/u).filter((t2) => t2.length >= 4))).sort(
    (a, b) => b.length - a.length
  );
  for (const token of tokens.slice(0, 4)) {
    const lower = token.toLowerCase();
    const hits = [];
    for (let i = 0; i < lines.length && hits.length < 5; i++) {
      if (lines[i].toLowerCase().includes(lower)) hits.push(i);
    }
    if (hits.length > 0) {
      const rows = hits.map((i) => `${String(i + 1).padStart(4)} | ${lines[i]}`).join("\n");
      return `Lines in the note that contain "${token}" (copy old_text exactly from the note, or call find_in_note for more context):
${rows}`;
    }
  }
  return `Nothing similar was found. The note has ${lines.length} lines (${content.length} characters); use find_in_note or read_note to locate the passage.`;
}
function parseDate(s) {
  const t2 = s.trim();
  if (!t2) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(t2);
  const d = m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : new Date(t2);
  const ms = d.getTime();
  return Number.isFinite(ms) ? ms : null;
}
var readFile = {
  name: "read_file",
  description: "Read the text of an attachment: a PDF (text is extracted per page) or a plain-text file (.txt, .csv, .json, .html, \u2026). Not for notes \u2014 use read_note. Long files are paged with offset.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path of the attachment, e.g. 'Attachments/slides.pdf'." },
      offset: { type: "integer", description: "Character offset to start from (default 0)." }
    },
    required: ["path"]
  },
  mutates: false,
  async execute(args, ctx) {
    const input = str(args, "path");
    const path = ctx.vault.resolveFile(input);
    if (!path) throw new ToolError(`No file found for "${input}". Use list_files to find the exact path.`);
    if (/\.md$/i.test(path)) throw new ToolError(`${path} is a note; use read_note.`);
    if (!ctx.readAttachmentText) throw new ToolError("Reading attachments is not available here.");
    const offset = int(args, "offset", 0, 0, 5e7);
    const text = await ctx.readAttachmentText(path);
    const scannable = !!ctx.describeImage && /\.pdf$/i.test(path);
    if (!text.replace(/^--- Page \d+ ---$/gm, "").trim()) return `${path} contains no extractable text (it may be a scanned image or a binary file).${scannable ? " Read its pages with read_image (path, page)." : ""}`;
    const page = truncate(text, ctx.maxResultChars, offset);
    let out = `# ${path}
length: ${page.total} characters
---
${page.text}`;
    if (scannable && offset === 0) {
      const blank = Array.from(text.matchAll(/^--- Page (\d+) ---\n(?=\s*(?:--- Page|$))/gm), (m) => m[1]);
      if (blank.length) out += `

[Page${blank.length === 1 ? "" : "s"} ${blank.slice(0, 20).join(", ")} ha${blank.length === 1 ? "s" : "ve"} no text layer (scanned). read_image with the path and page reads a scanned page.]`;
    }
    if (page.truncated) out += `

[TRUNCATED at character ${offset + ctx.maxResultChars} of ${page.total}. Call read_file again with offset=${offset + ctx.maxResultChars} to continue.]`;
    return out;
  }
};
function isoDate(ms) {
  return new Date(ms).toISOString().slice(0, 10);
}
var ALL_TOOLS = [
  searchPassages,
  searchNotes,
  readNote,
  readSection,
  findInNote,
  grepVault,
  listSections,
  listNotes,
  listFiles,
  readFile,
  vaultOverview,
  getActiveNote,
  createNote,
  editNote,
  editNotes,
  appendToNote,
  replaceSection,
  replaceNote,
  moveNote,
  deleteFile
];
function toOllamaTools(tools) {
  return tools.map((t2) => ({
    type: "function",
    function: { name: t2.name, description: t2.description, parameters: t2.parameters }
  }));
}

// src/agent.ts
var MAX_AUTO_CONTINUES = 3;
var MAX_CALLS_PER_STEP = 8;
var MAX_REPEATED_CALLS = 3;
function callKey(call) {
  return `${call.function.name} ${canonicalJson(call.function.arguments ?? {})}`;
}
function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const entries = Object.entries(value).filter(([, v]) => v !== void 0).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalJson(v)}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}
var PER_NOTE_TOOLS = /^(read_note|read_section|find_in_note|get_active_note) /;
function invalidateCache(cache, paths) {
  const names = Array.from(paths).map((p) => (p.split("/").pop() ?? p).replace(/\.md$/i, ""));
  for (const key of Array.from(cache.keys())) {
    if (!PER_NOTE_TOOLS.test(key) || names.some((n) => key.includes(n))) cache.delete(key);
  }
}
function repeatedCallNotice(name, priorResult, repeat) {
  const head = priorResult.length > 300 ? priorResult.slice(0, 300) + "\u2026" : priorResult;
  const left = MAX_REPEATED_CALLS - repeat;
  return `Not executed: you already called ${name} with exactly these arguments earlier in this turn (repeat ${repeat} of ${MAX_REPEATED_CALLS}); calling it again returns the same result, which was:
${head}
` + (left > 0 ? `Do something different: change the arguments (if a search found nothing, the pattern or folder was wrong), use another tool, or answer with what you have. After ${left} more repeat${left === 1 ? "" : "s"} this turn ends.` : "The turn now ends; answer with what you have.");
}
var REPEATED_CALLS_WRAP_UP = "You repeated the same tool call with the same arguments several times, so the turn has been stopped. Answer now with what you have found so far, say what is still missing, and if you were searching for something, say which searches found nothing.";
var AUTO_CONTINUE_TEXT = "Yes. Continue without asking again: carry out everything you proposed, for every note involved, in this turn. Reading needs no permission and each change goes through the approval dialog. Report when you are done.";
var LECTURE_TOOLS_HINT = "Lecture Companion is installed: for questions about lectures or meetings (what was said about X, and when; which lecture covered Y), use list_lectures to find the lecture and lecture_transcript with a query to get the timestamped paragraphs, then quote the paragraph and give its [m:ss] time with a wikilink to the lecture note.";
var GROUNDING_PREFIX = "Grounding check:";
var REJECTED_WRITE_NOTICE = "Not executed: the user rejected a change earlier in this turn, so no further changes are made until they answer. Tell them what was rejected and ask what they want instead.";
var REJECTION_QUESTION = "The change was not applied. What would you like me to do instead?";
function withRejectionQuestion(content) {
  return /\?\s*$/.test(content.trim()) || content.includes(REJECTION_QUESTION) ? content : `${content.trimEnd()}

${REJECTION_QUESTION}`;
}
var FOLLOW_THROUGH_TEXT = "You described your next step instead of taking it. Do it now with the tools (reading needs no permission; each change goes through the approval dialog), then give the final answer. Never end a reply by announcing what you will do.";
var FOLLOW_THROUGH_TEXTS = [
  FOLLOW_THROUGH_TEXT,
  `${FOLLOW_THROUGH_TEXT} If the call is large, split it: at most 6 edits per edit_notes call, then the next 6 in the following step.`
];
function announcesNextStep(text) {
  const t2 = text.trim();
  if (!t2 || t2.endsWith("?")) return false;
  const tail = (t2.split(/\n+/).filter((l) => l.trim()).at(-1) ?? "").slice(-300);
  if (/\blet me know\b/i.test(tail)) return false;
  return /\b(i(?:'ll| will| am going to|'m going to| need to| should| can)|let me|next,? i(?:'ll| will)?|now i(?:'ll| will)?)\b[^.!?\n]{0,60}?\b(check|read|open|search|look|grep|list|find|verify|inspect|scan|examine|review|run|edit|update|create|move|rename|remove|delete|fix|apply|write|add|process|compile|handle|clean)\b/i.test(
    tail
  );
}
var READ_TOOLS = /* @__PURE__ */ new Set(["read_note", "read_section", "get_active_note"]);
function pickSources(answer, hits, texts) {
  if (hits.length === 0) return [];
  if (texts) {
    const fragments = quotable(answer);
    const quoted = hits.filter((p) => {
      const text = texts.get(p);
      if (!text) return false;
      const plain = plainText(text);
      return fragments.some((f) => plain.includes(f));
    });
    if (quoted.length) return quoted;
  }
  const lower = answer.toLowerCase();
  const mentioned = hits.filter(
    (p) => p.replace(/\.md$/i, "").split("/").some((seg) => seg.trim().length >= 4 && lower.includes(seg.trim().toLowerCase()))
  );
  if (mentioned.length) return mentioned;
  return hits.length <= 3 ? hits : [];
}
function withSources(content, paths) {
  const links = paths.slice(0, 6).map((p) => `[[${p.replace(/\.md$/i, "")}]]`);
  return `${content.trimEnd()}

Sources: ${links.join(", ")}`;
}
function linkifyNotePaths(text, vault) {
  const parts = text.split(/(```[\s\S]*?```)/);
  return parts.map((part, i) => {
    if (i % 2 === 1) return part;
    return part.replace(/`([^`\n]{1,200}?)`/g, (whole, inner) => {
      const candidate = inner.trim();
      if (!/\.md$/i.test(candidate) && !candidate.includes("/")) return whole;
      if (/[*?<>"]/.test(candidate)) return whole;
      const resolved = vault.resolve(candidate);
      if (!resolved) return whole;
      return `[[${resolved.replace(/\.md$/i, "")}]]`;
    });
  }).join("");
}
function unresolvedLinks(text, vault) {
  const out = /* @__PURE__ */ new Set();
  const prose = text.replace(/```[\s\S]*?```/g, "").replace(/`[^`\n]*`/g, "");
  for (const m of prose.matchAll(/(!?)\[\[([^\]|#]+)(?:[#|][^\]]*)?\]\]/g)) {
    if (m[1] === "!") continue;
    const target = m[2].trim();
    if (!target) continue;
    if (/\.[a-z0-9]{1,5}$/i.test(target) && !/\.md$/i.test(target)) continue;
    if (!vault.resolve(target) && !vault.resolveFile(target)) out.add(target);
  }
  return Array.from(out);
}
function groundingNudge(links, readAnything) {
  const cited = links.map((l) => `[[${l}]]`).join(", ");
  return readAnything ? `${GROUNDING_PREFIX} your answer cites notes that do not exist in the vault (${cited}). Cite only paths that search_notes, list_notes or read_note actually returned, exactly as returned, and correct the answer.` : `${GROUNDING_PREFIX} you have not searched or read anything in this conversation, yet your answer cites notes that do not exist in the vault (${cited}). You cannot know the user's notes from memory. Search with search_notes, read the relevant notes, then answer citing only notes you actually read. If nothing relevant exists, say so.`;
}
function looksLikeChoiceQuestion(text) {
  const t2 = text.trim();
  if (!t2.includes("?")) return false;
  return /\b(which (one|ones|of these|of the|would you|do you|should i)|what would you (like|prefer|rather)|instead\s*\?|or (do|would|should) you\b|\boptions?\s*:)/i.test(t2);
}
function looksLikePermissionQuestion(text) {
  const t2 = text.trim();
  if (!t2.includes("?")) return false;
  const tail = t2.slice(-600);
  if (/\b(would you like|do you want|want me|shall i|should i|may i|can i)\b[^?]{0,40}\b(create|make|write|add|draft|generate|build|compile|consolidate|set up|summari[sz]e|organi[sz]e|turn (this|these|it) into)\b/i.test(tail)) {
    return false;
  }
  const continuing = "(proceed|continue|go ahead|carry on|move on|start|begin|keep going|do (the|all|every|each|that|this|these|those|so|it)|check(ing)? (the )?(full|next|other|remaining|rest)|(read|open|look at|inspect|handle|process|clean up|fix|update|remove|delete|apply|run)(ing)? (the |all |each |every |these |those )?(next|other|remaining|rest|full|same|changes?|edits?|notes?|files?|deletions?))";
  const asks = new RegExp(`\\b(would you like me to|do you want me to|shall i|should i|want me to|may i)\\s+(also\\s+)?${continuing}\\b`, "i");
  return asks.test(tail) || /\b(ready to proceed|(proceed|continue|go ahead|carry on)\s*\?\s*$)/i.test(tail);
}
function newConversation() {
  return { id: `chat-${Date.now().toString(36)}`, messages: [], approveAll: false };
}
function turnContext(vault, now, daily = null) {
  const active = vault.getActiveNotePath();
  return [
    `Today is ${now.toISOString().slice(0, 10)}.`,
    active ? `The user currently has this note open: ${active}` : "No note is currently open in the editor.",
    daily ? `Today's daily note is ${daily.path}${daily.exists ? "" : " (it does not exist yet; create it if the user wants something added to today)"}.` : ""
  ].filter(Boolean).join(" ");
}
function withTurnContext(m) {
  return m.role === "user" && m.context ? { ...m, content: `${m.content}

[State when this message was sent \u2014 ${m.context}]` } : m;
}
function buildSystemPrompt(vault, cfg, conventions = null, gist) {
  const notes = vault.listNotes();
  const lines = [
    "You are an autonomous assistant that lives inside the user's Obsidian vault and runs fully locally. You answer questions from the user's notes, compile information across notes, and edit, reformat, clean up or reorganise notes when asked.",
    "",
    "Work autonomously:",
    "- Finish the whole task in this turn. If it spans many notes, handle them one after another until every one is done; do not stop after the first to report progress.",
    "- Never ask for permission or confirmation to search, read or change notes. Reading needs none, and every write is shown to the user as a diff they approve or reject, so the approval dialog is the confirmation. Do not end a reply with 'Would you like me to proceed?' or 'Shall I check the next note?' \u2014 proceed.",
    "- Do not describe a plan and wait; carry it out. Stop to ask only when the request is genuinely ambiguous in a way that changes the outcome, and then ask one specific question.",
    "- For a task that touches more than two notes, begin with one line stating the plan (which notes, what you will do to each), then start immediately in the same reply; as you go, note each note as done in a few words.",
    "- A question gets an answer, not edits. When the user asks something, answer it from the notes and stop; do not propose, offer or make changes to notes they did not ask for.",
    "- Search snippets are not the note. Before concluding that a note lacks or contains something, read it with read_note, or use find_in_note for one specific passage.",
    "- Never read every note to find something. To find all occurrences of a pattern across the vault (an embed, a tag, a phrase, a heading), use grep_vault; then read_section or find_in_note only where needed. Call at most about 6 tools per step; big batches overflow the context window.",
    "- Never guess a path. The outline below lists every note; to enumerate a folder (which daily notes exist, say) call list_notes with that folder \u2014 it returns every path with its size \u2014 and read only paths it returned. A note that does not exist is not a note to try the next date for.",
    "- To survey one section across many notes (which daily notes have a full '## Capture', which lecture sections are empty), ONE list_sections call with heading: 'Capture' and the folder lists that section of every note with its size and first line; grep_vault with the heading as the pattern and context: 8 shows more of each. Then read_section only the few that matter. Never read the notes one by one.",
    "- A tool call with the same arguments returns the same result; never repeat one. When a search finds nothing, that is the answer for that pattern: change the pattern, the folder or the tool, or report it.",
    "- search_passages and search_notes find notes by topic (meaning and keywords). They cannot find notes that are 'messy', 'long', 'empty' or 'unstructured': such structural questions are answered by list_notes (sizes), list_sections (which sections contain what), grep_vault (headings, patterns) and the outline.",
    "- Clean-ups across many notes: do not survey everything first and act later \u2014 you will run out of steps. When the rule involves two texts (sections that have A and also B, or A but not B), the first call is ONE list_sections({containing: ['![[Recording', '### Summary']}) over the whole vault \u2014 never grep_vault for this, and never read notes to check: it lists the sections that have both texts and, separately, the ones with only some. Every section in the first group becomes one edit_notes item {path, heading: that section's own heading (not the note title), line_contains: '![[Recording', new_text: ''}; the second group is left alone. For a single-pattern clean-up, grep_vault (each match shows its heading) finds the candidates. Then edit_notes, at most 8 edits per call \u2014 one call per note is a natural split \u2014 and the next call in the next step; old_text, when used, is the single matching line, never a whole section. Survey once, then edit; never read the sections one by one, and never describe an edit instead of making it.",
    "- Tool results are authoritative: a successful edit result means the note is written, so do not read it again to verify, and do not re-check notes that were already handled.",
    "",
    "Grounding and style:",
    "- You know nothing about the contents of the user's notes until you read them. The vault outline below tells you which notes exist and their headings, nothing more. Every answer about the notes starts with search_passages or search_notes (or read_note / read_section on a path from the outline), then reading the relevant results. Never answer from memory or assumption, never invent note names, quotes or facts, and cite only notes you actually read. If nothing relevant exists, say so.",
    "- Prefer search_passages for questions: it returns the matching sections verbatim, which is usually enough to answer. Use read_section to get one heading's full text, and read_note only when you need the whole note.",
    "- Refer to notes with wikilinks, e.g. [[Projects/Chess Robot]] (path without the .md extension), never as backticked paths, so the user can click through.",
    `- ${answerLanguageLine(cfg.answerLanguage ?? "")}`,
    "- Keep answers concise and in markdown. When the task is complete, stop calling tools and give a short report of what you did and anything you could not do.",
    "",
    "Editing:",
    "- Small change: locate the exact passage with grep_vault, find_in_note or read_section, then call edit_note with old_text copied verbatim \u2014 the smallest unique passage, usually one line; never paste a whole section as old_text or rewrite it as new_text. If edit_note reports no match, use the candidate lines it returns; never guess at text you have not seen.",
    "- Whole-note rewrite or reformat: replace_note with the complete new content, keeping wikilinks and tags intact. If the note starts with a YAML frontmatter block (--- ... ---), keep it unchanged; if it has none, never add one.",
    "- Compile into a new note with create_note, citing the source notes as wikilinks. Add to the end of a note with append_to_note.",
    "- Non-markdown files (recordings, images, PDFs, \u2026) are attachments: list them with list_files; read the text of a PDF or text file with read_file; they cannot be edited. Move or rename with move_note (links in other notes are updated). Remove any note or attachment with delete_file (it goes to the trash).",
    "- If the user rejects a change, stop, tell them what was rejected and ask what they want instead; never retry the same change.",
    "- Tool arguments must be valid JSON matching the tool's parameters.",
    "",
    `The vault has ${notes.length} markdown notes. Each message from the user ends with a bracketed line giving today's date, the note open in the editor and today's daily note at that moment; the latest one is current.`,
    "",
    "Vault outline (every note, grouped by folder). Each line is `<file>.md \u2014 <gist or headings> <tags>`; a note's path is the folder plus the file name only, never the text after the dash:",
    buildOutline(vault, { budgetChars: outlineBudget(cfg.numCtx, gist !== void 0), gist })
  ];
  if (conventions?.trim()) lines.push("", "The user's vault conventions (from their conventions note; follow them):", conventions.trim());
  if (cfg.extraSystemPrompt.trim()) lines.push("", "Additional instructions from the user:", cfg.extraSystemPrompt.trim());
  return lines.join("\n");
}
var Agent = class {
  constructor(deps) {
    this.deps = deps;
  }
  async run(conversation, userText, callbacks, signal) {
    const cfg = this.deps.getConfig();
    const { client, vault } = this.deps;
    const tools = [...this.deps.tools, ...this.deps.extraTools?.() ?? []];
    const now = this.deps.now ? this.deps.now() : /* @__PURE__ */ new Date();
    const toolByName = new Map(tools.map((t2) => [t2.name, t2]));
    compactHistory(conversation.messages, cfg.numCtx);
    const turn = conversation.messages.length;
    let conventions = null;
    try {
      conventions = await this.deps.readConventions?.() ?? null;
    } catch {
      conventions = null;
    }
    let daily = null;
    try {
      daily = await this.deps.dailyNote?.() ?? null;
    } catch {
      daily = null;
    }
    conversation.messages.push({ role: "user", content: userText, context: turnContext(vault, now, daily) });
    let currentCall = null;
    const changedPaths = /* @__PURE__ */ new Set();
    const ctx = {
      vault,
      search: this.deps.search,
      searchPassages: this.deps.searchPassages,
      maxResultChars: cfg.maxToolResultChars,
      configDir: this.deps.configDir,
      signal,
      readLog: /* @__PURE__ */ new Map(),
      readAttachmentText: this.deps.readAttachmentText,
      lectures: this.deps.lectures?.(),
      describeImage: this.deps.describeImage?.(),
      recordChange: (change) => {
        changedPaths.add(change.path);
        if (!this.deps.undo || !currentCall) return;
        const record = this.deps.undo.push({ ...change, time: now.getTime(), turn, chat: conversation.id });
        callbacks.onChange?.(record, currentCall);
      },
      approve: async (req) => {
        if (cfg.autoApprove || conversation.approveAll) return "approve";
        const decision = await this.deps.approve(req);
        if (decision === "approve-all") conversation.approveAll = true;
        if (decision === "reject") rejected = true;
        return decision;
      }
    };
    let think = cfg.think;
    let rejected = false;
    let autoContinues = 0;
    let groundingNudges = 0;
    let emptyNudges = 0;
    let followThroughNudges = 0;
    let toolsUsed = 0;
    let writes = 0;
    const readPaths = [];
    const hitPaths = [];
    const hitTexts = /* @__PURE__ */ new Map();
    const callCache = /* @__PURE__ */ new Map();
    let repeats = 0;
    let wrapUpText = null;
    const system = { role: "system", content: buildSystemPrompt(vault, cfg, conventions, this.deps.gist) };
    if (toolByName.has("lecture_transcript")) system.content += `

${LECTURE_TOOLS_HINT}`;
    const options = { num_ctx: cfg.numCtx, temperature: cfg.temperature, ...cfg.sampling ?? {} };
    iterations: for (let iteration = 0; iteration < cfg.maxIterations; iteration++) {
      if (signal?.aborted) return;
      const history = trimHistory(conversation.messages, cfg.numCtx, (m) => {
        const header = /^# (.+)$/m.exec(m.content);
        if (m.tool_name === "read_note" && header) ctx.readLog?.delete(header[1].trim());
        if (m.cacheKey) callCache.delete(m.cacheKey);
      });
      callbacks.onStatus?.(iteration === 0 ? "Thinking\u2026" : "Working\u2026");
      callbacks.onAssistantStart?.();
      let response2;
      try {
        response2 = await client.chat({
          model: cfg.model,
          messages: [system, ...history.map(withTurnContext)],
          tools: toOllamaTools(tools),
          think,
          options,
          keep_alive: cfg.keepAlive,
          signal,
          onDelta: (d) => {
            if (d.content) callbacks.onAssistantDelta?.(d.content);
            if (d.thinking) callbacks.onThinkingDelta?.(d.thinking);
          }
        });
      } catch (err) {
        if (signal?.aborted) return;
        if (think !== void 0 && err instanceof OllamaError && /think/i.test(err.message)) {
          think = void 0;
          iteration--;
          continue;
        }
        if (err instanceof OllamaError && /does not support tools/i.test(err.message)) {
          throw new OllamaError(
            `The model "${cfg.model}" does not support tool calling, which this plugin needs. Pick a model with the "tools" capability (for example qwen3.5, qwen3, llama3.1 or mistral) in settings.`
          );
        }
        throw err;
      }
      const assistant = response2.message;
      if (assistant.content) assistant.content = linkifyNotePaths(assistant.content, vault);
      const sources = readPaths.length ? readPaths : pickSources(assistant.content, hitPaths, hitTexts);
      if (!assistant.tool_calls?.length && writes === 0 && sources.length > 0 && !/\[\[/.test(assistant.content) && assistant.content.trim()) {
        assistant.content = withSources(assistant.content, sources);
      }
      if (!assistant.tool_calls?.length && rejected && assistant.content.trim()) assistant.content = withRejectionQuestion(assistant.content);
      if (!assistant.tool_calls?.length && writes === 0 && !rejected && assistant.content.trim() && (cfg.citations ?? "blocks") !== "off" && unresolvedLinks(assistant.content, vault).length === 0) {
        assistant.content = await this.citePassages(assistant.content, [...readPaths, ...hitPaths], cfg, conversation, turn, now, signal);
      }
      conversation.messages.push(assistant);
      callbacks.onAssistantDone?.(assistant);
      if (response2.promptTokens !== void 0) {
        const ms = (ns) => ns === void 0 ? void 0 : Math.round(ns / 1e6);
        callbacks.onUsage?.({
          promptTokens: response2.promptTokens,
          completionTokens: response2.completionTokens ?? 0,
          numCtx: cfg.numCtx,
          promptEvalMs: ms(response2.promptEvalDuration),
          evalMs: ms(response2.evalDuration),
          loadMs: ms(response2.loadDuration)
        });
      }
      const calls = assistant.tool_calls ?? [];
      if (calls.length === 0 && !assistant.content.trim() && emptyNudges < 1) {
        emptyNudges++;
        const nudge = "Your reply was empty. Answer now with what you have found so far; if a step is still missing, do it.";
        conversation.messages.push({ role: "user", content: nudge });
        callbacks.onAutoContinue?.(nudge);
        continue;
      }
      if (calls.length === 0) {
        if (groundingNudges < 1) {
          const bad = unresolvedLinks(assistant.content, vault);
          if (bad.length > 0) {
            groundingNudges++;
            const nudge = groundingNudge(bad, toolsUsed > 0);
            conversation.messages.push({ role: "user", content: nudge });
            callbacks.onAutoContinue?.(nudge);
            continue;
          }
        }
        if (cfg.autoContinue && !rejected && followThroughNudges < FOLLOW_THROUGH_TEXTS.length && announcesNextStep(assistant.content)) {
          const nudge = FOLLOW_THROUGH_TEXTS[followThroughNudges++];
          conversation.messages.push({ role: "user", content: nudge });
          callbacks.onAutoContinue?.(nudge);
          continue;
        }
        if (cfg.autoContinue && !rejected && autoContinues < MAX_AUTO_CONTINUES && looksLikePermissionQuestion(assistant.content) && !looksLikeChoiceQuestion(assistant.content)) {
          autoContinues++;
          conversation.messages.push({ role: "user", content: AUTO_CONTINUE_TEXT });
          callbacks.onAutoContinue?.(AUTO_CONTINUE_TEXT);
          continue;
        }
        return;
      }
      let batchChars = 0;
      const cap = batchBudget(cfg.numCtx);
      for (const [i, call] of calls.entries()) {
        if (signal?.aborted) return;
        if (i >= MAX_CALLS_PER_STEP) {
          const skipped = `Not executed: ${calls.length} tool calls in one step is too many (the first ${MAX_CALLS_PER_STEP} ran). To find which notes contain something use grep_vault or search_passages; then read_section or find_in_note only where needed, a few at a time.`;
          callbacks.onToolStart?.(call);
          callbacks.onToolDone?.(call, skipped, false);
          conversation.messages.push({ role: "tool", content: skipped, tool_name: call.function.name, tool_call_id: call.id });
          continue;
        }
        callbacks.onToolStart?.(call);
        const tool = toolByName.get(call.function.name);
        if (rejected && tool?.mutates) {
          callbacks.onToolDone?.(call, REJECTED_WRITE_NOTICE, false);
          conversation.messages.push({ role: "tool", content: REJECTED_WRITE_NOTICE, tool_name: call.function.name, tool_call_id: call.id });
          continue;
        }
        const key = callKey(call);
        const prior = tool && !tool.mutates ? callCache.get(key) : void 0;
        if (prior !== void 0) {
          repeats++;
          const notice = repeatedCallNotice(call.function.name, prior, repeats);
          callbacks.onToolDone?.(call, notice, false);
          conversation.messages.push({ role: "tool", content: notice, tool_name: call.function.name, tool_call_id: call.id });
          if (repeats >= MAX_REPEATED_CALLS) {
            wrapUpText = REPEATED_CALLS_WRAP_UP;
            break iterations;
          }
          continue;
        }
        toolsUsed++;
        currentCall = call;
        let { result, ok } = await this.executeTool(call, toolByName, ctx, cfg.maxToolResultChars);
        currentCall = null;
        if (tool?.mutates) {
          if (ok && changedPaths.size) invalidateCache(callCache, changedPaths);
          else callCache.clear();
        } else if (tool && ok) callCache.set(key, result);
        changedPaths.clear();
        batchChars += result.length;
        if (batchChars > cap && result.length > 400) {
          result = result.slice(0, 400) + `
[truncated: this batch of ${calls.length} tool calls returned too much at once. Call fewer tools per step (at most ~6) and use grep_vault, search_passages or read_section instead of reading whole notes.]`;
        }
        callbacks.onToolDone?.(call, result, ok);
        const cached = tool && ok && !tool.mutates;
        conversation.messages.push({ role: "tool", content: result, tool_name: call.function.name, tool_call_id: call.id, ...cached ? { cacheKey: key } : {} });
        if (ok) {
          if (tool?.mutates) writes++;
          if (call.function.name === "lecture_transcript") {
            const m = /^# (.+?\.md) \(transcript/m.exec(result);
            if (m && !readPaths.includes(m[1])) readPaths.push(m[1]);
          } else if (READ_TOOLS.has(call.function.name)) {
            const header = /^# (.+?)(?: \(lines [^)]*\))?$/m.exec(result);
            if (header && !readPaths.includes(header[1].trim())) readPaths.push(header[1].trim());
          } else if (call.function.name === "grep_vault") {
            for (const m of result.matchAll(/^(.+?\.md):\d+[ :-]/gm)) if (!hitPaths.includes(m[1])) hitPaths.push(m[1]);
          } else if (call.function.name === "search_passages") {
            for (const block of result.split(/^(?=--- \[\d+\] )/m)) {
              const m = /^--- \[\d+\] (.+?)(?: › .*)? \(score [^)]*\)\n?([\s\S]*)$/.exec(block);
              if (!m) continue;
              if (!hitPaths.includes(m[1])) hitPaths.push(m[1]);
              hitTexts.set(m[1], `${hitTexts.get(m[1]) ?? ""}
${m[2]}`);
            }
          }
        }
      }
    }
    if (signal?.aborted) return;
    callbacks.onAssistantStart?.();
    const response = await this.deps.client.chat({
      model: cfg.model,
      messages: [
        system,
        ...trimHistory(conversation.messages, cfg.numCtx).map(withTurnContext),
        {
          role: "user",
          content: wrapUpText ?? "You have used the maximum number of tool calls for this turn. Answer now with what you have found so far, and say what is still missing."
        }
      ],
      think,
      options,
      keep_alive: cfg.keepAlive,
      signal,
      onDelta: (d) => {
        if (d.content) callbacks.onAssistantDelta?.(d.content);
        if (d.thinking) callbacks.onThinkingDelta?.(d.thinking);
      }
    });
    conversation.messages.push(response.message);
    callbacks.onAssistantDone?.(response.message);
  }
  /**
   * Adds a "Passages:" line linking the paragraphs the answer used in the notes it cites (only
   * notes read or found this turn). Paragraphs without a block id get one proposed; in "blocks"
   * mode the ids for each note are one diff the user approves, and a note whose diff is rejected
   * (or "headings" mode) is linked by heading instead.
   */
  async citePassages(answer, grounded, cfg, conversation, turn, now, signal) {
    const { vault } = this.deps;
    if (/\[\[[^\]]*#\^/.test(answer)) return answer;
    const cited = linkedTargets(answer).map((t2) => vault.resolve(t2)).filter((p) => p !== null && grounded.includes(p));
    const paths = Array.from(new Set(cited)).slice(0, 4);
    if (paths.length === 0) return answer;
    const contents = /* @__PURE__ */ new Map();
    for (const p of paths) {
      try {
        contents.set(p, await vault.read(p));
      } catch {
      }
    }
    const citations = planCitations(answer, Array.from(contents, ([path, content]) => ({ path, content })));
    if (citations.length === 0) return answer;
    const written = /* @__PURE__ */ new Set();
    if ((cfg.citations ?? "blocks") === "blocks") {
      for (const [path, after] of blockIdEdits(citations, contents)) {
        if (signal?.aborted) break;
        const before = contents.get(path) ?? "";
        const n = citations.filter((c) => c.path === path && c.isNew).length;
        const req = { tool: "add_block_ids", path, before, after, summary: `Add ${n} block id${n === 1 ? "" : "s"} to ${path} so the answer can link the exact paragraph${n === 1 ? "" : "s"}` };
        let decision = "approve";
        if (!cfg.autoApprove && !conversation.approveAll) decision = await this.deps.approve(req);
        if (decision === "approve-all") conversation.approveAll = true;
        if (decision === "reject") continue;
        if (signal?.aborted) break;
        try {
          if (await vault.read(path) !== before) continue;
          await vault.modify(path, after);
        } catch {
          continue;
        }
        written.add(path);
        this.deps.undo?.push({ tool: "add_block_ids", path, before, after, time: now.getTime(), turn, chat: conversation.id, summary: req.summary });
      }
    }
    return withPassages(answer, citations, written);
  }
  async executeTool(call, toolByName, ctx, maxChars) {
    const tool = toolByName.get(call.function.name);
    if (!tool) {
      return {
        ok: false,
        result: `Error: unknown tool "${call.function.name}". Available tools: ${Array.from(toolByName.keys()).join(", ")}.`
      };
    }
    try {
      const raw = await tool.execute(call.function.arguments ?? {}, ctx);
      const result = raw.length > maxChars + 500 ? raw.slice(0, maxChars) + `

[Result truncated at ${maxChars} characters.]` : raw;
      return { result, ok: true };
    } catch (err) {
      if (ctx.signal?.aborted) throw err;
      const message = err instanceof ToolError ? err.message : `${err.message ?? err}`;
      return { result: `Error: ${message}`, ok: false };
    }
  }
};
var HISTORY_CTX_CAP = 32768;
function historyBudget(numCtx) {
  return Math.floor(Math.min(numCtx, HISTORY_CTX_CAP) * 3.2 * 0.6);
}
function messageSize(m) {
  return m.content.length + (m.context?.length ?? 0) + (m.thinking?.length ?? 0) + (m.tool_calls ? JSON.stringify(m.tool_calls).length : 0);
}
function compactHistory(messages, numCtx) {
  const budget = historyBudget(numCtx);
  for (const m of messages) {
    if (m.role === "assistant" && m.thinking) delete m.thinking;
    if (m.role === "tool" && m.content.length > 400) m.content = m.content.slice(0, 400) + "\n[earlier tool result shortened]";
  }
  let total = messages.reduce((n, m) => n + messageSize(m), 0);
  while (total > budget) {
    const firstUser = messages.findIndex((m) => m.role === "user");
    const nextUser = messages.findIndex((m, i) => i > firstUser && m.role === "user");
    if (nextUser < 0) break;
    total -= messages.splice(0, nextUser).reduce((n, m) => n + messageSize(m), 0);
  }
  while (messages.length && messages[0].role !== "user") messages.shift();
}
function trimHistory(messages, numCtx, onShortened) {
  const budget = historyBudget(numCtx);
  const size = messageSize;
  let out = messages.map((m) => ({ ...m }));
  const lastUser = out.map((m) => m.role).lastIndexOf("user");
  for (let i = 0; i < lastUser; i++) {
    if (out[i].role === "assistant" && out[i].thinking) delete out[i].thinking;
  }
  let total = out.reduce((n, m) => n + size(m), 0);
  if (total <= budget) return out;
  for (let i = 0; i < lastUser && total > budget; i++) {
    const m = out[i];
    if (m.role === "tool" && m.content.length > 400) {
      total -= m.content.length - 400;
      m.content = m.content.slice(0, 400) + "\n[earlier tool result shortened]";
    }
  }
  while (total > budget && out.length > 1) {
    const firstUser = out.findIndex((m) => m.role === "user");
    const nextUser = out.findIndex((m, i) => i > firstUser && m.role === "user");
    if (nextUser < 0) break;
    const dropped = out.splice(0, nextUser);
    total -= dropped.reduce((n, m) => n + size(m), 0);
  }
  const lastUserNow = out.map((m) => m.role).lastIndexOf("user");
  const current2 = out.map((m, i) => i > lastUserNow && m.role === "tool" ? i : -1).filter((i) => i >= 0);
  for (let k = 0; k < current2.length - 2 && total > budget; k++) {
    const m = out[current2[k]];
    if (m.content.length > 600) {
      total -= m.content.length - 600;
      m.content = m.content.slice(0, 600) + "\n[earlier result in this turn shortened to save context; call the tool again if you still need it]";
      onShortened?.(m);
    }
  }
  while (out.length && out[0].role !== "user") out.shift();
  return out;
}
function batchBudget(numCtx) {
  return Math.floor(numCtx * 3.2 * 0.25);
}

// src/approval-modal.ts
var import_obsidian2 = require("obsidian");
var ApprovalModal = class extends import_obsidian2.Modal {
  constructor(app, req) {
    super(app);
    this.req = req;
    this.result = new Promise((res) => this.resolve = res);
  }
  decision = "reject";
  resolve;
  result;
  onOpen() {
    const { contentEl, titleEl, modalEl } = this;
    modalEl.addClass("lva-approval-modal");
    titleEl.setText(this.req.summary);
    const diff = computeDiff(this.req.before, this.req.after);
    const meta = contentEl.createDiv({ cls: "lva-approval-meta" });
    meta.createSpan({ text: this.req.path, cls: "lva-approval-path" });
    meta.createSpan({ text: `+${diff.added} \u2212${diff.removed}`, cls: "lva-approval-stats" });
    const pre = contentEl.createEl("pre", { cls: "lva-diff", attr: { tabindex: "0", role: "region", "aria-label": `${t("approve.diff")}: ${this.req.path}, +${diff.added} \u2212${diff.removed}` } });
    for (const line of diff.lines) {
      const row = pre.createDiv({ cls: `lva-diff-line lva-diff-${line.type}` });
      row.createSpan({ cls: "lva-diff-gutter", text: line.type === "add" ? "+" : line.type === "remove" ? "\u2212" : " ", attr: { "aria-label": line.type === "add" ? "added" : line.type === "remove" ? "removed" : "unchanged" } });
      row.createSpan({ cls: "lva-diff-text", text: line.text });
    }
    const buttons = contentEl.createDiv({ cls: "lva-approval-buttons" });
    const reject = buttons.createEl("button", { text: t("approve.reject") });
    reject.addEventListener("click", () => this.finish("reject"));
    const approveAll = buttons.createEl("button", { text: t("approve.all") });
    approveAll.addEventListener("click", () => this.finish("approve-all"));
    const approve = buttons.createEl("button", { text: t("approve.approve"), cls: "mod-cta" });
    approve.addEventListener("click", () => this.finish("approve"));
    approve.focus();
    contentEl.createDiv({ cls: "lva-approval-hint", text: t("approve.hint") });
    this.scope.register([], "Enter", (e) => {
      const focused = activeDocument.activeElement;
      if (focused && focused.instanceOf(HTMLButtonElement) && focused !== approve) return true;
      e.preventDefault();
      this.finish("approve");
      return false;
    });
    this.scope.register([], "a", (e) => {
      e.preventDefault();
      this.finish("approve-all");
      return false;
    });
  }
  finish(decision) {
    this.decision = decision;
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    this.resolve(this.decision);
  }
};

// src/index.ts
var SHARDS = 32;
function encodeVec(f) {
  const bytes = new Uint8Array(f.buffer, f.byteOffset, f.byteLength);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 32768) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 32768));
  }
  return btoa(bin);
}
function decodeVec(s) {
  const bin = atob(s);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Float32Array(bytes.buffer);
}
function normalize(v) {
  let n = 0;
  for (let i = 0; i < v.length; i++) n += v[i] * v[i];
  n = Math.sqrt(n);
  if (n > 0 && Math.abs(n - 1) > 1e-6) for (let i = 0; i < v.length; i++) v[i] /= n;
  return v;
}
function dot(a, b) {
  let d = 0;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) d += a[i] * b[i];
  return d;
}
function shardOf(path, shards = SHARDS) {
  let h = 2166136261;
  for (let i = 0; i < path.length; i++) {
    h ^= path.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h % shards;
}
function cosine(a, b) {
  let dot2 = 0;
  let na = 0;
  let nb = 0;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    dot2 += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dot2 / (Math.sqrt(na) * Math.sqrt(nb));
}
function embedInput(model, text, kind) {
  if (/nomic-embed/i.test(model)) {
    return `${kind === "query" ? "search_query" : "search_document"}: ${text}`;
  }
  return text;
}
var SemanticIndex = class {
  constructor(client, vault, store, opts) {
    this.client = client;
    this.vault = vault;
    this.store = store;
    this.opts = opts;
    this.model = opts.getModel();
  }
  model;
  dims = 0;
  files = /* @__PURE__ */ new Map();
  /** Kept in step with `files`, so status() costs nothing however large the vault is. */
  totalChunks = 0;
  queue = /* @__PURE__ */ new Set();
  processing = false;
  building = false;
  lastError;
  saveTimer = null;
  abort = null;
  dirty = false;
  dirtyShards = /* @__PURE__ */ new Set();
  lastFlush = Date.now();
  /** Model, dimensions and shard count of the manifest on disk, so an unchanged one is not written again. */
  manifestKey = "";
  /** The flush in progress: flushes run one after another, never side by side. */
  flushing = Promise.resolve();
  get sharded() {
    return !!(this.store.loadShard && this.store.saveShard && this.store.saveManifest);
  }
  setFile(path, file) {
    const old = this.files.get(path);
    if (old) this.totalChunks -= old.chunks.length;
    if (file) {
      this.files.set(path, file);
      this.totalChunks += file.chunks.length;
    } else this.files.delete(path);
    this.dirty = true;
    this.dirtyShards.add(shardOf(path));
  }
  clear() {
    this.files.clear();
    this.totalChunks = 0;
    this.dims = 0;
    this.model = this.opts.getModel();
    this.dirty = true;
    for (let i = 0; i < SHARDS; i++) this.dirtyShards.add(i);
  }
  adopt(files) {
    for (const [path, f] of Object.entries(files)) {
      const chunks = f.chunks.map((c) => ({ heading: c.heading, text: c.text, vec: normalize(decodeVec(c.vec)) }));
      this.files.set(path, { mtime: f.mtime, chunks });
      this.totalChunks += chunks.length;
    }
  }
  async load() {
    try {
      const loaded = await this.store.load();
      if (loaded && loaded.model === this.opts.getModel()) {
        this.files.clear();
        this.totalChunks = 0;
        this.model = loaded.model;
        this.dims = loaded.dims;
        if (loaded.version === 2) {
          if (!this.store.loadShard) throw new Error("the index is stored in shards this build cannot read");
          for (let i = 0; i < loaded.shards; i++) {
            try {
              const shard = await this.store.loadShard(i);
              if (shard) this.adopt(shard);
            } catch (err) {
              this.lastError = `Could not load index: part ${i} is unreadable (${err.message})`;
              this.dirty = true;
              if (i < SHARDS) this.dirtyShards.add(i);
            }
          }
          if (loaded.shards !== SHARDS) {
            this.dirty = true;
            for (let i = 0; i < SHARDS; i++) this.dirtyShards.add(i);
          } else this.manifestKey = `${loaded.model}|${loaded.dims}|${SHARDS}`;
        } else if (loaded.version === 1) {
          this.adopt(loaded.files);
          if (this.sharded) {
            this.dirty = true;
            for (let i = 0; i < SHARDS; i++) this.dirtyShards.add(i);
            this.scheduleSave();
          }
        }
      } else if (loaded && this.sharded) {
        for (let i = 0; i < SHARDS; i++) this.dirtyShards.add(i);
      }
    } catch (err) {
      this.lastError = `Could not load index: ${err.message}`;
    }
    this.emit();
  }
  status() {
    return {
      enabled: this.opts.isEnabled(),
      building: this.building || this.processing,
      indexedFiles: this.files.size,
      totalChunks: this.totalChunks,
      pending: this.queue.size,
      lastError: this.lastError
    };
  }
  get ready() {
    return this.opts.isEnabled() && this.files.size > 0;
  }
  /** The indexed text of a note (its chunks joined), when its index entry is current; for keyword search without a disk read. */
  textFor(path, mtime) {
    const f = this.files.get(path);
    if (!f || f.mtime !== mtime) return void 0;
    return f.chunks.map((c) => c.heading ? `${c.heading}
${c.text}` : c.text).join("\n");
  }
  /** Queue every note whose mtime changed or that is missing from the index. */
  async syncAll(force = false) {
    if (!this.opts.isEnabled()) return;
    if (force || this.model !== this.opts.getModel()) this.clear();
    const live = /* @__PURE__ */ new Set();
    for (const note of this.vault.listNotes()) {
      if (!this.opts.shouldIndex(note.path)) continue;
      live.add(note.path);
      const stored = this.files.get(note.path);
      if (!stored || stored.mtime !== note.mtime) this.queue.add(note.path);
    }
    for (const path of Array.from(this.files.keys())) {
      if (!live.has(path)) this.remove(path);
    }
    this.building = this.queue.size > 0;
    this.emit();
    await this.process();
  }
  /** Cancel in-flight embedding work. Queued files are kept for the next sync. */
  cancel() {
    this.abort?.abort();
  }
  enqueue(path) {
    if (!this.opts.isEnabled() || !this.opts.shouldIndex(path)) return;
    this.queue.add(path);
    void this.process();
  }
  remove(path) {
    if (this.files.has(path)) {
      this.setFile(path, null);
      this.scheduleSave();
    }
    this.queue.delete(path);
    this.emit();
  }
  rename(oldPath, newPath) {
    const entry = this.files.get(oldPath);
    this.remove(oldPath);
    if (entry && this.opts.shouldIndex(newPath)) {
      this.setFile(newPath, entry);
      this.scheduleSave();
    }
    this.emit();
  }
  async queryVector(query, signal) {
    const model = this.opts.getModel();
    const [qv] = await this.client.embed(model, [embedInput(model, query, "query")], signal);
    return normalize(new Float32Array(qv));
  }
  async search(query, limit, signal) {
    if (!this.ready) return [];
    const q = await this.queryVector(query, signal);
    const best = [];
    for (const [path, file] of this.files) {
      let top = -2;
      let idx = -1;
      for (let i = 0; i < file.chunks.length; i++) {
        const s = dot(q, file.chunks[i].vec);
        if (s > top) {
          top = s;
          idx = i;
        }
      }
      if (idx >= 0) best.push({ path, score: top, idx });
    }
    best.sort((a, b) => b.score - a.score);
    return best.slice(0, limit).map((b) => {
      const chunk = this.files.get(b.path).chunks[b.idx];
      return { path: b.path, score: b.score, heading: chunk.heading || void 0, snippet: chunk.text.replace(/\s+/g, " ").slice(0, 280) };
    });
  }
  /**
   * Chunk-level search: the best-matching sections across the vault, verbatim, at most
   * `perNote` from any one note so a single long note cannot crowd out the others.
   */
  async searchPassages(query, limit, perNote = 3, signal) {
    if (!this.ready) return [];
    const q = await this.queryVector(query, signal);
    const scored = [];
    for (const [path, file] of this.files) {
      const mine = [];
      for (let i = 0; i < file.chunks.length; i++) mine.push({ path, score: dot(q, file.chunks[i].vec), idx: i });
      if (mine.length > perNote) mine.sort((a, b) => b.score - a.score);
      for (let i = 0; i < Math.min(perNote, mine.length); i++) scored.push(mine[i]);
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, limit).map((s) => {
      const chunk = this.files.get(s.path).chunks[s.idx];
      return { path: s.path, heading: chunk.heading, text: chunk.text, score: s.score };
    });
  }
  /** One unit vector per indexed note: the normalised mean of its chunk vectors. */
  noteVectors() {
    const out = /* @__PURE__ */ new Map();
    for (const [path, file] of this.files) {
      if (file.chunks.length === 0) continue;
      const sum = new Float32Array(file.chunks[0].vec.length);
      for (const c of file.chunks) for (let i = 0; i < sum.length; i++) sum[i] += c.vec[i];
      out.set(path, normalize(sum));
    }
    return out;
  }
  async process() {
    if (this.processing) return;
    this.processing = true;
    this.abort = new AbortController();
    const signal = this.abort.signal;
    const batchSize = this.opts.batchSize ?? 64;
    let mtimes = null;
    const mtimeOf = (path) => {
      if (this.queue.size < 8 && !mtimes) return this.vault.listNotes().find((n) => n.path === path)?.mtime;
      mtimes ??= new Map(this.vault.listNotes().map((n) => [n.path, n.mtime]));
      return mtimes.get(path) ?? this.vault.listNotes().find((n) => n.path === path)?.mtime;
    };
    let lastEmit = 0;
    try {
      while (this.queue.size > 0 && !signal.aborted) {
        const path = this.queue.values().next().value;
        this.queue.delete(path);
        if (!this.vault.exists(path)) {
          this.remove(path);
          continue;
        }
        const mtime = mtimeOf(path);
        const content = await this.vault.read(path);
        const model = this.opts.getModel();
        const chunks = chunkMarkdown(content);
        const chunkKey = (c) => `${c.heading}
${c.text}`;
        const known = /* @__PURE__ */ new Map();
        for (const c of this.files.get(path)?.chunks ?? []) known.set(chunkKey(c), c.vec);
        const vecs = chunks.map((c) => known.get(chunkKey(c)));
        const missing = chunks.map((_, i) => i).filter((i) => vecs[i] === void 0);
        const inputs = missing.map(
          (i) => embedInput(model, `${noteTitle(path)}${chunks[i].heading ? ` > ${chunks[i].heading}` : ""}
${chunks[i].text}`, "document")
        );
        for (let i = 0; i < inputs.length; i += batchSize) {
          const vectors = await this.client.embed(model, inputs.slice(i, i + batchSize), signal);
          if (vectors.length && this.dims === 0) this.dims = vectors[0].length;
          vectors.forEach((v, k) => vecs[missing[i + k]] = normalize(new Float32Array(v)));
        }
        this.setFile(path, { mtime: mtime ?? Date.now(), chunks: chunks.map((c, i) => ({ heading: c.heading, text: c.text, vec: vecs[i] })) });
        this.lastError = void 0;
        this.scheduleSave();
        const now = Date.now();
        if (now - lastEmit > 250 || this.queue.size === 0) {
          lastEmit = now;
          this.emit();
        }
        if (this.sharded && now - this.lastFlush > 6e4) await this.flush();
      }
    } catch (err) {
      if (!signal.aborted) this.lastError = err.message;
    } finally {
      this.processing = false;
      this.building = false;
      this.abort = null;
      this.emit();
      await this.flush();
    }
  }
  scheduleSave() {
    if (this.saveTimer !== null) window.clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => void this.flush(), 3e3);
  }
  stored(file) {
    return { mtime: file.mtime, chunks: file.chunks.map((c) => ({ heading: c.heading, text: c.text, vec: encodeVec(c.vec) })) };
  }
  /** Saves what changed. Calls queue up: a second flush starting while one is still writing could have its newer shard overwritten by the first one's older copy. */
  flush() {
    this.flushing = this.flushing.then(() => this.doFlush());
    return this.flushing;
  }
  async doFlush() {
    if (this.saveTimer !== null) {
      window.clearTimeout(this.saveTimer);
      this.saveTimer = null;
    }
    if (!this.dirty) return;
    this.dirty = false;
    this.lastFlush = Date.now();
    const shards = Array.from(this.dirtyShards);
    this.dirtyShards.clear();
    try {
      if (this.sharded) {
        const want = new Set(shards);
        const buckets = new Map(shards.map((i) => [i, {}]));
        for (const [path, file] of this.files) {
          const i = shardOf(path);
          if (want.has(i)) buckets.get(i)[path] = this.stored(file);
        }
        for (const i of shards) {
          await this.store.saveShard(i, buckets.get(i));
          buckets.delete(i);
        }
        const key = `${this.model}|${this.dims}|${SHARDS}`;
        if (key !== this.manifestKey) {
          await this.store.saveManifest({ version: 2, model: this.model, dims: this.dims, shards: SHARDS });
          this.manifestKey = key;
        }
      } else {
        const files = {};
        for (const [path, file] of this.files) files[path] = this.stored(file);
        await this.store.save({ version: 1, model: this.model, dims: this.dims, files });
      }
    } catch (err) {
      this.dirty = true;
      for (const i of shards) this.dirtyShards.add(i);
      this.lastError = `Could not save index: ${err.message}`;
      this.emit();
    }
  }
  emit() {
    this.opts.onStatus?.(this.status());
  }
};
function noteTitle(path) {
  const base = path.split("/").pop() ?? path;
  return base.replace(/\.md$/i, "");
}

// src/gardener.ts
var CAP = { broken: 60, orphans: 40, mentions: 50, stubs: 30, inboxes: 40, duplicates: 20 };
var LEGACY_SUGGESTIONS_NOTE = "Vault Suggestions.md";
var CHAT_CAP = 15;
var EXHAUSTIVE_PAIRS = 1500;
var MIN_LINE_OVERLAP = 0.5;
function basenameOf(path) {
  return (path.split("/").pop() ?? path).replace(/\.md$/i, "");
}
var noMd = (path) => path.replace(/\.md$/i, "");
function stripFrontmatter2(content) {
  return content.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n?/, "");
}
function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function maskProse(content) {
  const blank = (s) => s.replace(/[^\n]/g, " ");
  return content.replace(/^---\r?\n[\s\S]*?\r?\n---(?=\r?\n|$)/, blank).replace(/```[\s\S]*?```/g, blank).replace(/~~~[\s\S]*?~~~/g, blank).replace(/<!--[\s\S]*?-->/g, blank).replace(/%%[\s\S]*?%%/g, blank).replace(/`[^`\n]*`/g, blank).replace(/!?\[\[[^\]\n]*\]\]/g, blank).replace(/!?\[[^\]\n]*\]\([^)\n]*\)/g, blank).replace(/https?:\/\/\S+/g, blank).replace(/^#{1,6}\s.*$/gm, blank).replace(/^\s*\|.*$/gm, blank);
}
function isWordChar(ch) {
  return /[\p{L}\p{N}_]/u.test(ch);
}
function indexOfWord(hay, needle, from = 0) {
  for (; ; ) {
    const at = hay.indexOf(needle, from);
    if (at < 0) return -1;
    const before = at === 0 ? "" : hay[at - 1];
    const after = at + needle.length >= hay.length ? "" : hay[at + needle.length];
    if ((!before || !isWordChar(before)) && (!after || !isWordChar(after))) return at;
    from = at + needle.length;
  }
}
function countWordOccurrences(hay, needle) {
  let count = 0;
  let from = 0;
  for (; ; ) {
    const at = indexOfWord(hay, needle, from);
    if (at < 0) return count;
    count++;
    from = at + needle.length;
  }
}
function mentionName(basename) {
  const name = basename.trim();
  if (name.length < 6 || /^\d{4}-\d{2}-\d{2}/.test(name)) return null;
  const exact = /\p{Lu}/u.test(name);
  if (/[\s_-]/.test(name)) return { name, exact };
  const distinctive = /\d/.test(name) || /\p{Lu}/u.test(name.slice(1)) && /\p{Ll}/u.test(name);
  return distinctive ? { name, exact: true } : null;
}
function findMention(content, m) {
  const masked = maskProse(content);
  const at = m.exact ? indexOfWord(masked, m.name) : indexOfWord(masked.toLowerCase(), m.name.toLowerCase());
  return at < 0 ? null : { at, text: content.slice(at, at + m.name.length) };
}
function countMentions(masked, maskedLower, m) {
  return m.exact ? countWordOccurrences(masked, m.name) : countWordOccurrences(maskedLower, m.name.toLowerCase());
}
function comparable(content) {
  return stripFrontmatter2(content).replace(/\[\[([^\]|#\n]*\/)?([^\]|#\n]+)([^\]\n]*)\]\]/g, "[[$2$3]]").split(/\r?\n/).map((l) => l.trim()).filter(Boolean).join("\n");
}
function substantialLines(content) {
  const out = /* @__PURE__ */ new Set();
  for (const l of comparable(content).split("\n")) {
    if (l.length >= 20 && !l.startsWith(">")) out.add(l.toLowerCase());
  }
  return out;
}
async function gardenVault(vault, opts = {}) {
  const daily = (opts.dailyFolder ?? "").replace(/^\/+|\/+$/g, "");
  const isDaily = (path) => daily ? path.startsWith(daily + "/") : /^\d{4}-\d{2}-\d{2}$/.test(basenameOf(path));
  const notes = vault.listNotes().filter((n) => !(opts.exclude?.(n.path) ?? false) && n.path !== LEGACY_SUGGESTIONS_NOTE);
  const texts = /* @__PURE__ */ new Map();
  for (const n of notes) texts.set(n.path, await vault.read(n.path));
  const paths = new Set(notes.map((n) => n.path));
  const report = {
    generated: (opts.now ?? /* @__PURE__ */ new Date()).toISOString().slice(0, 10),
    notes: notes.length,
    broken: [],
    orphans: [],
    mentions: [],
    stubs: [],
    inboxes: [],
    duplicates: []
  };
  const byName = /* @__PURE__ */ new Map();
  const addName = (name, path) => byName.set(name, [...byName.get(name) ?? [], path]);
  for (const n of vault.listNotes()) addName(n.basename.toLowerCase(), n.path);
  for (const f of vault.listAttachments()) addName(`${f.basename}.${f.extension}`.toLowerCase(), f.path);
  const linked = /* @__PURE__ */ new Map();
  for (const n of notes) {
    const meta = vault.getMetadata(n.path);
    const seen = /* @__PURE__ */ new Set();
    const resolvedLinks = /* @__PURE__ */ new Set();
    linked.set(n.path, resolvedLinks);
    for (const raw of meta.links) {
      const target = raw.split("#")[0].split("|")[0].trim();
      if (!target || seen.has(target)) continue;
      seen.add(target);
      const resolved = vault.resolve(target) ?? vault.resolveFile(target);
      const wanted = noMd(target).toLowerCase();
      if (resolved && (!target.includes("/") || noMd(resolved).toLowerCase().endsWith(wanted) || resolved.toLowerCase().endsWith(wanted))) {
        resolvedLinks.add(resolved);
        continue;
      }
      const candidates = byName.get(noMd(target.split("/").pop() ?? target).toLowerCase()) ?? byName.get((target.split("/").pop() ?? target).toLowerCase()) ?? [];
      report.broken.push(candidates.length === 1 ? { path: n.path, target, suggestion: candidates[0] } : { path: n.path, target });
    }
    if (!isDaily(n.path) && meta.links.length === 0 && meta.backlinks.filter((b) => paths.has(b)).length === 0) report.orphans.push(n.path);
  }
  report.broken.sort((x, y) => Number(!x.suggestion) - Number(!y.suggestion));
  const nameCount = /* @__PURE__ */ new Map();
  for (const n of notes) nameCount.set(n.basename.toLowerCase(), (nameCount.get(n.basename.toLowerCase()) ?? 0) + 1);
  const names = notes.map((n) => ({ path: n.path, m: mentionName(basenameOf(n.path)) })).filter((x) => x.m !== null && nameCount.get(x.m.name.toLowerCase()) === 1);
  const nameWords = /* @__PURE__ */ new Map();
  const wordUse = /* @__PURE__ */ new Map();
  for (const x of names) {
    const ws = Array.from(new Set(x.m.name.toLowerCase().match(/[\p{L}\p{N}_]+/gu) ?? []));
    nameWords.set(x.path, ws);
    for (const w of ws) wordUse.set(w, (wordUse.get(w) ?? 0) + 1);
  }
  const namesByWord = /* @__PURE__ */ new Map();
  for (const x of names) {
    const ws = nameWords.get(x.path) ?? [];
    if (ws.length === 0) continue;
    const key = ws.reduce((best, w) => (wordUse.get(w) ?? 0) < (wordUse.get(best) ?? 0) ? w : best, ws[0]);
    const list = namesByWord.get(key);
    if (list) list.push(x);
    else namesByWord.set(key, [x]);
  }
  for (const n of notes) {
    const masked = maskProse(texts.get(n.path) ?? "");
    if (!masked.trim()) continue;
    const maskedLower = masked.toLowerCase();
    const words = new Set(maskedLower.match(/[\p{L}\p{N}_]+/gu) ?? []);
    const candidates = [];
    for (const w of words) {
      const list = namesByWord.get(w);
      if (!list) continue;
      for (const x of list) if ((nameWords.get(x.path) ?? []).every((nw) => words.has(nw))) candidates.push(x);
    }
    for (const other of candidates) {
      if (other.path === n.path || linked.get(n.path)?.has(other.path)) continue;
      if (n.path.toLowerCase().startsWith(noMd(other.path).toLowerCase() + "/")) continue;
      const count = countMentions(masked, maskedLower, other.m);
      if (count > 0) report.mentions.push({ path: n.path, target: other.path, count });
    }
  }
  report.mentions.sort((a, b) => b.count - a.count || a.path.localeCompare(b.path));
  for (const n of notes) {
    if (isDaily(n.path)) continue;
    if (/^(```|~~~)|!\[\[/m.test(texts.get(n.path) ?? "")) continue;
    const body = stripFrontmatter2(texts.get(n.path) ?? "").replace(/^#{1,6}\s.*$/gm, " ").replace(/\s+/g, " ").trim();
    if (body.length < 80) report.stubs.push({ path: n.path, chars: body.length });
  }
  const heading = (opts.inboxHeading ?? "Capture").replace(/^#+\s*/, "").trim();
  for (const n of notes) {
    if (!isDaily(n.path)) continue;
    const section = extractSection(texts.get(n.path) ?? "", heading);
    if (!section) continue;
    const lines = section.text.split("\n").slice(1).filter((l) => l.trim()).length;
    if (lines >= 3) report.inboxes.push({ path: n.path, lines });
  }
  report.inboxes.sort((a, b) => b.lines - a.lines || a.path.localeCompare(b.path));
  const folderSize = /* @__PURE__ */ new Map();
  for (const n of notes) folderSize.set(n.folder, (folderSize.get(n.folder) ?? 0) + 1);
  const groups = /* @__PURE__ */ new Map();
  for (const n of notes) {
    const text = comparable(texts.get(n.path) ?? "");
    if (text.length < 80) continue;
    groups.set(text, [...groups.get(text) ?? [], n.path]);
  }
  const copies = /* @__PURE__ */ new Set();
  for (const group of groups.values()) {
    if (group.length < 2) continue;
    const rank = (p) => vault.getMetadata(p).backlinks.filter((b) => !group.includes(b)).length;
    const folderOf = (p) => p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "";
    const ordered = group.map((p) => ({ p, links: rank(p), folder: folderSize.get(folderOf(p)) ?? 0 })).sort((x, y) => y.links - x.links || y.folder - x.folder || x.p.length - y.p.length || x.p.localeCompare(y.p));
    for (const other of ordered.slice(1)) {
      report.duplicates.push({ a: ordered[0].p, b: other.p, score: 1, identical: true });
      copies.add(other.p);
    }
  }
  if (opts.noteVectors) {
    const threshold = opts.duplicateThreshold ?? 0.9;
    const candidates = notes.filter((n) => !isDaily(n.path) && !copies.has(n.path) && (texts.get(n.path)?.length ?? 0) >= 200 && opts.noteVectors.has(n.path));
    const lineSets = /* @__PURE__ */ new Map();
    const linesOf = (p) => {
      let s = lineSets.get(p);
      if (!s) lineSets.set(p, s = substantialLines(texts.get(p) ?? ""));
      return s;
    };
    const similar = [];
    let pairsOf;
    if (candidates.length <= EXHAUSTIVE_PAIRS) {
      pairsOf = function* (i) {
        for (let j = i + 1; j < candidates.length; j++) yield j;
      };
    } else {
      const byLine = /* @__PURE__ */ new Map();
      candidates.forEach((c, i) => {
        for (const l of linesOf(c.path)) {
          const list = byLine.get(l);
          if (list) list.push(i);
          else byLine.set(l, [i]);
        }
      });
      const partners = candidates.map(() => /* @__PURE__ */ new Set());
      for (const list of byLine.values()) {
        if (list.length < 2 || list.length > 50) continue;
        for (let a = 0; a < list.length; a++) for (let b = a + 1; b < list.length; b++) partners[list[a]].add(list[b]);
      }
      pairsOf = (i) => partners[i];
    }
    for (let i = 0; i < candidates.length; i++) {
      for (const j of pairsOf(i)) {
        if (cosine(opts.noteVectors.get(candidates[i].path), opts.noteVectors.get(candidates[j].path)) < threshold) continue;
        const [x, y] = [linesOf(candidates[i].path), linesOf(candidates[j].path)];
        const [small, large] = x.size <= y.size ? [x, y] : [y, x];
        if (small.size < 3) continue;
        let shared = 0;
        for (const l of small) if (large.has(l)) shared++;
        const score = shared / small.size;
        if (score < MIN_LINE_OVERLAP) continue;
        const [a, b] = x.size >= y.size ? [candidates[i].path, candidates[j].path] : [candidates[j].path, candidates[i].path];
        similar.push({ a, b, score, identical: false });
      }
    }
    similar.sort((p, q) => q.score - p.score);
    report.duplicates.push(...similar);
  }
  report.broken = report.broken.slice(0, CAP.broken);
  report.orphans = report.orphans.sort().slice(0, CAP.orphans);
  report.mentions = report.mentions.slice(0, CAP.mentions);
  report.stubs = report.stubs.sort((a, b) => a.chars - b.chars).slice(0, CAP.stubs);
  report.inboxes = report.inboxes.slice(0, CAP.inboxes);
  report.duplicates = report.duplicates.slice(0, CAP.duplicates);
  return report;
}
var link = (path) => `[[${noMd(path)}]]`;
function sectionLines(r, section) {
  switch (section) {
    case "broken":
      return r.broken.map((b) => `${link(b.path)} links to \`[[${b.target}]]\`${b.suggestion ? ` \u2014 it is now ${link(b.suggestion)}` : ""}`);
    case "inboxes":
      return r.inboxes.map((i) => `${link(i.path)} \u2014 ${i.lines} lines`);
    case "mentions":
      return r.mentions.map((m) => `${link(m.path)} mentions ${link(m.target)} ${m.count === 1 ? "once" : `${m.count} times`} without linking`);
    case "duplicates":
      return r.duplicates.map(
        (d) => d.identical ? `${link(d.b)} is a copy of ${link(d.a)} (identical text)` : `${link(d.b)} shares ${Math.round(d.score * 100)}% of its lines with ${link(d.a)}`
      );
    case "orphans":
      return r.orphans.map((o) => link(o));
    case "stubs":
      return r.stubs.map((s) => `${link(s.path)} \u2014 ${s.chars} characters`);
  }
}
var SECTIONS = [
  { id: "broken", title: "Broken links", about: "Links to notes or files that do not exist. Where the target only moved, I can repoint the link; the rest need you (recreate the file, or tell me to remove the link)." },
  { id: "inboxes", title: "Daily inboxes with content", about: "Capture sections that grew past a line or two." },
  { id: "mentions", title: "Unlinked mentions", about: "A note's name written in another note that does not link to it." },
  { id: "duplicates", title: "Duplicates", about: "The same text in two notes." },
  { id: "orphans", title: "Orphans", about: "Notes with no links in or out." },
  { id: "stubs", title: "Stubs", about: "Notes with almost no content. Fill them in, merge them or delete them; tell me which." }
];
function renderGardenChat(r, opts = {}) {
  const out = [];
  const total = r.broken.length + r.orphans.length + r.mentions.length + r.stubs.length + r.inboxes.length + r.duplicates.length;
  if (total === 0) {
    out.push(`**Vault suggestions** \u2014 checked ${r.notes} notes and found nothing to suggest: no broken links, orphans, unlinked mentions, stubs, full inboxes or duplicates.`);
  } else {
    out.push(`**Vault suggestions** \u2014 checked ${r.notes} notes. Nothing has been changed or written. The buttons below act on what is listed here (each change is shown as a diff first), or tell me what to do with any of it.`);
  }
  for (const s of SECTIONS) {
    const lines = sectionLines(r, s.id);
    if (lines.length === 0) continue;
    out.push("", `**${s.title} (${lines.length})** \u2014 ${s.about}`, "");
    for (const l of lines.slice(0, CHAT_CAP)) out.push(`- ${l}`);
    if (lines.length > CHAT_CAP) out.push(`- \u2026and ${lines.length - CHAT_CAP} more; run /garden again once these are dealt with.`);
  }
  if (opts.hasIndex === false) {
    out.push("", "Only exact copies are detected without semantic search; turn it on (settings \u2192 Search) to also find notes that mostly repeat another.");
  }
  return out.join("\n");
}
var NO_TASKS = "Never add checkboxes, tasks or TODO items to any note, and do not create a note to track this work; report in the chat.";
var plural = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;
function shown(all, keep) {
  return all.slice(0, CHAT_CAP).filter(keep);
}
function gardenFixes(r) {
  const fixes = [];
  const moved = shown(r.broken, (b) => b.suggestion !== void 0);
  if (moved.length) fixes.push({ action: "repair-links", label: `Repoint ${plural(moved.length, "moved link")}` });
  if (r.inboxes.length) fixes.push({ action: "inboxes", label: "Process daily inboxes" });
  const mentions = shown(r.mentions, () => true);
  if (mentions.length) fixes.push({ action: "link-mentions", label: `Link ${plural(mentions.length, "mention")}` });
  const copies = shown(r.duplicates, (d) => d.identical);
  if (copies.length) fixes.push({ action: "remove-copies", label: `Remove ${plural(copies.length, "identical copy", "identical copies")}` });
  const similar = shown(r.duplicates, (d) => !d.identical);
  if (similar.length) {
    fixes.push({
      action: "review-similar",
      label: "Review similar notes",
      prompt: [
        "These notes mostly repeat another note:",
        ...similar.map((d) => `- ${link(d.b)} shares ${Math.round(d.score * 100)}% of its lines with ${link(d.a)}`),
        "",
        "For each pair, read both notes (read_note, each note once) and tell me in one or two lines what the first has that the second lacks, and your recommendation: merge the first into the second, or keep both and link them. Change nothing yet; I will tell you which recommendations to carry out.",
        NO_TASKS
      ].join("\n")
    });
  }
  if (r.orphans.length) {
    fixes.push({
      action: "orphans",
      label: "Suggest links for orphans",
      prompt: [
        "These notes have no links in or out:",
        ...r.orphans.slice(0, CHAT_CAP).map((o) => `- ${link(o)}`),
        "",
        "For each, find the one existing note that should link to it: a hub or parent note from the vault outline, or search_notes with the orphan's title. Do not read the orphans themselves unless the title says nothing. Tell me your proposal as a list, one line per orphan: `[[orphan]] \u2190 [[note that should link to it]]` and a few words why, or `no good home` when nothing fits. Change nothing yet; I will tell you which links to add.",
        NO_TASKS
      ].join("\n")
    });
  }
  return fixes;
}
var Edits = class {
  constructor(vault) {
    this.vault = vault;
  }
  current = /* @__PURE__ */ new Map();
  async read(path) {
    const held = this.current.get(path);
    if (held) return held.text;
    if (!this.vault.exists(path)) return null;
    const text = await this.vault.read(path);
    this.current.set(path, { before: text, text, what: [] });
    return text;
  }
  write(path, text, what) {
    const held = this.current.get(path);
    if (!held || held.text === text) return;
    held.text = text;
    held.what.push(what);
  }
  changes() {
    return Array.from(this.current.entries()).filter(([, e]) => e.text !== e.before).map(([path, e]) => ({ tool: "edit_note", path, before: e.before, after: e.text, summary: `${path}: ${e.what.join("; ")}` }));
  }
};
function repoint(text, from, to) {
  return text.replace(new RegExp(`(!?\\[\\[)${escapeRegExp(from)}(?:\\.md)?(?=[\\]|#])`, "gi"), (_, open) => `${open}${to}`);
}
async function planLinkRepairs(vault, broken) {
  const edits = new Edits(vault);
  const skipped = [];
  for (const b of broken) {
    if (!b.suggestion) continue;
    const text = await edits.read(b.path);
    const target = /\.md$/i.test(b.suggestion) ? noMd(b.suggestion) : b.suggestion;
    const next = text === null || !vault.resolveFile(b.suggestion) ? null : repoint(text, noMd(b.target), target);
    if (next === null || next === text) skipped.push(`${link(b.path)} \u2192 \`[[${b.target}]]\`: the link or its new target is no longer there`);
    else edits.write(b.path, next, `[[${b.target}]] \u2192 [[${target}]]`);
  }
  return { changes: edits.changes(), skipped };
}
async function planMentionLinks(vault, mentions) {
  const edits = new Edits(vault);
  const skipped = [];
  for (const m of mentions) {
    const text = await edits.read(m.path);
    const name = mentionName(basenameOf(m.target));
    const found = text !== null && name && vault.exists(m.target) ? findMention(text, name) : null;
    if (text === null || !found) {
      skipped.push(`${link(m.path)}: no plain mention of ${link(m.target)} left`);
      continue;
    }
    const target = noMd(m.target);
    const wikilink = found.text === target ? `[[${target}]]` : `[[${target}|${found.text}]]`;
    edits.write(m.path, text.slice(0, found.at) + wikilink + text.slice(found.at + found.text.length), `linked "${found.text}" to [[${target}]]`);
  }
  return { changes: edits.changes(), skipped };
}
async function planCopyRemoval(vault, pairs) {
  const edits = new Edits(vault);
  const skipped = [];
  const deletions = [];
  const removing = new Set(pairs.filter((p) => p.identical).map((p) => p.b));
  for (const p of pairs) {
    if (!p.identical) continue;
    if (!vault.exists(p.a) || !vault.exists(p.b)) {
      skipped.push(`${link(p.b)}: one of the two notes is already gone`);
      continue;
    }
    const copy = await vault.read(p.b);
    if (comparable(copy) !== comparable(await vault.read(p.a))) {
      skipped.push(`${link(p.b)}: no longer identical to ${link(p.a)}`);
      continue;
    }
    for (const source of vault.getMetadata(p.b).backlinks) {
      if (removing.has(source) || source === p.a) continue;
      const text = await edits.read(source);
      if (text !== null) edits.write(source, repoint(text, noMd(p.b), noMd(p.a)), `[[${noMd(p.b)}]] \u2192 [[${noMd(p.a)}]]`);
    }
    deletions.push({ tool: "delete_file", path: p.b, before: copy, after: "", summary: `Delete ${p.b} (identical to ${p.a}; moved to the trash)` });
  }
  return { changes: [...edits.changes(), ...deletions], skipped };
}
async function planGardenAction(vault, action, r) {
  switch (action) {
    case "repair-links":
      return planLinkRepairs(vault, shown(r.broken, (b) => b.suggestion !== void 0));
    case "link-mentions":
      return planMentionLinks(vault, shown(r.mentions, () => true));
    case "remove-copies":
      return planCopyRemoval(vault, shown(r.duplicates, (d) => d.identical));
    default:
      return null;
  }
}
function renderPlanResult(applied, plan, stopped) {
  const out = [];
  if (applied.length === 0) out.push(stopped ? "Nothing was changed: you rejected the first change." : "Nothing to change: none of the listed findings still applies.");
  else {
    out.push(`Done, without the model: ${plural(applied.length, "note")} changed. \`/undo-all\` takes all of it back.`, "");
    for (const c of applied) out.push(`- ${c.tool === "delete_file" ? `${link(c.path)} moved to the trash` : `${link(c.path)} \u2014 ${c.summary.slice(c.path.length + 2)}`}`);
    if (stopped) out.push("", `Stopped at the change you rejected; ${plural(plan.changes.length - applied.length, "planned change")} not applied.`);
  }
  if (plan.skipped.length) out.push("", "Skipped:", ...plan.skipped.map((s) => `- ${s}`));
  return out.join("\n");
}

// src/gists.ts
var MAX_GIST_CHARS = 240;
var EMPTY = (model) => ({ version: 1, model, files: {} });
function gistPrompt(path, content, maxChars) {
  const head = content.length > maxChars ? content.slice(0, maxChars) + "\n[\u2026]" : content;
  return [
    `Note path: ${path}`,
    "",
    head,
    "",
    "In one sentence of at most 200 characters, say what this note is about and what it contains (its main topics, decisions or items). Plain text only: no preamble, no quotes, no markdown."
  ].join("\n");
}
function cleanGist(text) {
  let t2 = text.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
  t2 = t2.replace(/^(gist|summary)\s*:\s*/i, "").replace(/^["'“]+|["'”]+$/g, "");
  t2 = t2.replace(/\s+/g, " ").trim();
  if (t2.length > MAX_GIST_CHARS) t2 = t2.slice(0, MAX_GIST_CHARS - 1).replace(/\s+\S*$/, "") + "\u2026";
  return t2;
}
var GistCache = class {
  constructor(client, vault, store, opts) {
    this.client = client;
    this.vault = vault;
    this.store = store;
    this.opts = opts;
    this.data = EMPTY(opts.getModel());
  }
  data;
  queue = /* @__PURE__ */ new Set();
  processing = false;
  lastError;
  dirty = false;
  saveTimer = null;
  abort = null;
  think = false;
  async load() {
    try {
      const loaded = await this.store.load();
      if (loaded && loaded.version === 1) this.data = loaded;
    } catch (err) {
      this.lastError = `Could not load gists: ${err.message}`;
    }
    this.emit();
  }
  status() {
    const total = this.vault.listNotes().filter((n) => this.opts.shouldIndex(n.path)).length;
    return {
      enabled: this.opts.isEnabled(),
      building: this.processing,
      done: Object.keys(this.data.files).length,
      total,
      pending: this.queue.size,
      lastError: this.lastError
    };
  }
  /** The cached gist for a note, if it is current. */
  get(path) {
    return this.data.files[path]?.gist;
  }
  get count() {
    return Object.keys(this.data.files).length;
  }
  /** Queue every note whose mtime changed or that has no gist yet. */
  async syncAll(force = false) {
    if (!this.opts.isEnabled()) return;
    if (force) {
      this.data = EMPTY(this.opts.getModel());
      this.dirty = true;
    }
    const live = /* @__PURE__ */ new Set();
    for (const note of this.vault.listNotes()) {
      if (!this.opts.shouldIndex(note.path)) continue;
      live.add(note.path);
      const stored = this.data.files[note.path];
      if (!stored || stored.mtime !== note.mtime) this.queue.add(note.path);
    }
    for (const path of Object.keys(this.data.files)) {
      if (!live.has(path)) this.remove(path);
    }
    this.emit();
    await this.process();
  }
  enqueue(path) {
    if (!this.opts.isEnabled() || !this.opts.shouldIndex(path)) return;
    this.queue.add(path);
    void this.process();
  }
  remove(path) {
    if (this.data.files[path]) {
      delete this.data.files[path];
      this.dirty = true;
      this.scheduleSave();
    }
    this.queue.delete(path);
    this.emit();
  }
  rename(oldPath, newPath) {
    const entry = this.data.files[oldPath];
    this.remove(oldPath);
    if (entry && this.opts.shouldIndex(newPath)) {
      this.data.files[newPath] = entry;
      this.dirty = true;
      this.scheduleSave();
    }
    this.emit();
  }
  cancel() {
    this.abort?.abort();
  }
  async process() {
    if (this.processing) return;
    this.processing = true;
    this.abort = new AbortController();
    const signal = this.abort.signal;
    const sleep = this.opts.sleep ?? ((ms) => new Promise((r) => window.setTimeout(r, ms)));
    try {
      while (this.queue.size > 0 && !signal.aborted) {
        if (this.opts.isBusy?.()) {
          await sleep(2e3);
          continue;
        }
        const path = this.queue.values().next().value;
        this.queue.delete(path);
        if (!this.vault.exists(path)) {
          this.remove(path);
          continue;
        }
        const note = this.vault.listNotes().find((n) => n.path === path);
        const content = await this.vault.read(path);
        const gist = await this.generate(path, content, signal);
        this.data.files[path] = { mtime: note?.mtime ?? Date.now(), gist };
        this.data.model = this.opts.getModel();
        this.dirty = true;
        this.lastError = void 0;
        this.scheduleSave();
        this.emit();
      }
    } catch (err) {
      if (!signal.aborted) this.lastError = err.message;
    } finally {
      this.processing = false;
      this.abort = null;
      this.emit();
      await this.flush();
    }
  }
  async generate(path, content, signal) {
    const body = content.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n?/, "").trim();
    if (body.length < 80) return cleanGist(body) || "(empty note)";
    const request = (think) => this.client.chat({
      model: this.opts.getModel(),
      messages: [
        { role: "system", content: "You write one-sentence gists of a user's notes. Reply with the sentence only." },
        { role: "user", content: gistPrompt(path, body, this.opts.maxChars ?? 6e3) }
      ],
      think,
      options: { num_ctx: 8192, temperature: 0 },
      keep_alive: this.opts.keepAlive ?? "10m",
      signal
    });
    let res;
    try {
      res = await request(this.think);
    } catch (err) {
      if (this.think !== void 0 && err instanceof OllamaError && /think/i.test(err.message)) {
        this.think = void 0;
        res = await request(void 0);
      } else throw err;
    }
    return cleanGist(res.message.content) || "(no gist)";
  }
  scheduleSave() {
    if (this.saveTimer !== null) window.clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => void this.flush(), 3e3);
  }
  async flush() {
    if (this.saveTimer !== null) {
      window.clearTimeout(this.saveTimer);
      this.saveTimer = null;
    }
    if (!this.dirty) return;
    this.dirty = false;
    try {
      await this.store.save(this.data);
    } catch (err) {
      this.lastError = `Could not save gists: ${err.message}`;
      this.emit();
    }
  }
  emit() {
    this.opts.onStatus?.(this.status());
  }
};

// src/obsidian-vault.ts
var import_obsidian3 = require("obsidian");
var ObsidianVault = class {
  constructor(app, isExcluded2) {
    this.app = app;
    this.isExcluded = isExcluded2;
  }
  listNotes() {
    return this.app.vault.getMarkdownFiles().filter((f) => !this.isExcluded(f.path)).map((f) => ({
      path: f.path,
      basename: f.basename,
      folder: f.parent?.path === "/" ? "" : f.parent?.path ?? "",
      mtime: f.stat.mtime,
      ctime: f.stat.ctime,
      size: f.stat.size
    }));
  }
  fileFor(path) {
    const normalized = (0, import_obsidian3.normalizePath)(path);
    const direct = this.app.vault.getFileByPath(normalized);
    if (direct) return direct;
    if (!/\.md$/i.test(normalized)) {
      const withExt = this.app.vault.getFileByPath(normalized + ".md");
      if (withExt) return withExt;
    }
    return null;
  }
  resolve(pathOrName) {
    const cleaned = pathOrName.trim().replace(/\\/g, "/").replace(/^\[\[|\]\]$/g, "").replace(/^\/+/, "");
    if (!cleaned) return null;
    const direct = this.fileFor(cleaned);
    if (direct) return this.isExcluded(direct.path) ? null : direct.path;
    const linkpath = cleaned.replace(/\.md$/i, "");
    const dest = this.app.metadataCache.getFirstLinkpathDest(linkpath, "");
    if (dest && dest.extension === "md" && !this.isExcluded(dest.path)) return dest.path;
    const lower = linkpath.toLowerCase();
    const match = this.app.vault.getMarkdownFiles().find((f) => f.basename.toLowerCase() === lower || f.path.toLowerCase() === lower + ".md");
    return match && !this.isExcluded(match.path) ? match.path : null;
  }
  exists(path) {
    return this.fileFor(path) !== null;
  }
  async read(path) {
    const file = this.fileFor(path);
    if (!file) throw new Error(`Note not found: ${path}`);
    return this.app.vault.cachedRead(file);
  }
  async create(path, content) {
    const normalized = (0, import_obsidian3.normalizePath)(path);
    await this.ensureFolder(normalized);
    await this.app.vault.create(normalized, content);
  }
  async readBinary(path) {
    const file = this.app.vault.getFileByPath((0, import_obsidian3.normalizePath)(path));
    if (!file) throw new Error(`File not found: ${path}`);
    return this.app.vault.readBinary(file);
  }
  async createBinary(path, data) {
    const normalized = (0, import_obsidian3.normalizePath)(path);
    await this.ensureFolder(normalized);
    await this.app.vault.createBinary(normalized, data);
  }
  async rename(path, newPath) {
    const file = this.app.vault.getFileByPath((0, import_obsidian3.normalizePath)(path)) ?? this.fileFor(path);
    if (!file) throw new Error(`File not found: ${path}`);
    const target = (0, import_obsidian3.normalizePath)(newPath);
    await this.ensureFolder(target);
    await this.app.fileManager.renameFile(file, target);
  }
  /** Creates each missing ancestor folder of `normalizedPath` in turn. */
  async ensureFolder(normalizedPath) {
    const folder = normalizedPath.includes("/") ? normalizedPath.slice(0, normalizedPath.lastIndexOf("/")) : "";
    if (!folder || this.app.vault.getFolderByPath(folder)) return;
    let current2 = "";
    for (const part of folder.split("/")) {
      current2 = current2 ? `${current2}/${part}` : part;
      if (!this.app.vault.getFolderByPath(current2)) await this.app.vault.createFolder(current2);
    }
  }
  async modify(path, content) {
    const file = this.fileFor(path);
    if (!file) throw new Error(`Note not found: ${path}`);
    await this.app.vault.process(file, () => content);
  }
  listAttachments() {
    return this.app.vault.getFiles().filter((f) => f.extension.toLowerCase() !== "md" && !this.isExcluded(f.path)).map((f) => ({
      path: f.path,
      basename: f.basename,
      extension: f.extension.toLowerCase(),
      folder: f.parent?.path === "/" ? "" : f.parent?.path ?? "",
      mtime: f.stat.mtime,
      ctime: f.stat.ctime,
      size: f.stat.size
    }));
  }
  resolveFile(path) {
    const cleaned = path.trim().replace(/\\/g, "/").replace(/^!?\[\[|\]\]$/g, "").replace(/^\/+/, "");
    if (!cleaned) return null;
    const file = this.app.vault.getFileByPath((0, import_obsidian3.normalizePath)(cleaned));
    if (file) return this.isExcluded(file.path) ? null : file.path;
    const dest = this.app.metadataCache.getFirstLinkpathDest(cleaned, "");
    return dest && !this.isExcluded(dest.path) ? dest.path : null;
  }
  async trash(path) {
    const file = this.app.vault.getFileByPath((0, import_obsidian3.normalizePath)(path)) ?? this.fileFor(path);
    if (!file) throw new Error(`File not found: ${path}`);
    await this.app.fileManager.trashFile(file);
  }
  getMetadata(path) {
    const file = this.fileFor(path);
    const empty = { tags: [], links: [], backlinks: [], headings: [], frontmatter: {} };
    if (!file) return empty;
    const cache = this.app.metadataCache.getFileCache(file);
    if (!cache) return empty;
    const tags = Array.from(new Set((0, import_obsidian3.getAllTags)(cache) ?? []));
    const links = Array.from(
      new Set([...cache.links ?? [], ...cache.embeds ?? []].map((l) => l.link))
    );
    const headings = (cache.headings ?? []).map((h) => `${"#".repeat(h.level)} ${h.heading}`);
    const backlinks = this.backlinksOf(file.path);
    const frontmatter = {};
    if (cache.frontmatter) {
      for (const [k, v] of Object.entries(cache.frontmatter)) {
        if (k !== "position") frontmatter[k] = v;
      }
    }
    return { tags, links, backlinks, headings, frontmatter };
  }
  backlinkMap = null;
  backlinkMapAt = 0;
  /**
   * Notes linking to `path`, from a reverse map of Obsidian's resolved links that is rebuilt at most
   * once a second. Scanning every note's links for each note asked about made anything that looks
   * at the whole vault (the outline in the system prompt, the gardener) quadratic: seconds at 2,000
   * notes, minutes at 50,000.
   */
  backlinksOf(path) {
    const now = Date.now();
    if (!this.backlinkMap || now - this.backlinkMapAt > 1e3) {
      const map = /* @__PURE__ */ new Map();
      const resolved = this.app.metadataCache.resolvedLinks;
      for (const source of Object.keys(resolved)) {
        for (const target of Object.keys(resolved[source])) {
          const list = map.get(target);
          if (list) list.push(source);
          else map.set(target, [source]);
        }
      }
      this.backlinkMap = map;
      this.backlinkMapAt = now;
    }
    return this.backlinkMap.get(path)?.slice() ?? [];
  }
  getActiveNotePath() {
    const file = this.app.workspace.getActiveFile();
    return file && file.extension === "md" ? file.path : null;
  }
  getSelection() {
    const view = this.app.workspace.getActiveViewOfType(import_obsidian3.MarkdownView);
    const sel = view?.editor?.getSelection();
    return sel && sel.length > 0 ? sel : null;
  }
};

// src/prompt-modals.ts
var import_obsidian4 = require("obsidian");
var TuneModal = class extends import_obsidian4.Modal {
  constructor(app, advice, connection) {
    super(app);
    this.advice = advice;
    this.connection = connection;
    this.result = new Promise((res) => this.resolve = res);
  }
  resolve;
  result;
  done = false;
  onOpen() {
    const { contentEl, titleEl, modalEl } = this;
    modalEl.addClass("lva-options-modal");
    titleEl.setText(ui("Connection and speed test", "\uC5F0\uACB0 \uBC0F \uC18D\uB3C4 \uD14C\uC2A4\uD2B8"));
    contentEl.createEl("p", { cls: "lva-modal-help", text: this.connection });
    contentEl.createEl("p", { cls: "lva-tune-headline", text: this.advice.headline });
    const list = contentEl.createEl("ul", { cls: "lva-tune-lines" });
    for (const line of this.advice.lines) list.createEl("li", { text: line });
    const buttons = new import_obsidian4.Setting(contentEl);
    if (this.advice.suggestedNumCtx) {
      const n = this.advice.suggestedNumCtx;
      buttons.addButton(
        (b) => b.setButtonText(`Use a ${Math.round(n / 1024)}k context`).setCta().onClick(() => this.finish({ numCtx: n }))
      );
    }
    if (this.advice.suggestedModel) {
      const name = this.advice.suggestedModel;
      buttons.addButton((b) => b.setButtonText(`Switch to ${name}`).onClick(() => this.finish({ model: name })));
    }
    buttons.addButton((b) => b.setButtonText(ui("Close", "\uB2EB\uAE30")).onClick(() => this.finish(null)));
  }
  finish(choice) {
    if (this.done) return;
    this.done = true;
    this.resolve(choice);
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    this.finish(null);
  }
};
var ProcessDailyModal = class extends import_obsidian4.Modal {
  constructor(app, initial, today = /* @__PURE__ */ new Date()) {
    super(app);
    this.today = today;
    this.opts = { ...initial };
    this.result = new Promise((res) => this.resolve = res);
  }
  resolve;
  result;
  done = false;
  opts;
  onOpen() {
    const { contentEl, titleEl, modalEl } = this;
    modalEl.addClass("lva-options-modal");
    titleEl.setText(ui("Process my daily notes", "\uC77C\uC77C \uB178\uD2B8 \uC815\uB9AC"));
    contentEl.createEl("p", {
      cls: "lva-modal-help",
      text: ui("The agent surveys the inbox section of every daily note, compiles the substantial ones into topic notes with links back to the source days, and can replace each compiled inbox with a link. Every write is shown as a diff first.", "\uC77C\uC77C \uB178\uD2B8\uC758 \uC218\uC9D1 \uC139\uC158\uC744 \uC77D\uC5B4 \uC8FC\uC81C\uBCC4\uB85C \uC815\uB9AC\uD558\uACE0 \uC6D0\uBCF8 \uB0A0\uC9DC\uB85C \uC5F0\uACB0\uD569\uB2C8\uB2E4. \uC815\uB9AC\uD55C \uC139\uC158\uC744 \uC8FC\uC81C \uB178\uD2B8 \uB9C1\uD06C\uB85C \uBC14\uAFC0 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uC800\uC7A5 \uC804\uC5D0 \uBCC0\uACBD\uC0AC\uD56D\uC744 \uD45C\uC2DC\uD569\uB2C8\uB2E4.")
    });
    new import_obsidian4.Setting(contentEl).setName(ui("Daily notes folder", "\uC77C\uC77C \uB178\uD2B8 \uD3F4\uB354")).setDesc(ui("Read from the Daily Notes plugin; empty means the vault root.", "\uC77C\uC77C \uB178\uD2B8 \uD50C\uB7EC\uADF8\uC778\uC5D0\uC11C \uD3F4\uB354\uB97C \uC77D\uC2B5\uB2C8\uB2E4. \uBE44\uC6CC \uB450\uBA74 Vault \uCD5C\uC0C1\uC704\uB97C \uC0AC\uC6A9\uD569\uB2C8\uB2E4.")).addText((t2) => t2.setValue(this.opts.folder).onChange((v) => this.opts.folder = v.trim()));
    new import_obsidian4.Setting(contentEl).setName(ui("Inbox heading", "\uC218\uC9D1 \uC139\uC158 \uC81C\uBAA9")).setDesc(ui("The section inside each daily note that collects loose captures, without the #.", "\uC77C\uC77C \uB178\uD2B8\uC5D0\uC11C \uBA54\uBAA8\uB97C \uBAA8\uC544 \uB450\uB294 \uC139\uC158 \uC81C\uBAA9\uC744 # \uC5C6\uC774 \uC785\uB825\uD569\uB2C8\uB2E4.")).addText((t2) => t2.setValue(this.opts.heading).onChange((v) => this.opts.heading = v.trim() || "Capture"));
    new import_obsidian4.Setting(contentEl).setName(ui("Topic notes folder", "\uC8FC\uC81C \uB178\uD2B8 \uD3F4\uB354")).setDesc(ui("Where compiled notes are created; empty means the vault root.", "\uD1B5\uD569 \uB178\uD2B8\uB97C \uC800\uC7A5\uD560 \uD3F4\uB354\uC785\uB2C8\uB2E4. \uBE44\uC6CC \uB450\uBA74 Vault \uCD5C\uC0C1\uC704\uB97C \uC0AC\uC6A9\uD569\uB2C8\uB2E4.")).addText((t2) => t2.setValue(this.opts.destination).onChange((v) => this.opts.destination = v.trim()));
    new import_obsidian4.Setting(contentEl).setName(ui("Look back", "\uB300\uC0C1 \uAE30\uAC04")).addDropdown((d) => {
      d.addOption("all", "All daily notes");
      d.addOption("30", "Last 30 days");
      d.addOption("90", "Last 90 days");
      d.addOption("365", "Last year");
      d.setValue("all");
      d.onChange((v) => {
        if (v === "all") delete this.opts.since;
        else {
          const since = new Date(this.today.getTime() - Number(v) * 864e5);
          this.opts.since = since.toISOString().slice(0, 10);
        }
      });
    });
    new import_obsidian4.Setting(contentEl).setName(ui("Move compiled inboxes out of the daily notes", "\uC815\uB9AC\uD55C \uBA54\uBAA8\uB97C \uC77C\uC77C \uB178\uD2B8\uC5D0\uC11C \uC774\uB3D9")).setDesc(ui("Replace each compiled inbox with '- Moved to [[Topic]]'. Off keeps daily notes unchanged.", "\uC815\uB9AC\uD55C \uC218\uC9D1 \uC139\uC158\uC744 \uC8FC\uC81C \uB178\uD2B8 \uB9C1\uD06C\uB85C \uBC14\uAFC9\uB2C8\uB2E4. \uB044\uBA74 \uC77C\uC77C \uB178\uD2B8\uB97C \uADF8\uB300\uB85C \uB461\uB2C8\uB2E4.")).addToggle((t2) => t2.setValue(this.opts.move).onChange((v) => this.opts.move = v));
    new import_obsidian4.Setting(contentEl).addButton((b) => b.setButtonText(ui("Cancel", "\uCDE8\uC18C")).onClick(() => this.finish(null))).addButton(
      (b) => b.setButtonText(ui("Run", "\uC2E4\uD589")).setCta().onClick(() => this.finish(this.opts))
    );
  }
  finish(o) {
    if (this.done) return;
    this.done = true;
    this.resolve(o);
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    this.finish(null);
  }
};
var InstructionModal = class extends import_obsidian4.Modal {
  constructor(app, preview) {
    super(app);
    this.preview = preview;
    this.result = new Promise((res) => this.resolve = res);
  }
  resolve;
  result;
  done = false;
  value = "";
  onOpen() {
    const { contentEl, titleEl, modalEl } = this;
    modalEl.addClass("lva-options-modal");
    titleEl.setText(ui("Edit the selected text", "\uC120\uD0DD \uC601\uC5ED \uD3B8\uC9D1"));
    const quote = contentEl.createEl("pre", { cls: "lva-modal-preview" });
    quote.setText(this.preview.length > 400 ? this.preview.slice(0, 400) + "\u2026" : this.preview);
    new import_obsidian4.Setting(contentEl).setName(ui("Instruction", "\uD3B8\uC9D1 \uC9C0\uC2DC")).setDesc(ui("What should change? e.g. 'is a markdown table', 'reads as one tight paragraph', 'is in the past tense'.", "\uC5B4\uB5BB\uAC8C \uBC14\uAFC0\uC9C0 \uC785\uB825\uD558\uC138\uC694. \uC608: Markdown \uD45C\uB85C \uB9CC\uB4E4\uAE30, \uD55C \uBB38\uB2E8\uC73C\uB85C \uB2E4\uB4EC\uAE30, \uACFC\uAC70\uD615\uC73C\uB85C \uBC14\uAFB8\uAE30.")).addText((t2) => {
      t2.setPlaceholder("make this a bullet list");
      t2.onChange((v) => this.value = v);
      t2.inputEl.addClass("lva-modal-input");
      t2.inputEl.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && this.value.trim()) {
          e.preventDefault();
          this.finish(this.value.trim());
        }
      });
      window.setTimeout(() => t2.inputEl.focus(), 0);
    });
    new import_obsidian4.Setting(contentEl).addButton((b) => b.setButtonText(ui("Cancel", "\uCDE8\uC18C")).onClick(() => this.finish(null))).addButton(
      (b) => b.setButtonText(ui("Edit", "\uD3B8\uC9D1")).setCta().onClick(() => this.finish(this.value.trim() || null))
    );
  }
  finish(s) {
    if (this.done) return;
    this.done = true;
    this.resolve(s);
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    this.finish(null);
  }
};

// src/concepts.ts
var DEFAULT_CONCEPT_FOLDERS = ["Concepts", "Topics"];
function isConceptNote(n, folders, meta) {
  const lower = n.path.toLowerCase();
  if (folders.some((f) => {
    const p = f.trim().replace(/^\/+|\/+$/g, "").toLowerCase();
    return p && (lower.startsWith(p + "/") || lower.includes("/" + p + "/"));
  })) return true;
  if (meta?.tags?.some((t2) => /^#?(concept|topic)s?$/i.test(t2))) return true;
  const type = meta?.frontmatter?.type ?? meta?.frontmatter?.category;
  return typeof type === "string" && /^(concept|topic)s?$/i.test(type.trim());
}
function isWordChar2(ch) {
  return !!ch && /[\p{L}\p{N}_]/u.test(ch);
}
function findWord(maskedLower, name) {
  const needle = name.toLowerCase();
  let from = 0;
  for (; ; ) {
    const at = maskedLower.indexOf(needle, from);
    if (at < 0) return -1;
    if (!isWordChar2(maskedLower[at - 1]) && !isWordChar2(maskedLower[at + needle.length])) return at;
    from = at + needle.length;
  }
}
function conceptNames(n, aliases) {
  const out = [n.basename];
  if (Array.isArray(aliases)) {
    for (const a of aliases) if (typeof a === "string") out.push(a);
  }
  if (typeof aliases === "string") out.push(...aliases.split(","));
  return Array.from(new Set(out.map((s) => s.trim()))).filter((s) => s.length >= 4 && !/^\d{4}-\d{2}-\d{2}/.test(s));
}
function existingLinks(content) {
  const out = /* @__PURE__ */ new Set();
  for (const m of content.matchAll(/\[\[([^\]|#]+)/g)) {
    const t2 = m[1].trim().replace(/\.md$/i, "").toLowerCase();
    out.add(t2);
    out.add(t2.split("/").pop() ?? t2);
  }
  for (const m of content.matchAll(/^\s*(?:parent|child|children|up|related)\s*:.*$/gim)) for (const l of m[0].matchAll(/\[\[([^\]|#]+)/g)) out.add(l[1].trim().toLowerCase());
  return out;
}
function suggestConcepts(current2, concepts, related = [], maxRelated = 5) {
  const masked = maskProse(current2.content).toLowerCase();
  const linked = existingLinks(current2.content);
  const out = [];
  const taken = [];
  const candidates = concepts.filter((c) => c.note.path !== current2.path).flatMap((c) => c.names.map((name) => ({ c, name }))).sort((a, b) => b.name.length - a.name.length);
  for (const { c, name } of candidates) {
    const target = c.note.path.replace(/\.md$/i, "").toLowerCase();
    if (out.some((o) => o.path === c.note.path) || linked.has(target) || linked.has(c.note.basename.toLowerCase())) continue;
    let at = findWord(masked, name);
    while (at >= 0 && taken.some(([a, b]) => at < b && at + name.length > a)) {
      const next = findWord(masked.slice(at + name.length), name);
      at = next < 0 ? -1 : at + name.length + next;
    }
    if (at < 0) continue;
    taken.push([at, at + name.length]);
    out.push({ path: c.note.path, kind: "mentioned", mention: { at, text: current2.content.slice(at, at + name.length) } });
  }
  const conceptPaths = new Set(concepts.map((c) => c.note.path));
  for (const r of [...related].sort((a, b) => b.score - a.score)) {
    if (out.filter((o) => o.kind === "related").length >= maxRelated) break;
    if (r.path === current2.path || !conceptPaths.has(r.path) || out.some((o) => o.path === r.path)) continue;
    const target = r.path.replace(/\.md$/i, "").toLowerCase();
    if (linked.has(target) || linked.has(target.split("/").pop() ?? target)) continue;
    out.push({ path: r.path, kind: "related", score: r.score });
  }
  return out;
}
function noMd2(p) {
  return p.replace(/\.md$/i, "");
}
function linkFor(path, text) {
  const target = noMd2(path);
  return !text || text === target ? `[[${target}]]` : `[[${target}|${text}]]`;
}
function setLinkProperty(content, key, links) {
  const nl = content.includes("\r\n") ? "\r\n" : "\n";
  const lines = content.split(/\r?\n/);
  const hasFm = lines[0] === "---" && lines.indexOf("---", 1) > 0;
  const quote = (l) => `  - "${l.replace(/"/g, '\\"')}"`;
  if (!hasFm) {
    if (!links.length) return content;
    return ["---", `${key}:`, ...links.map(quote), "---", ...lines].join(nl);
  }
  const end = lines.indexOf("---", 1);
  const keyRe = new RegExp(`^${key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*:(.*)$`);
  const at = lines.findIndex((l, i) => i > 0 && i < end && keyRe.test(l));
  const existing = [];
  let stop = at + 1;
  if (at > 0) {
    const inline = keyRe.exec(lines[at])[1].trim();
    for (const m of inline.matchAll(/\[\[[^\]]+\]\]/g)) existing.push(m[0]);
    while (stop < end && /^\s+(-\s|\S)/.test(lines[stop]) && !/^\S/.test(lines[stop])) {
      for (const m of lines[stop].matchAll(/\[\[[^\]]+\]\]/g)) existing.push(m[0]);
      stop++;
    }
  }
  const target = (l) => l.replace(/^\[\[|\]\]$/g, "").replace(/[|#].*$/, "").trim().toLowerCase();
  const merged = [...existing];
  for (const l of links) if (!merged.some((e) => target(e) === target(l))) merged.push(l);
  const block = [`${key}:`, ...merged.map(quote)];
  if (at > 0) lines.splice(at, stop - at, ...block);
  else lines.splice(end, 0, ...block);
  return lines.join(nl);
}
function addRelatedSection(content, paths, heading = "Related concepts") {
  if (!paths.length) return content;
  const nl = content.includes("\r\n") ? "\r\n" : "\n";
  const lines = content.split(/\r?\n/);
  const at = lines.findIndex((l) => new RegExp(`^#{1,6}\\s+${heading}\\s*$`, "i").test(l));
  const items = paths.map((p) => `- ${linkFor(p)}`);
  if (at < 0) return `${content.replace(/\s+$/, "")}${nl}${nl}## ${heading}${nl}${nl}${items.join(nl)}${nl}`;
  let end = at + 1;
  while (end < lines.length && !/^#{1,6}\s/.test(lines[end])) end++;
  let insert = end;
  while (insert > at + 1 && !lines[insert - 1].trim()) insert--;
  const have = lines.slice(at, end).join("\n").toLowerCase();
  const fresh = items.filter((i) => !have.includes(i.toLowerCase()));
  lines.splice(insert, 0, ...fresh);
  return lines.join(nl);
}
function applyConceptLinks(content, chosen, property) {
  let out = content;
  const mentions = chosen.filter((c) => c.kind === "mentioned" && c.mention).sort((a, b) => b.mention.at - a.mention.at);
  for (const c of mentions) {
    const { at, text } = c.mention;
    if (out.slice(at, at + text.length) !== text) continue;
    out = out.slice(0, at) + linkFor(c.path, text) + out.slice(at + text.length);
  }
  out = addRelatedSection(out, chosen.filter((c) => c.kind === "related").map((c) => c.path));
  if (property !== "none" && chosen.length) out = setLinkProperty(out, property, chosen.map((c) => `[[${noMd2(c.path)}]]`));
  return out;
}

// src/feature-modals.ts
var import_obsidian5 = require("obsidian");

// src/undo.ts
var MAX_HISTORY = 300;
var UndoStack = class {
  constructor(max = MAX_HISTORY) {
    this.max = max;
  }
  changes = [];
  nextId = 1;
  listeners = /* @__PURE__ */ new Set();
  push(change) {
    const record = { ...change, id: this.nextId++ };
    this.changes.push(record);
    if (this.changes.length > this.max) this.changes.splice(0, this.changes.length - this.max);
    this.emit();
    return record;
  }
  /** Replaces the history with saved records (from `toJSON`). */
  load(records) {
    if (!Array.isArray(records)) return;
    this.changes = records.filter((r) => {
      const c = r;
      return !!c && typeof c.id === "number" && typeof c.path === "string" && typeof c.before === "string" && typeof c.after === "string";
    }).slice(-this.max);
    this.nextId = this.changes.reduce((m, c) => Math.max(m, c.id), 0) + 1;
    this.emit();
  }
  /** The history for saving: attachment bytes are left out (too large for JSON). */
  toJSON() {
    return this.changes.map((c) => c.binary ? { ...c, binary: void 0 } : c);
  }
  markUndone(id, time = Date.now()) {
    const c = this.byId(id);
    if (!c || c.undone) return;
    c.undone = time;
    this.emit();
  }
  get size() {
    return this.changes.length;
  }
  /** Oldest first. */
  list() {
    return this.changes;
  }
  byId(id) {
    return this.changes.find((c) => c.id === id);
  }
  /** The most recent change that has not been undone. */
  latest() {
    for (let i = this.changes.length - 1; i >= 0; i--) if (!this.changes[i].undone) return this.changes[i];
    return void 0;
  }
  /** Changes made in one agent turn (of one chat, when given) and not undone, most recent first (the order to revert them in). */
  forTurn(turn, chat) {
    return this.changes.filter((c) => c.turn === turn && !c.undone && (chat === void 0 || c.chat === chat)).reverse();
  }
  remove(id) {
    const before = this.changes.length;
    this.changes = this.changes.filter((c) => c.id !== id);
    if (this.changes.length !== before) this.emit();
  }
  onChange(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  emit() {
    for (const l of this.listeners) l();
  }
};
var RevertError = class extends Error {
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "RevertError";
  }
};
function reverseOnto(current2, before, after) {
  return carryOnto(current2, after, before);
}
function carryOnto(current2, from, to) {
  if (current2 === from) return to;
  const patch = structuredPatch("note", "note", from, to, "", "", { context: 2 });
  const out = applyPatch(current2, patch, { fuzzFactor: 0 });
  return out === false ? null : out;
}
function describeChange(change) {
  switch (change.tool) {
    case "create_note":
      return `created ${change.path}`;
    case "delete_file":
      return `deleted ${change.path}`;
    case "move_note":
      return `moved ${change.before} to ${change.after}`;
    case "append_to_note":
      return `appended to ${change.path}`;
    case "add_block_ids":
      return `added block ids to ${change.path}`;
    case "undo":
      return `undid a change to ${change.path}`;
    case "replace_note":
      return `rewrote ${change.path}`;
    default:
      return `edited ${change.path}`;
  }
}
async function planRevert(change, vault) {
  const { path } = change;
  const isNote = /\.md$/i.test(path);
  switch (change.tool) {
    case "create_note": {
      if (!vault.exists(path)) throw new RevertError(`${path} no longer exists; nothing to undo.`, "nothing");
      const current2 = await vault.read(path);
      if (change.after && current2 !== change.after) throw new RevertError(`${path} was edited after the agent created it; deleting it would lose those edits. Delete it by hand if you want it gone.`, "conflict");
      return {
        tool: "undo",
        path,
        before: current2,
        after: "",
        summary: `Undo: delete ${path} (the agent created it)`,
        apply: () => vault.trash(path)
      };
    }
    case "move_note": {
      const from = change.after;
      const to = change.before;
      if (!vault.resolveFile(from)) throw new RevertError(`${from} is no longer there; nothing to undo.`, "nothing");
      if (vault.resolveFile(to)) throw new RevertError(`${to} already exists; cannot move back.`, "conflict");
      return {
        tool: "undo",
        path: from,
        before: from,
        after: to,
        summary: `Undo: move ${from} back to ${to}`,
        apply: () => vault.rename(from, to)
      };
    }
    case "delete_file": {
      if (vault.resolveFile(path)) throw new RevertError(`${path} already exists; nothing to undo.`, "nothing");
      if (isNote) {
        return {
          tool: "undo",
          path,
          before: "",
          after: change.before,
          summary: `Undo: restore ${path}`,
          apply: () => vault.create(path, change.before)
        };
      }
      const data = change.binary;
      if (!data) throw new RevertError(`${path} was too large to keep a copy of; restore it from the trash by hand.`, "nothing");
      return {
        tool: "undo",
        path,
        before: "",
        after: `(restore attachment, ${data.byteLength} bytes)`,
        summary: `Undo: restore ${path}`,
        apply: () => vault.createBinary(path, data)
      };
    }
    default: {
      if (!vault.exists(path)) {
        return {
          tool: "undo",
          path,
          before: "",
          after: change.before,
          summary: `Undo: restore ${path}`,
          apply: () => vault.create(path, change.before)
        };
      }
      const current2 = await vault.read(path);
      if (current2 === change.before) throw new RevertError(`${path} is already as it was before this change.`, "nothing");
      const restored = reverseOnto(current2, change.before, change.after);
      if (restored === null) throw new RevertError(`${path} changed since in a way that overlaps this change, so it cannot be undone automatically. Compare the note with the change in the history and fix it by hand.`, "conflict");
      return {
        tool: "undo",
        path,
        before: current2,
        after: restored,
        summary: current2 === change.after ? `Undo: ${describeChange(change)}` : `Undo: ${describeChange(change)} (later edits kept)`,
        apply: async () => {
          if (await vault.read(path) !== current2) throw new RevertError(`${path} changed while the undo was waiting for approval; try again.`, "conflict");
          await vault.modify(path, restored);
        }
      };
    }
  }
}
function stillApplied(made) {
  return made.filter((c) => !c.undone).reverse();
}

// src/feature-modals.ts
var QuizModal = class extends import_obsidian5.Modal {
  constructor(app, courses, count) {
    super(app);
    this.courses = courses;
    this.count = count;
    this.result = new Promise((res) => this.resolve = res);
  }
  resolve;
  result;
  done = false;
  topic = "";
  since = "";
  onOpen() {
    const { contentEl, titleEl, modalEl } = this;
    modalEl.addClass("lva-options-modal");
    titleEl.setText(ui("Quiz me", "\uD034\uC988"));
    contentEl.createEl("p", {
      cls: "lva-modal-help",
      text: ui("Questions are written from your notes on the topic, asked one at a time in the chat and graded against the passage they came from. Missed ones go to a review note, after you approve the diff. Type stop to end early.", "\uAD00\uB828 \uB178\uD2B8\uB97C \uBC14\uD0D5\uC73C\uB85C \uD55C \uBB38\uC81C\uC529 \uCD9C\uC81C\uD558\uACE0 \uC6D0\uBB38 \uBB38\uB2E8\uACFC \uBE44\uAD50\uD574 \uCC44\uC810\uD569\uB2C8\uB2E4. \uD2C0\uB9B0 \uBB38\uD56D\uC740 \uBCC0\uACBD \uC2B9\uC778 \uD6C4 \uBCF5\uC2B5 \uB178\uD2B8\uC5D0 \uC800\uC7A5\uB429\uB2C8\uB2E4. \uC911\uAC04\uC5D0 \uB05D\uB0B4\uB824\uBA74 stop\uC744 \uC785\uB825\uD558\uC138\uC694.")
    });
    new import_obsidian5.Setting(contentEl).setName(ui("Topic or course", "\uC8FC\uC81C \uB610\uB294 \uACFC\uBAA9")).setDesc(this.courses.length ? `Lecture Companion courses: ${this.courses.join(", ")}` : "A course folder, a topic, or words from note names.").addText((t2) => {
      t2.setPlaceholder(this.courses[0] ?? "Machine Learning").onChange((v) => this.topic = v);
      t2.inputEl.addEventListener("keydown", (e) => {
        if (e.key === "Enter") this.finish(true);
      });
      window.setTimeout(() => t2.inputEl.focus(), 0);
    });
    new import_obsidian5.Setting(contentEl).setName(ui("Since", "\uC2DC\uC791 \uB0A0\uC9DC")).setDesc(ui("A date (2026-10-01), or words: last week, 2 weeks ago, monday, Oct 3. Empty for all.", "\uB0A0\uC9DC\uB97C \uC785\uB825\uD558\uC138\uC694. \uC608: 2026-10-01. \uBE44\uC6CC \uB450\uBA74 \uC804\uCCB4 \uAE30\uAC04\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4.")).addText((t2) => t2.setPlaceholder("last week").onChange((v) => this.since = v));
    new import_obsidian5.Setting(contentEl).setName(ui("Questions", "\uBB38\uD56D \uC218")).addSlider(
      (s) => s.setLimits(3, 15, 1).setValue(this.count).onChange((v) => this.count = v)
    );
    new import_obsidian5.Setting(contentEl).addButton((b) => b.setButtonText(ui("Cancel", "\uCDE8\uC18C")).onClick(() => this.finish(false))).addButton(
      (b) => b.setButtonText(ui("Start the quiz", "\uD034\uC988 \uC2DC\uC791")).setCta().onClick(() => this.finish(true))
    );
  }
  finish(ok) {
    if (this.done) return;
    this.done = true;
    this.resolve(ok ? { topic: this.topic.trim(), since: this.since.trim(), count: this.count } : null);
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    this.finish(false);
  }
};
var ConceptModal = class extends import_obsidian5.Modal {
  constructor(app, notePath, suggestions) {
    super(app);
    this.notePath = notePath;
    this.suggestions = suggestions;
    this.picked = new Set(suggestions.filter((s) => s.kind === "mentioned"));
    this.result = new Promise((res) => this.resolve = res);
  }
  resolve;
  result;
  done = false;
  picked;
  property = "none";
  onOpen() {
    const { contentEl, titleEl, modalEl } = this;
    modalEl.addClass("lva-options-modal");
    titleEl.setText(ui("Concept links", "\uAC1C\uB150 \uB9C1\uD06C"));
    contentEl.createEl("p", {
      cls: "lva-modal-help",
      text: `Concept notes ${this.notePath.replace(/\.md$/i, "")} talks about. Mentions are linked where they first appear; related notes go under "## Related concepts". You see the whole change as a diff before anything is written.`
    });
    for (const s of this.suggestions) {
      const name = s.path.replace(/\.md$/i, "");
      const desc = s.kind === "mentioned" ? `Mentioned as \u201C${s.mention?.text ?? ""}\u201D` : `Related by meaning (${Math.round((s.score ?? 0) * 100)}%), not mentioned`;
      new import_obsidian5.Setting(contentEl).setName(name).setDesc(desc).addToggle(
        (t2) => t2.setValue(this.picked.has(s)).onChange((v) => {
          if (v) this.picked.add(s);
          else this.picked.delete(s);
        })
      );
    }
    new import_obsidian5.Setting(contentEl).setName(ui("Link properties", "\uB9C1\uD06C \uC18D\uC131")).setDesc(ui("Also record the concepts in this note's frontmatter, as Branching Table of Contents reads them. 'parent': this note sits under each concept, so a concept gathers its lectures from every course.", "\uAC1C\uB150\uC744 \uC774 \uB178\uD2B8\uC758 YAML \uC18D\uC131\uC5D0\uB3C4 \uAE30\uB85D\uD569\uB2C8\uB2E4. parent\uB97C \uC120\uD0DD\uD558\uBA74 \uAC1C\uB150 \uB178\uD2B8\uC5D0 \uAD00\uB828 \uAC15\uC758\uB97C \uBAA8\uC744 \uC218 \uC788\uC2B5\uB2C8\uB2E4.")).addDropdown(
      (d) => d.addOptions({ none: "Don't add properties", parent: "parent: the concepts", child: "child: the concepts" }).setValue(this.property).onChange((v) => this.property = v)
    );
    new import_obsidian5.Setting(contentEl).addButton((b) => b.setButtonText(ui("Cancel", "\uCDE8\uC18C")).onClick(() => this.finish(false))).addButton(
      (b) => b.setButtonText(ui("Show the diff", "\uBCC0\uACBD\uC0AC\uD56D \uBCF4\uAE30")).setCta().onClick(() => this.finish(true))
    );
  }
  finish(ok) {
    if (this.done) return;
    this.done = true;
    const chosen = this.suggestions.filter((s) => this.picked.has(s));
    this.resolve(ok && chosen.length ? { chosen, property: this.property } : null);
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    this.finish(false);
  }
};
function when(ms) {
  const d = new Date(ms);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
var HistoryModal = class extends import_obsidian5.Modal {
  constructor(app, changes, undo, openNote, onChange) {
    super(app);
    this.changes = changes;
    this.undo = undo;
    this.openNote = openNote;
    this.onChange = onChange;
  }
  off = null;
  onOpen() {
    this.modalEl.addClass("lva-history-modal");
    this.titleEl.setText(ui("Change history", "\uBCC0\uACBD \uAE30\uB85D"));
    this.render();
    this.off = this.onChange(() => this.render());
  }
  render() {
    const { contentEl } = this;
    contentEl.empty();
    const list = [...this.changes()].reverse();
    if (list.length === 0) {
      contentEl.createEl("p", { cls: "lva-modal-help", text: ui("No changes yet. Every diff you approve is listed here, newest first, with an Undo button.", "\uC544\uC9C1 \uBCC0\uACBD \uAE30\uB85D\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uC2B9\uC778\uD55C \uBCC0\uACBD\uC740 \uCD5C\uC2E0\uC21C\uC73C\uB85C \uD45C\uC2DC\uB418\uBA70 \uC2E4\uD589 \uCDE8\uC18C\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.") });
      return;
    }
    contentEl.createEl("p", { cls: "lva-modal-help", text: `${list.length} approved change${list.length === 1 ? "" : "s"}, newest first (the last 300 are kept). Undo shows the reverse diff for approval and refuses when the note changed since where the change was.` });
    for (const c of list) {
      const row = contentEl.createDiv({ cls: `lva-history-row${c.undone ? " lva-history-undone" : ""}` });
      const head = row.createDiv({ cls: "lva-history-head" });
      head.createSpan({ cls: "lva-history-time", text: when(c.time) });
      head.createSpan({ cls: "lva-history-what", text: c.summary ?? describeChange(c) });
      const src = c.chat === "scheduled" ? "scheduled job" : c.chat === "plugin" ? "vault suggestions" : "chat";
      head.createSpan({ cls: "lva-history-src", text: c.undone ? `${src} \xB7 undone ${when(c.undone)}` : src });
      const buttons = head.createDiv({ cls: "lva-history-buttons" });
      if (c.tool !== "move_note" && /\.md$/i.test(c.path)) {
        const openBtn = buttons.createEl("button", { text: ui("Open", "\uC5F4\uAE30") });
        openBtn.addEventListener("click", () => this.openNote(c.path));
      }
      const diffBtn = buttons.createEl("button", { text: ui("Diff", "\uBCC0\uACBD\uC0AC\uD56D \uBE44\uAD50") });
      const undoBtn = buttons.createEl("button", { text: c.undone ? ui("Undone", "\uC2E4\uD589 \uCDE8\uC18C\uB428") : "Undo", cls: c.undone ? "" : "mod-warning" });
      undoBtn.disabled = !!c.undone;
      undoBtn.addEventListener("click", () => {
        undoBtn.disabled = true;
        void this.undo(c).then((ok) => {
          if (!ok) undoBtn.disabled = false;
        });
      });
      let shown2 = null;
      diffBtn.addEventListener("click", () => {
        if (shown2) {
          shown2.remove();
          shown2 = null;
          return;
        }
        shown2 = row.createEl("pre", { cls: "lva-diff" });
        const diff = c.tool === "move_note" ? null : computeDiff(c.before, c.after);
        if (!diff) {
          shown2.createDiv({ text: `${c.before} \u2192 ${c.after}` });
          return;
        }
        for (const line of diff.lines) {
          const r = shown2.createDiv({ cls: `lva-diff-line lva-diff-${line.type}` });
          r.createSpan({ cls: "lva-diff-gutter", text: line.type === "add" ? "+" : line.type === "remove" ? "\u2212" : " " });
          r.createSpan({ cls: "lva-diff-text", text: line.text });
        }
      });
    }
  }
  onClose() {
    this.off?.();
    this.contentEl.empty();
  }
};

// src/lecture-companion.ts
var LECTURE_COMPANION_ID = "lecture-companion";
function lectureCompanionApi(app) {
  const registry = app?.plugins?.plugins;
  const api = registry?.[LECTURE_COMPANION_ID]?.api;
  if (!api || api.version !== 1) return null;
  for (const fn of ["courses", "lectures", "transcript", "transcribe", "ollama"]) {
    if (typeof api[fn] !== "function") return null;
  }
  return api;
}
function formatTimestamp(sec) {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor(s % 3600 / 60);
  const r = s % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}` : `${m}:${String(r).padStart(2, "0")}`;
}
function terms(text) {
  return (text.toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}.'-]*/gu) ?? []).filter((w) => w.length >= 3 && !STOP.has(w));
}
var STOP = /* @__PURE__ */ new Set(["the", "and", "for", "what", "when", "did", "say", "said", "about", "that", "this", "with", "was", "were", "professor", "lecture", "time", "how", "why", "which", "from", "into", "are", "you", "can"]);
function matchParagraphs(paragraphs2, query, limit = 8) {
  const q = Array.from(new Set(terms(query)));
  if (q.length === 0) return paragraphs2.slice(0, limit).map((_, index) => ({ index, score: 0 }));
  const scored = paragraphs2.map((p, index) => {
    const words = new Set(terms(p.text));
    const lower = p.text.toLowerCase();
    let score = 0;
    for (const t2 of q) {
      if (words.has(t2)) score += 1;
      else if (lower.includes(t2)) score += 0.5;
    }
    return { index, score };
  });
  return scored.filter((s) => s.score > 0).sort((a, b) => b.score - a.score || a.index - b.index).slice(0, limit);
}
function findLecture(lectures, vault, input) {
  const raw = input.trim().replace(/^\[\[|\]\]$/g, "").replace(/#.*$/, "");
  const resolved = vault.resolve(raw);
  if (resolved) {
    const hit = lectures.find((l) => l.path === resolved);
    if (hit) return hit;
  }
  const noMd3 = raw.replace(/\.md$/i, "").toLowerCase();
  const exact = lectures.find((l) => l.path.replace(/\.md$/i, "").toLowerCase() === noMd3);
  if (exact) return exact;
  const date = /\d{4}-\d{2}-\d{2}/.exec(raw)?.[0];
  if (date) {
    const sameDay = lectures.filter((l) => l.date === date);
    if (sameDay.length === 1) return sameDay[0];
    const lower = raw.toLowerCase();
    const course = sameDay.find((l) => lower.includes(l.course.toLowerCase()));
    if (course) return course;
  }
  return null;
}
function str2(args, key) {
  const v = args[key];
  return typeof v === "string" ? v.trim() : typeof v === "number" ? String(v) : "";
}
var listLectures = {
  name: "list_lectures",
  description: "List the lectures and meetings Lecture Companion recorded, from its own records: date, course, kind, note path and its one-sentence summary. Filter by course, by date range (since/until, YYYY-MM-DD) or by words in the summary. The way to find which lecture covered something before reading its transcript with lecture_transcript.",
  parameters: {
    type: "object",
    properties: {
      course: { type: "string", description: "Course name (as list_lectures shows it); omit for every course." },
      since: { type: "string", description: "Only lectures on or after this date (YYYY-MM-DD)." },
      until: { type: "string", description: "Only lectures on or before this date (YYYY-MM-DD)." },
      contains: { type: "string", description: "Only lectures whose summary sentence or course mentions these words." }
    }
  },
  mutates: false,
  async execute(args, ctx) {
    const lc = ctx.lectures;
    if (!lc) throw new ToolError("Lecture Companion is not installed; search the notes instead.");
    const course = str2(args, "course");
    const courses = lc.courses();
    let list = lc.lectures(course || void 0);
    if (course && list.length === 0) {
      const near = courses.find((c) => c.toLowerCase().includes(course.toLowerCase()) || course.toLowerCase().includes(c.toLowerCase()));
      if (near) list = lc.lectures(near);
    }
    const since = str2(args, "since");
    const until = str2(args, "until");
    if (since) list = list.filter((l) => l.date >= since);
    if (until) list = list.filter((l) => l.date <= until);
    const contains = str2(args, "contains");
    if (contains) {
      const q = terms(contains);
      list = list.filter((l) => {
        const hay = `${l.course} ${l.sentence ?? ""}`.toLowerCase();
        return q.some((t2) => hay.includes(t2));
      });
    }
    list = [...list].sort((a, b) => a.date.localeCompare(b.date) || a.course.localeCompare(b.course));
    const header = `${list.length} lecture${list.length === 1 ? "" : "s"}${course ? ` in ${course}` : ""}. Courses: ${courses.join(", ") || "(none)"}.`;
    if (list.length === 0) return `${header}
No lectures match.`;
    const shown2 = list.slice(0, 200);
    const lines = shown2.map((l) => `${l.date} \xB7 ${l.course} \xB7 ${l.kind} \xB7 ${l.path}${l.sentence ? ` \u2014 ${l.sentence}` : ""}`);
    if (list.length > shown2.length) lines.push(`\u2026 ${list.length - shown2.length} more; narrow with course or since/until.`);
    return `${header}
${lines.join("\n")}`;
  }
};
var lectureTranscript = {
  name: "lecture_transcript",
  description: "The transcript of one lecture as timestamped paragraphs [m:ss], from Lecture Companion. With query, only the paragraphs that match it best (and their neighbours); without, the whole transcript from the start. Use it for 'what did the professor say about X, and when': quote the paragraph and give its [m:ss] time, citing the lecture note.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "The lecture note's path (from list_lectures), or '<course> <date>'." },
      query: { type: "string", description: "Words to look for, e.g. 'contamination isolation forest'." }
    },
    required: ["path"]
  },
  mutates: false,
  async execute(args, ctx) {
    const lc = ctx.lectures;
    if (!lc) throw new ToolError("Lecture Companion is not installed; read the note's Transcript section instead.");
    const input = str2(args, "path");
    if (!input) throw new ToolError('Missing required argument "path".');
    const lecture = findLecture(lc.lectures(), ctx.vault, input);
    const path = lecture?.path ?? ctx.vault.resolve(input);
    if (!path) throw new ToolError(`No lecture found for "${input}". Use list_lectures to find its path.`);
    const paragraphs2 = await lc.transcript(path);
    if (paragraphs2.length === 0) return `${path} has no transcript.`;
    const query = str2(args, "query");
    let keep;
    if (query) {
      const best = matchParagraphs(paragraphs2, query, 5);
      if (best.length === 0) return `# ${path} (transcript, ${paragraphs2.length} paragraphs)
No paragraph mentions "${query}". Try other words, or call lecture_transcript without query to read it from the start.`;
      const set = /* @__PURE__ */ new Set();
      for (const b of best) for (const i of [b.index - 1, b.index, b.index + 1]) if (i >= 0 && i < paragraphs2.length) set.add(i);
      keep = Array.from(set).sort((a, b) => a - b);
    } else keep = paragraphs2.map((_, i) => i);
    const lines = [];
    let chars = 0;
    let last = -2;
    for (const i of keep) {
      const p = paragraphs2[i];
      const line = `[${formatTimestamp(p.start)}] ${p.text}`;
      if (chars + line.length > ctx.maxResultChars) {
        lines.push(`[\u2026 transcript continues; ${paragraphs2.length - i} more paragraphs. Pass query to find a passage.]`);
        break;
      }
      if (last >= 0 && i !== last + 1) lines.push("\u2026");
      lines.push(line);
      chars += line.length;
      last = i;
    }
    const head = `# ${path} (transcript${lecture ? `, ${lecture.course}, ${lecture.date}` : ""}, ${paragraphs2.length} paragraphs${query ? `, best matches for "${query}"` : ""})`;
    return `${head}
---
${lines.join("\n\n")}
---
Quote the paragraph you use with its [m:ss] time and cite [[${path.replace(/\.md$/i, "")}]].`;
  }
};
var LECTURE_TOOLS = [listLectures, lectureTranscript];

// src/quiz.ts
function iso(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
var DAYS = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
function parseSince(phrase, now) {
  const p = phrase.trim().toLowerCase().replace(/[.,!?]+$/, "").replace(/^(the|this)\s+/, "");
  const d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const isoM = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(p);
  if (isoM) return `${isoM[1]}-${isoM[2].padStart(2, "0")}-${isoM[3].padStart(2, "0")}`;
  if (p === "today") return iso(d);
  if (p === "yesterday") return iso(new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1));
  const unit = (u) => u.startsWith("day") ? 1 : u.startsWith("week") ? 7 : u.startsWith("month") ? 30 : u.startsWith("year") ? 365 : 0;
  const last = /^(?:last|past)\s+(?:(\d+|a|one|two|three|four)\s+)?(day|days|week|weeks|month|months|year|years)$/.exec(p);
  const ago = /^(\d+|a|one|two|three|four)\s+(day|days|week|weeks|month|months|year|years)\s+ago$/.exec(p);
  const m = last ?? ago;
  if (m) {
    const words = { a: 1, one: 1, two: 2, three: 3, four: 4 };
    const n = m[1] === void 0 ? 1 : words[m[1]] ?? Number(m[1]);
    return iso(new Date(d.getFullYear(), d.getMonth(), d.getDate() - n * unit(m[2])));
  }
  const dayIdx = DAYS.findIndex((x) => p === x || p === `last ${x}` || p === x.slice(0, 3));
  if (dayIdx >= 0) {
    const back = (d.getDay() - dayIdx + 7) % 7 || 7;
    return iso(new Date(d.getFullYear(), d.getMonth(), d.getDate() - back));
  }
  const md = /^([a-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s+(\d{4}))?$/.exec(p) ?? null;
  const slash = /^(\d{1,2})\/(\d{1,2})(?:\/(\d{4}))?$/.exec(p);
  let month = -1;
  let day = 0;
  let year = null;
  if (md && MONTHS.includes(md[1].slice(0, 3))) {
    month = MONTHS.indexOf(md[1].slice(0, 3));
    day = Number(md[2]);
    year = md[3] ? Number(md[3]) : null;
  } else if (slash) {
    month = Number(slash[1]) - 1;
    day = Number(slash[2]);
    year = slash[3] ? Number(slash[3]) : null;
  }
  if (month >= 0 && month < 12 && day >= 1 && day <= 31) {
    let y = year ?? d.getFullYear();
    if (year === null && new Date(y, month, day).getTime() > d.getTime()) y--;
    return iso(new Date(y, month, day));
  }
  return null;
}
function parseQuizRequest(text, now) {
  const t2 = text.trim().replace(/[.!?]+$/, "");
  const m = /^(?:please\s+)?(?:quiz|test)\s+me(?:\s+(?:on|about|over|from))?\s*(.*)$/i.exec(t2);
  if (!m) return null;
  let rest = m[1].trim();
  let since;
  const sinceM = /\s*\b(?:since|from|after|starting)\s+(.+)$/i.exec(rest) ?? /\s*\b(?:in|from|over)\s+(the\s+(?:last|past)\s+.+)$/i.exec(rest) ?? /\s*\b((?:last|this)\s+(?:week|month))$/i.exec(rest);
  if (sinceM) {
    const parsed = parseSince(sinceM[1].replace(/^this\s+week$/i, "last week").replace(/^this\s+month$/i, "last month"), now);
    if (parsed) {
      since = parsed;
      rest = rest.slice(0, sinceM.index).trim();
    }
  }
  rest = rest.replace(/^(?:my|the)\s+/i, "").replace(/\s+(?:notes|lectures|course)$/i, "").trim();
  return { topic: rest, since };
}
function noteDate(n) {
  return /(\d{4}-\d{2}-\d{2})/.exec(n.path)?.[1] ?? iso(new Date(n.mtime));
}
function selectQuizNotes(notes, req, lectures = [], max = 12) {
  const topic = req.topic.trim().toLowerCase();
  const since = req.since ?? "0000-00-00";
  if (lectures.length) {
    const courses = Array.from(new Set(lectures.map((l) => l.course)));
    const match = courses.filter((c) => topic && (c.toLowerCase().includes(topic) || topic.includes(c.toLowerCase())));
    if (match.length || !topic) {
      const picked = lectures.filter((l) => (!topic || match.includes(l.course)) && l.date >= since).sort((a, b) => a.date.localeCompare(b.date)).map((l) => l.path);
      if (picked.length) return picked.slice(-max);
    }
  }
  const words = topic.split(/\s+/).filter((w) => w.length >= 2);
  if (words.length === 0) return [];
  return notes.filter((n) => {
    const p = n.path.toLowerCase();
    return words.every((w) => p.includes(w)) && noteDate(n) >= since;
  }).sort((a, b) => noteDate(a).localeCompare(noteDate(b))).map((n) => n.path).slice(-max);
}
function quizSourceText(content, budget) {
  const body = stripFrontmatter(content).body.replace(/!\[\[[^\]]*\]\]/g, "").replace(/\n{3,}/g, "\n\n").trim();
  return body.length > budget ? body.slice(0, budget) + "\n[\u2026]" : body;
}
function questionsPrompt(topic, notes, count) {
  return [
    `Write ${count} quiz questions${topic ? ` on ${topic}` : ""} from the notes below, to test whether I remember them. Spread them over the notes; prefer definitions, key facts, reasons, formulas and decisions over trivia like dates of class.`,
    'Reply with JSON only: {"questions": [{"question": "...", "answer": "the correct answer in one or two sentences", "source": "the note path exactly as given after ---", "quote": "the sentence from that note that holds the answer, copied word for word"}]}',
    "Use only what the notes say; every answer must be in its quote.",
    "",
    ...notes.map((n) => `--- ${n.path} ---
${n.text}`)
  ].join("\n");
}
function extractJson(raw) {
  const t2 = raw.replace(/```(?:json)?/gi, "").trim();
  for (const [open, close] of [
    ["{", "}"],
    ["[", "]"]
  ]) {
    const a = t2.indexOf(open);
    const b = t2.lastIndexOf(close);
    if (a >= 0 && b > a) {
      try {
        return JSON.parse(t2.slice(a, b + 1));
      } catch {
      }
    }
  }
  return null;
}
function parseQuestions(raw, notes) {
  const json = extractJson(raw);
  const list = Array.isArray(json) ? json : Array.isArray(json?.questions) ? json.questions : [];
  const out = [];
  for (const item of list) {
    const q = item;
    const question = typeof q.question === "string" ? q.question.trim() : "";
    const answer = typeof q.answer === "string" ? q.answer.trim() : "";
    const quote = typeof q.quote === "string" ? q.quote.trim() : "";
    const src = typeof q.source === "string" ? q.source.trim().replace(/^\[\[|\]\]$/g, "") : "";
    if (!question || !answer) continue;
    const noMd3 = (s) => s.replace(/\.md$/i, "").toLowerCase();
    const note = notes.find((n) => noMd3(n.path) === noMd3(src)) ?? notes.find((n) => noMd3(n.path).endsWith("/" + noMd3(src)) || (n.path.split("/").pop() ?? "").replace(/\.md$/i, "").toLowerCase() === noMd3(src)) ?? (quote ? notes.find((n) => plainText(n.content).includes(plainText(quote))) : void 0);
    if (!note) continue;
    const para = (quote ? matchPassages(`"${quote}"`, note.content, 1)[0] : void 0) ?? matchPassages(`${question} ${answer}`, note.content, 1)[0];
    const cite = para ? passageLink(note.path, para, para.blockId) : `[[${note.path.replace(/\.md$/i, "")}]]`;
    if (out.some((o) => o.question.toLowerCase() === question.toLowerCase())) continue;
    out.push({ question, answer, source: note.path, quote, cite });
  }
  return out;
}
function isNonAnswer(text) {
  return /^\s*(?:|\?+|skip|pass|next|idk|i\s*don'?t\s*know|no idea|dunno|-+)\s*[.!]*\s*$/i.test(text);
}
function gradePrompt(q, given, sourceText) {
  return [
    "Grade a student's answer to a quiz question against the source notes. Be fair: the wording may differ, but the facts must match. A partly right or incomplete answer is 'partial'.",
    'Reply with JSON only: {"verdict": "correct" | "partial" | "wrong", "feedback": "one or two sentences to the student: what was right, what was missing or wrong"}',
    "",
    `Question: ${q.question}`,
    `Expected answer: ${q.answer}`,
    q.quote ? `Source passage: ${q.quote}` : "",
    sourceText ? `More of the source:
${sourceText}` : "",
    "",
    `Student's answer: ${given}`
  ].filter((l) => l !== "").join("\n");
}
function parseGrade(raw) {
  const json = extractJson(raw);
  const v = typeof json?.verdict === "string" ? json.verdict.toLowerCase() : "";
  const feedback = typeof json?.feedback === "string" ? json.feedback.trim() : raw.replace(/[{}"]/g, "").trim().slice(0, 400);
  const verdict = /partial|partly/.test(v) ? "partial" : /correct|right/.test(v) && !/incorrect/.test(v) ? "correct" : v ? "wrong" : /\bpartial/i.test(raw) ? "partial" : /\bincorrect|\bwrong/i.test(raw) ? "wrong" : /\bcorrect\b/i.test(raw) ? "correct" : "wrong";
  return { verdict, feedback };
}
var QuizSession = class {
  constructor(topic, questions, since) {
    this.topic = topic;
    this.questions = questions;
    this.since = since;
  }
  results = [];
  index = 0;
  current() {
    return this.questions[this.index] ?? null;
  }
  get number() {
    return this.index + 1;
  }
  record(given, verdict, feedback) {
    const q = this.current();
    if (!q) throw new Error("The quiz is over.");
    const r = { question: q, given, verdict, feedback };
    this.results.push(r);
    this.index++;
    return r;
  }
  done() {
    return this.index >= this.questions.length;
  }
  missed() {
    return this.results.filter((r) => r.verdict !== "correct");
  }
  /** "4 of 5 right (1 partly)". */
  score() {
    const right = this.results.filter((r) => r.verdict === "correct").length;
    const partial = this.results.filter((r) => r.verdict === "partial").length;
    return `${right} of ${this.results.length} right${partial ? ` (${partial} partly)` : ""}`;
  }
};
function questionMarkdown(s) {
  const q = s.current();
  return q ? `**Question ${s.number} of ${s.questions.length}.** ${q.question}` : "";
}
function resultMarkdown(r) {
  const head = r.verdict === "correct" ? "\u2705 **Correct.**" : r.verdict === "partial" ? "\u{1F7E1} **Partly.**" : "\u274C **Not quite.**";
  return [`${head} ${r.feedback}`.trim(), "", `**Answer:** ${r.question.answer} \u2014 ${r.question.cite}`].join("\n");
}
function safeName(s) {
  return s.replace(/[\\/:*?"<>|#^[\]]/g, "-").replace(/\s+/g, " ").trim() || "General";
}
function reviewNotePath(folder, topic) {
  const f = folder.replace(/^\/+|\/+$/g, "");
  return `${f ? f + "/" : ""}Quiz review - ${safeName(topic)}.md`;
}
function renderReview(existing, topic, date, missed) {
  const section = [
    `## ${date}`,
    "",
    ...missed.flatMap((r) => [
      `### ${r.question.question.replace(/\n+/g, " ")}`,
      `- Your answer: ${r.given.replace(/\n+/g, " ").trim() || "(none)"}`,
      `- Answer: ${r.question.answer.replace(/\n+/g, " ")} (${r.question.cite})`,
      ...r.feedback ? [`- Note: ${r.feedback.replace(/\n+/g, " ")}`] : [],
      ""
    ])
  ].join("\n");
  if (existing === null) return `# Quiz review: ${topic || "General"}

Questions I missed in quizzes, with the answer and where it is in my notes.

${section}`;
  return `${existing.trimEnd()}

${section}`;
}
var QuizEngine = class {
  constructor(client, config) {
    this.client = client;
    this.config = config;
  }
  async ask(prompt, signal) {
    const cfg = this.config();
    let think = false;
    for (; ; ) {
      try {
        const res = await this.client.chat({
          model: cfg.model,
          messages: [{ role: "user", content: prompt }],
          think,
          format: "json",
          options: { num_ctx: cfg.numCtx, temperature: 0.4 },
          keep_alive: cfg.keepAlive,
          signal
        });
        return res.message.content;
      } catch (err) {
        if (think !== void 0 && err instanceof OllamaError && /think/i.test(err.message)) {
          think = void 0;
          continue;
        }
        throw err;
      }
    }
  }
  /** Questions from the notes (contents keyed by path), at most `count`. */
  async questions(topic, notes, count = 5, signal) {
    const perNote = Math.max(1500, Math.floor(4e4 / Math.max(1, notes.length)));
    const prompt = questionsPrompt(topic, notes.map((n) => ({ path: n.path, text: quizSourceText(n.content, perNote) })), count);
    const parsed = parseQuestions(await this.ask(prompt, signal), notes);
    return parsed.slice(0, count);
  }
  async grade(q, given, sourceText, signal) {
    if (isNonAnswer(given)) return { verdict: "wrong", feedback: "No answer given." };
    return parseGrade(await this.ask(gradePrompt(q, given, sourceText), signal));
  }
};

// src/scheduler.ts
function parseTime(hhmm) {
  const m = /^\s*(\d{1,2}):(\d{2})\s*$/.exec(hhmm);
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  return h < 24 && min < 60 ? h * 60 + min : null;
}
function lastScheduled(job, now, s) {
  if (job === "daily" ? !s.nightlyDaily : !s.weeklyDigest) return null;
  const minutes = parseTime(job === "daily" ? s.nightlyTime : s.digestTime);
  if (minutes === null) return null;
  const at = new Date(now.getFullYear(), now.getMonth(), now.getDate(), Math.floor(minutes / 60), minutes % 60, 0, 0);
  if (job === "daily") {
    if (at.getTime() > now.getTime()) at.setDate(at.getDate() - 1);
    return at;
  }
  const day = (Math.floor(s.digestDay) % 7 + 7) % 7;
  at.setDate(at.getDate() - (at.getDay() - day + 7) % 7);
  if (at.getTime() > now.getTime()) at.setDate(at.getDate() - 7);
  return at;
}
function dueJobs(now, s, lastRuns) {
  const out = [];
  for (const job of ["daily", "digest"]) {
    const at = lastScheduled(job, now, s);
    const last = lastRuns[job];
    if (at && typeof last === "number" && last < at.getTime()) out.push(job);
  }
  return out;
}
function localDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
var OverlayVault = class {
  constructor(base) {
    this.base = base;
  }
  writes = /* @__PURE__ */ new Map();
  created = /* @__PURE__ */ new Set();
  listNotes() {
    const notes = this.base.listNotes().map((n) => this.writes.has(n.path) ? { ...n, size: this.writes.get(n.path).length } : n);
    for (const path of this.created) {
      const name = path.split("/").pop() ?? path;
      notes.push({ path, basename: name.replace(/\.md$/i, ""), folder: path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "", mtime: Date.now(), ctime: Date.now(), size: this.writes.get(path)?.length ?? 0 });
    }
    return notes;
  }
  resolve(pathOrName) {
    const p = pathOrName.trim().replace(/^\[\[|\]\]$/g, "").replace(/^\/+/, "");
    for (const c of [p, `${p}.md`]) if (this.created.has(c)) return c;
    const name = p.replace(/\.md$/i, "").toLowerCase();
    for (const c of this.created) if ((c.split("/").pop() ?? "").replace(/\.md$/i, "").toLowerCase() === name) return c;
    return this.base.resolve(pathOrName);
  }
  exists(path) {
    return this.created.has(path) || this.base.exists(path);
  }
  async read(path) {
    const held = this.writes.get(path);
    return held !== void 0 ? held : this.base.read(path);
  }
  async create(path, content) {
    if (this.exists(path)) throw new Error(`Already exists: ${path}`);
    this.created.add(path);
    this.writes.set(path, content);
  }
  async modify(path, content) {
    if (!this.exists(path)) throw new Error(`Note not found: ${path}`);
    this.writes.set(path, content);
  }
  listAttachments() {
    return this.base.listAttachments();
  }
  resolveFile(path) {
    return this.resolve(path) ?? this.base.resolveFile(path);
  }
  async trash() {
    throw new Error("Deleting is not possible in a scheduled run; only new notes and edits can wait for approval.");
  }
  readBinary(path) {
    return this.base.readBinary(path);
  }
  async createBinary() {
    throw new Error("Attachments cannot be written in a scheduled run.");
  }
  async rename() {
    throw new Error("Moving is not possible in a scheduled run; only new notes and edits can wait for approval.");
  }
  getMetadata(path) {
    const held = this.writes.get(path);
    if (held === void 0) return this.base.getMetadata(path);
    const meta = this.created.has(path) ? { tags: [], links: [], backlinks: [], headings: [], frontmatter: {} } : this.base.getMetadata(path);
    return {
      ...meta,
      headings: Array.from(held.matchAll(/^(#{1,6}) (.+)$/gm), (m) => `${m[1]} ${m[2]}`),
      links: Array.from(held.matchAll(/\[\[([^\]|#]+)/g), (m) => m[1])
    };
  }
  getActiveNotePath() {
    return null;
  }
  getSelection() {
    return null;
  }
  /** What the run would write, one change per note, compared with the vault as it is now. */
  async changes() {
    const out = [];
    for (const [path, after] of this.writes) {
      const created = this.created.has(path);
      const before = created ? "" : await this.base.read(path);
      if (before !== after) out.push({ path, tool: created ? "create_note" : "edit_note", before, after });
    }
    return out;
  }
};
var JOB_NAMES = { daily: "Nightly: process my daily notes", digest: "Weekly digest" };
var PendingQueue = class {
  items = [];
  nextId = 1;
  listeners = /* @__PURE__ */ new Set();
  get size() {
    return this.items.length;
  }
  list() {
    return this.items;
  }
  add(job, changes, time = Date.now()) {
    const added = [];
    for (const c of changes) {
      const old = this.items.findIndex((i) => i.path === c.path && i.job === job);
      const before = old >= 0 ? this.items[old].before : c.before;
      if (old >= 0) this.items.splice(old, 1);
      const item = { ...c, before, id: this.nextId++, job, time, summary: `${JOB_NAMES[job]}: ${c.tool === "create_note" ? "create" : "edit"} ${c.path}` };
      this.items.push(item);
      added.push(item);
    }
    if (added.length) this.emit();
    return added;
  }
  remove(id) {
    const n = this.items.length;
    this.items = this.items.filter((i) => i.id !== id);
    if (this.items.length !== n) this.emit();
  }
  load(data) {
    if (!Array.isArray(data)) return;
    this.items = data.filter((d) => {
      const c = d;
      return !!c && typeof c.id === "number" && typeof c.path === "string" && typeof c.after === "string" && typeof c.before === "string";
    });
    this.nextId = this.items.reduce((m, c) => Math.max(m, c.id), 0) + 1;
    this.emit();
  }
  toJSON() {
    return this.items;
  }
  onChange(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  emit() {
    for (const l of this.listeners) l();
  }
};
async function planPending(change, vault) {
  if (change.tool === "create_note") {
    if (vault.exists(change.path)) return { ok: false, reason: `${change.path} was created in the meantime.` };
    return { ok: true, before: "", after: change.after };
  }
  if (!vault.exists(change.path)) return { ok: false, reason: `${change.path} no longer exists.` };
  const current2 = await vault.read(change.path);
  const after = carryOnto(current2, change.before, change.after);
  if (after === null) return { ok: false, reason: `${change.path} was edited since the job ran, where the job would change it.` };
  if (after === current2) return { ok: false, reason: `${change.path} already has this change.` };
  return { ok: true, before: current2, after };
}
function recentNotes(notes, now, days = 7) {
  const since = now.getTime() - days * 864e5;
  return notes.filter((n) => n.mtime >= since && n.mtime <= now.getTime() + 6e4).sort((a, b) => b.mtime - a.mtime);
}
function digestPrompt(weekOf, notes) {
  return [
    `Write a short weekly digest of my notes for the week ending ${weekOf}. Below are the notes I created or changed this week.`,
    "Group what happened by theme in a few short sections with '###' headings (projects, courses, ideas, people, \u2026). Under each, 2\u20135 bullets with the concrete facts, decisions, deadlines and open questions, each bullet ending with the wikilink of the note it came from, e.g. [[Projects/Chess Robot]]. Finish with '### Open threads': things left unfinished or to follow up.",
    "Use only what is in these notes; never invent anything. No preamble, no closing remarks; start with the first '###' heading.",
    "",
    ...notes.map((n) => `--- ${n.path.replace(/\.md$/i, "")} ---
${n.text}`)
  ].join("\n");
}
function digestPath(folder, weekOf) {
  const f = folder.replace(/^\/+|\/+$/g, "");
  return `${f ? f + "/" : ""}Digest ${weekOf}.md`;
}
function renderDigest(weekOf, summary, notes) {
  const list = notes.map((n) => `- [[${n.path.replace(/\.md$/i, "")}]] (${localDate(new Date(n.mtime))})`);
  return [`# Weekly digest, week ending ${weekOf}`, "", summary.trim(), "", "## Notes changed this week", "", ...list, ""].join("\n");
}

// src/vision.ts
function arrayBufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = "";
  const CHUNK = 32768;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(binary);
}
async function sha256Hex(buf) {
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}
var VISION_PROMPT = "Read this image for someone who cannot see it. First transcribe every piece of text in it exactly as written (printed or handwritten, keeping line breaks, formulas in LaTeX), under 'Text:'. Then, under 'Description:', describe in a few sentences what it shows (diagram, chart with its axes and values, photo, slide). Do not guess at what is not visible.";
var MAX_ENTRIES = 2e3;
var ImageReader = class {
  constructor(deps) {
    this.deps = deps;
  }
  data = { version: 1, entries: {} };
  loaded = false;
  capable = /* @__PURE__ */ new Map();
  /** The model that will read images, or null when there is none ("" setting and a chat model without vision). */
  async model() {
    const configured = this.deps.getVisionModel().trim();
    if (configured) return configured;
    const chat = this.deps.getChatModel();
    if (!this.capable.has(chat)) {
      try {
        this.capable.set(chat, (await this.deps.client.showCapabilities(chat)).includes("vision"));
      } catch {
        return null;
      }
    }
    return this.capable.get(chat) ? chat : null;
  }
  /** Forget the capability check (settings changed). */
  reset() {
    this.capable.clear();
  }
  async ensureLoaded() {
    if (this.loaded) return;
    this.loaded = true;
    try {
      const d = await this.deps.load();
      if (d && d.version === 1 && d.entries) this.data = d;
    } catch {
    }
  }
  /** Text and description of an image, or of one page of a PDF. Cached by content hash, model, page and question. */
  async describe(path, opts = {}) {
    const model = await this.model();
    if (!model) throw new ToolError("No vision model is available. Install one (for example `ollama pull qwen2.5vl:7b`) and set it under Settings \u2192 Local Vault Agent \u2192 Vision model.");
    const ext = /\.([a-z0-9]+)$/i.exec(path)?.[1]?.toLowerCase() ?? "";
    let image;
    const raw = await this.deps.readBinary(path);
    if (ext === "pdf") {
      if (!this.deps.renderPdfPage) throw new ToolError("Rendering PDF pages is not available here.");
      image = await this.deps.renderPdfPage(path, Math.max(1, opts.page ?? 1));
    } else if (IMAGE_EXTENSIONS.includes(ext)) image = raw;
    else throw new ToolError(`Cannot read .${ext} images; PNG, JPEG, WebP and PDF pages are supported.`);
    await this.ensureLoaded();
    const key = cacheKey(await sha256Hex(raw), model, ext === "pdf" ? Math.max(1, opts.page ?? 1) : void 0, opts.question);
    const hit = this.data.entries[key];
    if (hit) return hit.text;
    const prompt = opts.question?.trim() ? `${VISION_PROMPT}
Also answer this question about it: ${opts.question.trim()}` : VISION_PROMPT;
    const text = await this.ask(model, prompt, arrayBufferToBase64(image));
    this.data.entries[key] = { text, time: Date.now() };
    const keys = Object.keys(this.data.entries);
    if (keys.length > MAX_ENTRIES) {
      keys.sort((a, b) => this.data.entries[a].time - this.data.entries[b].time);
      for (const k of keys.slice(0, keys.length - MAX_ENTRIES)) delete this.data.entries[k];
    }
    await this.deps.save(this.data);
    return text;
  }
  async ask(model, prompt, image) {
    let think = false;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await this.deps.client.chat({
          model,
          messages: [{ role: "user", content: prompt, images: [image] }],
          think,
          options: { num_ctx: 8192, temperature: 0.2 },
          keep_alive: this.deps.keepAlive()
        });
        const text = res.message.content.trim();
        if (!text) throw new ToolError(`${model} returned nothing for this image.`);
        return text;
      } catch (err) {
        if (think !== void 0 && err instanceof OllamaError && /think/i.test(err.message)) {
          think = void 0;
          continue;
        }
        if (err instanceof OllamaError && /image|vision|multimodal/i.test(err.message)) {
          throw new ToolError(`${model} cannot read images (${err.message}). Pick a vision model in settings, e.g. qwen2.5vl:7b.`);
        }
        throw err;
      }
    }
    throw new ToolError("The vision model did not answer.");
  }
};
function cacheKey(hash, model, page, question) {
  return [hash, model, page ?? "", (question ?? "").trim().toLowerCase()].join("|");
}
var readImage = {
  name: "read_image",
  description: "Read an image or a scanned PDF page with the local vision model: transcribes the text in it (printed or handwritten) and describes diagrams, charts and photos. Use it for images a note embeds (![[photo.png]]) when their content matters, or for PDF pages read_file found no text on. Slow (seconds per image) but cached.",
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path of the image or PDF, e.g. 'Attachments/whiteboard.jpg'." },
      page: { type: "integer", description: "For a PDF: the page number (from 1)." },
      question: { type: "string", description: "Optional: what you want to know about the image." }
    },
    required: ["path"]
  },
  mutates: false,
  async execute(args, ctx) {
    const input = typeof args.path === "string" ? args.path : "";
    if (!input.trim()) throw new ToolError('Missing required argument "path".');
    if (!ctx.describeImage) throw new ToolError("No vision model is available.");
    const path = ctx.vault.resolveFile(input.trim().replace(/^!?\[\[|\]\]$/g, "").replace(/\|.*$/, ""));
    if (!path) throw new ToolError(`No file found for "${input}". Use list_files to find the exact path.`);
    const page = typeof args.page === "number" ? args.page : typeof args.page === "string" ? parseInt(args.page, 10) || void 0 : void 0;
    const question = typeof args.question === "string" ? args.question : void 0;
    const text = await ctx.describeImage(path, { page, question });
    return `# ${path}${page ? ` (page ${page})` : ""}
---
${text}`;
  }
};

// src/help-modals.ts
var import_obsidian6 = require("obsidian");

// src/log.ts
var RingLog = class {
  constructor(capacity = 200, now = () => Date.now()) {
    this.capacity = capacity;
    this.now = now;
  }
  entries = [];
  add(level, message) {
    this.entries.push({ time: this.now(), level, message: message.replace(/\s+/g, " ").trim().slice(0, 500) });
    if (this.entries.length > this.capacity) this.entries.splice(0, this.entries.length - this.capacity);
  }
  info(message) {
    this.add("info", message);
  }
  warn(message) {
    this.add("warn", message);
  }
  error(message) {
    this.add("error", message instanceof Error ? `${message.name}: ${message.message}` : message);
  }
  /** The last `n` entries, oldest first. */
  tail(n = 50) {
    return this.entries.slice(-n);
  }
  /** The most recent error, if any. */
  lastError() {
    for (let i = this.entries.length - 1; i >= 0; i--) if (this.entries[i].level === "error") return this.entries[i];
    return void 0;
  }
  get size() {
    return this.entries.length;
  }
};
var log = new RingLog();
function formatLogLine(e) {
  return `${new Date(e.time).toISOString().slice(11, 19)} ${e.level.toUpperCase().padEnd(5)} ${e.message}`;
}

// src/report.ts
var REPO = "TonyPeonio/obsidian-local-vault-agent";
var MAX_URL_CHARS = 7e3;
var SECRET_KEYS = /key|token|secret|password|auth|bearer/i;
var PERSONAL_KEYS = /* @__PURE__ */ new Set(["extraSystemPrompt", "jobRuns", "excludedFolders", "conceptFolders", "conventionsNote", "dailyTopicsFolder", "dailyInboxHeading", "quizReviewFolder", "digestFolder"]);
function escapeRegExp2(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function redact(text, paths = {}) {
  let out = text;
  out = out.replace(/\b([a-z][a-z0-9+.-]*:\/\/)(?:[^\s/@]+@)?([^\s/?#]+)([^\s?#]*)(?:\?[^\s#]*)?(?:#\S*)?/gi, "$1$2$3");
  out = out.replace(/\b(Bearer|Token)\s+[A-Za-z0-9._~+/=-]{8,}/gi, "$1 <redacted>");
  out = out.replace(/\b(sk|pk|rk|ghp|gho|ghs|github_pat|hf|xox[abp])[-_][A-Za-z0-9_-]{10,}\b/g, "<redacted-key>");
  out = out.replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, "<email>");
  const swap = (from, to) => {
    if (!from || from.length < 3) return;
    const pattern = from.replace(/[\\/]+$/, "").split(/[\\/]+/).map(escapeRegExp2).join("[\\\\/]+");
    out = out.replace(new RegExp(pattern, "gi"), to);
  };
  swap(paths.vault, "<vault>");
  swap(paths.home, "~");
  out = out.replace(/\b[A-Za-z]:[\\/]+Users[\\/]+[^\\/\s"'`]+/gi, "~").replace(/\/(?:Users|home)\/[^/\s"'`]+/g, "~");
  return out;
}
function safeSettings(settings, paths = {}) {
  const out = {};
  for (const [k, v] of Object.entries(settings)) {
    if (SECRET_KEYS.test(k)) {
      out[k] = typeof v === "string" && v ? "(set, not shown)" : "(empty)";
      continue;
    }
    if (PERSONAL_KEYS.has(k)) {
      out[k] = typeof v === "string" ? v.trim() ? `(${v.length} characters, not shown)` : "(empty)" : Array.isArray(v) ? `(${v.length} entries, not shown)` : "(not shown)";
      continue;
    }
    out[k] = typeof v === "string" ? redact(v, paths) : Array.isArray(v) ? v.map((x) => typeof x === "string" ? redact(x, paths) : x) : v;
  }
  return out;
}
function chatTranscript(messages, max = 6e3) {
  const lines = [];
  for (const m of messages) {
    if (m.role === "user") lines.push(`**User:** ${m.content.split("\n\n(The user attached")[0]}`);
    else if (m.role === "assistant") {
      if (m.content.trim()) lines.push(`**Assistant:** ${m.content}`);
      for (const c of m.tool_calls ?? []) lines.push(`- tool call: ${c.function.name}`);
    } else if (m.role === "tool") lines.push(`- ${m.tool_name ?? "tool"} result: ${m.content.length} characters${/^Error|^Not executed/.test(m.content) ? ` \u2014 ${m.content.slice(0, 200)}` : ""}`);
  }
  const text = lines.join("\n");
  return text.length > max ? `\u2026${text.slice(-max)}` : text;
}
var CHAT_SUMMARY = "<details><summary>Last chat (included by the user)</summary>";
var WHAT_HEAD = "### What happened\n\n";
var WHAT_END = "\n\n### Environment";
function withDescription(edited, fresh) {
  const span = (s) => {
    const head = s.indexOf(WHAT_HEAD);
    const end = head < 0 ? -1 : s.indexOf(WHAT_END, head + WHAT_HEAD.length);
    return end < 0 ? null : [head + WHAT_HEAD.length, end];
  };
  const e = span(edited);
  const f = span(fresh);
  if (!e || !f) return null;
  return edited.slice(0, e[0]) + fresh.slice(f[0], f[1]) + edited.slice(e[1]);
}
function withChatSection(edited, without, withChat, include) {
  const section = withChat.startsWith(without) ? withChat.slice(without.length) : "";
  const exact = section ? edited.lastIndexOf(section) : -1;
  if (include) return exact >= 0 || !section ? edited : edited.replace(/\s+$/, "") + section;
  if (exact >= 0) return edited.slice(0, exact) + edited.slice(exact + section.length);
  const start = edited.lastIndexOf(CHAT_SUMMARY);
  if (start < 0) return edited;
  const close = edited.lastIndexOf("</details>");
  if (close < start) return null;
  return edited.slice(0, start).replace(/\s+$/, "") + edited.slice(close + "</details>".length);
}
function buildReport(info, description, opts = {}) {
  const p = opts.paths ?? {};
  const settings = safeSettings(info.settings, p);
  const body = [
    "### What happened",
    "",
    description.trim() || "<!-- What did you do, what did you expect, what happened instead? -->",
    "",
    "### Environment",
    "",
    `- Local Vault Agent ${info.pluginVersion}, Obsidian ${info.obsidianVersion}, ${info.platform}${info.mobile ? " (mobile)" : ""}`,
    `- Provider: ${info.provider}${info.serverVersion ? ` ${info.serverVersion}` : " (not reachable)"}`,
    `- Chat model: ${info.chatModel} \xB7 embedding: ${info.embeddingModel} \xB7 vision: ${info.visionModel || "(chat model if it can see)"}`,
    `- Installed models: ${info.installedModels ? info.installedModels.join(", ") || "(none)" : "(server not reachable)"}`,
    `- Vault: ${info.notes} notes \xB7 index: ${info.index}`,
    `- Other enabled plugins: ${info.otherPlugins.length ? info.otherPlugins.join(", ") : "(none)"}`,
    "",
    "<details><summary>Settings (keys and personal text left out)</summary>",
    "",
    "```json",
    JSON.stringify(settings, null, 1),
    "```",
    "</details>",
    "",
    "<details><summary>Recent log</summary>",
    "",
    "```",
    info.log.length ? info.log.map(formatLogLine).join("\n") : "(empty)",
    "```",
    "</details>"
  ];
  if (opts.chat?.trim()) body.push("", CHAT_SUMMARY, "", opts.chat.trim(), "", "</details>");
  return redact(body.join("\n"), p);
}
function reportTitle(description, lastError, paths = {}) {
  const first = redact(description, paths).trim().split("\n")[0]?.trim() || redact(lastError ?? "", paths).trim() || "Problem report";
  return first.length > 80 ? first.slice(0, 77) + "\u2026" : first;
}
function wellFormed(s) {
  return s.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDFFF]/g, (m) => m.length === 2 ? m : "");
}
function issueUrl(title, body, repo = REPO) {
  const base = `https://github.com/${repo}/issues/new`;
  title = wellFormed(title);
  const full = `${base}?title=${encodeURIComponent(title)}&body=${encodeURIComponent(wellFormed(body))}`;
  if (full.length <= MAX_URL_CHARS) return { url: full, copyFirst: false };
  const short2 = "<!-- The report was copied to your clipboard: paste it here (Ctrl/Cmd+V), then review it before submitting. -->\n\n";
  return { url: `${base}?title=${encodeURIComponent(title)}&body=${encodeURIComponent(short2)}`, copyFirst: true };
}
function surveyUrl(answer, version, repo = REPO) {
  const title = `Feedback: ${answer}`;
  const body = `How is Local Vault Agent working for me? **${answer}**

(Version ${version}.) <!-- Anything to add: what you use it for, what is missing, what went wrong. -->`;
  return `https://github.com/${repo}/discussions/new?category=general&title=${encodeURIComponent(title)}&body=${encodeURIComponent(body)}`;
}

// src/setup.ts
var RECOMMENDED = {
  "24": "qwen3.5:35b-a3b",
  "12": "qwen3.5:9b",
  "8": "qwen3.5:4b",
  cpu: "qwen3.5:4b"
};
var RECOMMENDED_EMBED = "nomic-embed-text";
function guessTier(deviceMemoryGb) {
  if (deviceMemoryGb === void 0) return "12";
  return deviceMemoryGb >= 8 ? "12" : "8";
}
function isEmbedding(m) {
  return m.capabilities ? m.capabilities.includes("embedding") && !m.capabilities.includes("completion") : /embed|bge|e5-|gte-|minilm/i.test(m.name);
}
function canCallTools(m) {
  return m.capabilities ? m.capabilities.includes("tools") : !isEmbedding(m);
}
function evaluateSetup(i) {
  const steps = [];
  const pullable = i.provider === "ollama";
  if (!i.models) {
    steps.push({ id: "server", state: "missing", detail: ui(i.provider === "ollama" ? `Ollama is not reachable${i.serverError ? ` (${i.serverError})` : ""}. Install it from ollama.com and start it, or fix the URL in settings.` : `The server is not reachable${i.serverError ? ` (${i.serverError})` : ""}. Start it (LM Studio: enable the local server) or fix the URL in settings.`, i.provider === "ollama" ? "Ollama\uC5D0 \uC5F0\uACB0\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uC11C\uBC84\uB97C \uC2DC\uC791\uD558\uAC70\uB098 \uC124\uC815\uC5D0\uC11C \uC8FC\uC18C\uB97C \uD655\uC778\uD558\uC138\uC694." : "\uBAA8\uB378 \uC11C\uBC84\uC5D0 \uC5F0\uACB0\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. DNA \uC11C\uBC84 \uC2E4\uD589 \uC2A4\uD06C\uB9BD\uD2B8\uB97C \uC2E4\uD589\uD558\uACE0 \uC11C\uBC84 \uC8FC\uC18C\uB97C \uD655\uC778\uD558\uC138\uC694."), fix: { kind: "settings" } });
    steps.push({ id: "chat", state: "unknown", detail: ui("Waiting for the server.", "\uC11C\uBC84 \uC5F0\uACB0\uC744 \uAE30\uB2E4\uB9AC\uB294 \uC911\uC785\uB2C8\uB2E4.") });
    steps.push({ id: "embed", state: "unknown", detail: ui("Waiting for the server.", "\uC11C\uBC84 \uC5F0\uACB0\uC744 \uAE30\uB2E4\uB9AC\uB294 \uC911\uC785\uB2C8\uB2E4.") });
    steps.push({ id: "index", state: "unknown", detail: ui("Waiting for the server.", "\uC11C\uBC84 \uC5F0\uACB0\uC744 \uAE30\uB2E4\uB9AC\uB294 \uC911\uC785\uB2C8\uB2E4.") });
    return steps;
  }
  steps.push({ id: "server", state: "ok", detail: ui(`${i.models.length} model${i.models.length === 1 ? "" : "s"} available.`, `\uC0AC\uC6A9 \uAC00\uB2A5\uD55C \uBAA8\uB378 ${i.models.length}\uAC1C`) });
  const chat = i.models.find((m) => sameModel(m.name, i.chatModel));
  const recommended = RECOMMENDED[i.tier];
  const toolModels = i.models.filter(canCallTools);
  if (chat && canCallTools(chat)) steps.push({ id: "chat", state: "ok", detail: ui(`${chat.name} is installed and can call tools.`, `${chat.name} \uC0AC\uC6A9 \uAC00\uB2A5 \xB7 \uB3C4\uAD6C \uD638\uCD9C \uC9C0\uC6D0`) });
  else if (chat) {
    const alt = toolModels[0];
    steps.push({ id: "chat", state: "missing", detail: ui(`${chat.name} cannot call tools, which the agent needs.`, `${chat.name}\uC740 \uB3C4\uAD6C \uD638\uCD9C\uC744 \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.`), fix: alt ? { kind: "use", model: alt.name, role: "chat" } : pullable ? { kind: "pull", model: recommended, role: "chat" } : { kind: "settings" } });
  } else {
    const installedRec = i.models.find((m) => sameModel(m.name, recommended));
    steps.push({
      id: "chat",
      state: "missing",
      detail: ui(`${i.chatModel} is not installed.`, `\uC11C\uBC84\uC5D0 ${i.chatModel} \uBAA8\uB378\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.`),
      fix: installedRec ? { kind: "use", model: installedRec.name, role: "chat" } : pullable ? { kind: "pull", model: recommended, role: "chat" } : toolModels[0] ? { kind: "use", model: toolModels[0].name, role: "chat" } : { kind: "settings" }
    });
  }
  if (!i.semanticSearch) steps.push({ id: "embed", state: "warn", detail: ui("Semantic search is off; keyword search only.", "\uC758\uBBF8 \uAC80\uC0C9\uC774 \uAEBC\uC838 \uC788\uC5B4 \uD0A4\uC6CC\uB4DC\uB85C \uAC80\uC0C9\uD569\uB2C8\uB2E4."), fix: { kind: "settings" } });
  else if (i.models.some((m) => sameModel(m.name, i.embeddingModel))) steps.push({ id: "embed", state: "ok", detail: ui(`${i.embeddingModel} is installed.`, `${i.embeddingModel} \uC0AC\uC6A9 \uAC00\uB2A5`) });
  else {
    const other = i.models.find(isEmbedding);
    steps.push({ id: "embed", state: "missing", detail: ui(`${i.embeddingModel} is not installed; search falls back to keywords.`, `${i.embeddingModel}\uC774 \uC5C6\uC5B4 \uD0A4\uC6CC\uB4DC \uAC80\uC0C9\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4.`), fix: pullable ? { kind: "pull", model: i.embeddingModel || RECOMMENDED_EMBED, role: "embed" } : other ? { kind: "use", model: other.name, role: "embed" } : { kind: "settings" } });
  }
  if (!i.semanticSearch) steps.push({ id: "index", state: "warn", detail: ui("No index without semantic search.", "\uC758\uBBF8 \uAC80\uC0C9\uC774 \uAEBC\uC838 \uC788\uC5B4 \uC0C9\uC778\uC744 \uB9CC\uB4E4\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.") });
  else if (i.index.lastError) steps.push({ id: "index", state: "missing", detail: ui(`Index error: ${i.index.lastError}`, `\uC0C9\uC778 \uC624\uB958 \xB7 ${i.index.lastError}`), fix: { kind: "index" } });
  else if (i.index.building) steps.push({ id: "index", state: "warn", detail: `Indexing\u2026 ${i.index.indexedFiles} of ${i.index.indexedFiles + i.index.pending} notes.` });
  else if (i.index.indexedFiles === 0 && i.notes > 0) steps.push({ id: "index", state: "missing", detail: ui(`None of your ${i.notes} notes are indexed yet.`, `\uB178\uD2B8 ${i.notes}\uAC1C\uC758 \uC0C9\uC778\uC744 \uC544\uC9C1 \uB9CC\uB4E4\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.`), fix: { kind: "index" } });
  else steps.push({ id: "index", state: "ok", detail: ui(`${i.index.indexedFiles} notes indexed.`, `\uB178\uD2B8 ${i.index.indexedFiles}\uAC1C \uC0C9\uC778 \uC644\uB8CC`) });
  return steps;
}
function setupComplete(steps) {
  return steps.every((s) => s.state === "ok" || s.state === "warn");
}
function formatProgress(fraction, status) {
  return fraction === null ? status || "starting\u2026" : `${Math.round(fraction * 100)}%`;
}

// src/help-modals.ts
var ReportModal = class extends import_obsidian6.Modal {
  constructor(app, build, title, initialDescription = "") {
    super(app);
    this.build = build;
    this.title = title;
    this.description = initialDescription;
  }
  description = "";
  includeChat = false;
  edited = false;
  warnedDetached = false;
  preview;
  onOpen() {
    const { contentEl, titleEl, modalEl } = this;
    modalEl.addClass("lva-options-modal", "lva-report-modal");
    titleEl.setText(t("report.title"));
    contentEl.createEl("p", { cls: "lva-modal-help", text: t("report.help") });
    const what = contentEl.createEl("textarea", { cls: "lva-report-what", attr: { rows: "4", placeholder: t("report.what.placeholder"), "aria-label": t("report.what") } });
    what.value = this.description;
    what.addEventListener("input", () => {
      this.description = what.value;
      this.refresh();
    });
    new import_obsidian6.Setting(contentEl).setName(t("report.chat")).addToggle(
      (tg) => tg.setValue(false).onChange((v) => {
        this.includeChat = v;
        this.toggleChat();
      })
    );
    this.preview = contentEl.createEl("textarea", { cls: "lva-report-preview", attr: { rows: "14", "aria-label": t("report.title"), spellcheck: "false" } });
    this.preview.addEventListener("input", () => this.edited = true);
    this.refresh();
    new import_obsidian6.Setting(contentEl).addButton((b) => b.setButtonText(t("report.copy")).onClick(() => void this.copy())).addButton(
      (b) => b.setButtonText(t("report.open")).setCta().onClick(() => void this.openIssue())
    );
    window.setTimeout(() => what.focus(), 0);
  }
  /**
   * Rebuilds the preview from the description. Once the user has edited the preview by hand it is
   * never rebuilt (that would bring back what they deleted): only its "What happened" text follows
   * the description box.
   */
  refresh() {
    if (!this.edited) {
      this.preview.value = this.build(this.description, this.includeChat);
      return;
    }
    const next = withDescription(this.preview.value, this.build(this.description, false));
    if (next !== null) this.preview.value = next;
    else if (!this.warnedDetached) {
      this.warnedDetached = true;
      new import_obsidian6.Notice("The report below was edited and no longer has a \u201CWhat happened\u201D section, so it does not follow this box any more. Add your description to the report itself.", 1e4);
    }
  }
  /** Adds or removes the last chat. A hand-edited preview keeps its edits: only the chat section changes. */
  toggleChat() {
    if (!this.edited) {
      this.refresh();
      return;
    }
    const next = withChatSection(this.preview.value, this.build(this.description, false), this.build(this.description, true), this.includeChat);
    if (next !== null) this.preview.value = next;
    else new import_obsidian6.Notice("The chat section of the report was edited; remove it from the report by hand.", 1e4);
  }
  async copy() {
    await navigator.clipboard.writeText(this.preview.value);
    new import_obsidian6.Notice(t("report.copied"));
  }
  async openIssue() {
    const body = this.preview.value;
    const { url, copyFirst } = issueUrl(this.title(this.description), body);
    if (copyFirst) {
      await navigator.clipboard.writeText(body);
      new import_obsidian6.Notice(t("report.tooLong"), 1e4);
    }
    window.open(url);
  }
  onClose() {
    this.contentEl.empty();
  }
};
var SetupModal = class extends import_obsidian6.Modal {
  constructor(app, actions) {
    super(app);
    this.actions = actions;
    this.tier = actions.initialTier;
  }
  tier;
  listEl;
  busy = false;
  onOpen() {
    const { contentEl, titleEl, modalEl } = this;
    modalEl.addClass("lva-options-modal", "lva-setup-modal");
    titleEl.setText(t("setup.title"));
    contentEl.createEl("p", { cls: "lva-modal-help", text: t("setup.help") });
    if (this.actions.configuredModel) {
      new import_obsidian6.Setting(contentEl).setName(t("set.model.name")).setDesc(this.actions.configuredModel);
    } else new import_obsidian6.Setting(contentEl).setName(t("setup.recommend")).addDropdown(
      (d) => d.addOptions({
        "24": `${t("setup.rec.24")} \u2192 ${RECOMMENDED["24"]}`,
        "12": `${t("setup.rec.12")} \u2192 ${RECOMMENDED["12"]}`,
        "8": `${t("setup.rec.8")} \u2192 ${RECOMMENDED["8"]}`,
        cpu: `${t("setup.rec.cpu")} \u2192 ${RECOMMENDED.cpu}`
      }).setValue(this.tier).onChange((v) => {
        this.tier = v;
        void this.render();
      })
    );
    this.listEl = contentEl.createDiv({ cls: "lva-setup-list", attr: { role: "list", "aria-live": "polite" } });
    new import_obsidian6.Setting(contentEl).addButton((b) => b.setButtonText(t("setup.recheck")).onClick(() => void this.render())).addButton((b) => b.setButtonText(t("setup.sample")).onClick(() => void this.actions.trySample().then(() => this.close())));
    void this.render();
  }
  async render() {
    this.listEl.empty();
    this.listEl.createDiv({ cls: "lva-setup-checking", text: t("setup.checking") });
    const steps = await this.actions.evaluate(this.tier);
    this.listEl.empty();
    const names = { server: t("setup.server"), chat: t("setup.chat"), embed: t("setup.embed"), index: t("setup.index") };
    for (const step of steps) {
      const row = this.listEl.createDiv({ cls: `lva-setup-step lva-setup-${step.state}`, attr: { role: "listitem" } });
      const icon = step.state === "ok" ? "\u2713" : step.state === "warn" ? "!" : step.state === "unknown" ? "\u2026" : "\u2717";
      row.createSpan({ cls: "lva-setup-icon", text: icon, attr: { "aria-hidden": "true" } });
      const text = row.createDiv({ cls: "lva-setup-text" });
      text.createDiv({ cls: "lva-setup-name", text: names[step.id] });
      const detail = text.createDiv({ cls: "lva-setup-detail", text: step.detail });
      row.setAttribute("aria-label", `${names[step.id]}: ${step.state}. ${step.detail}`);
      if (step.fix) {
        const fix = step.fix;
        const label = fix.kind === "pull" ? t("setup.pull", { model: fix.model }) : fix.kind === "use" ? t("setup.useModel", { model: fix.model }) : fix.kind === "index" ? t("setup.buildIndex") : t("setup.openSettings");
        const btn = row.createEl("button", { text: label, cls: step.state === "missing" ? "mod-cta" : "" });
        btn.addEventListener("click", () => void this.runFix(fix, btn, detail));
      }
    }
    if (setupComplete(steps)) this.listEl.createDiv({ cls: "lva-setup-done", text: t("setup.done") });
  }
  async runFix(fix, btn, detail) {
    if (this.busy) return;
    this.busy = true;
    btn.disabled = true;
    try {
      if (fix.kind === "pull") {
        await this.actions.pull(fix.model, (f, status) => detail.setText(t("setup.pulling", { model: fix.model, pct: formatProgress(f, status) })));
        await this.actions.use(fix.model, fix.role);
      } else if (fix.kind === "use") await this.actions.use(fix.model, fix.role);
      else if (fix.kind === "index") await this.actions.buildIndex();
      else {
        this.actions.openSettings();
        this.close();
        return;
      }
    } catch (err) {
      new import_obsidian6.Notice(err.message, 1e4);
    } finally {
      this.busy = false;
    }
    await this.render();
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/sample.ts
var SAMPLE_FOLDER = "Local Vault Agent sample";
var SAMPLE_QUESTIONS = [
  "Why did I switch the garden lights to 18650 cells, and when?",
  "What did the professor say about the Calvin cycle, and at what time in the lecture?",
  "Who helped me with the soldering, and what did they suggest?"
];
function sampleNotes(folder = SAMPLE_FOLDER) {
  const f = folder.replace(/^\/+|\/+$/g, "");
  const p = (name) => `${f}/${name}.md`;
  const link2 = (name) => `[[${f}/${name}|${name.split("/").pop()}]]`;
  return [
    {
      path: p("Start here"),
      content: [
        "# Start here",
        "",
        "These notes are a small sample vault for trying Local Vault Agent. Ask the chat a question about them and the answer cites the notes, down to the paragraph.",
        "",
        `- ${link2("Projects/Solar garden lights")} \u2014 a weekend project with a decision in it`,
        `- ${link2("People/Priya Raman")} \u2014 who helped`,
        `- ${link2("Lectures/BIO 101 2026-02-10")} \u2014 a recorded lecture with a timestamped transcript`,
        `- ${link2("Daily/2026-03-04")} \u2014 a daily note`,
        "",
        "Delete this folder whenever you like; the agent never needs it.",
        ""
      ].join("\n")
    },
    {
      path: p("Projects/Solar garden lights"),
      content: [
        "# Solar garden lights",
        "",
        "Six path lights along the vegetable beds, each with a small panel and a battery.",
        "",
        "## Status",
        "",
        "Four lights installed, two waiting for a dry weekend.",
        "",
        "## Decisions",
        "",
        `- **2026-03-04: switched from AA NiMH to 18650 lithium cells.** The AA packs were flat by 22:00 in February; one 18650 (3000 mAh) keeps a light on all night, and the cells are reused from an old laptop battery. ${link2("People/Priya Raman")} suggested adding a protection board per cell, so each light now has a TP4056 charger with protection.`,
        "- 2026-02-20: warm white LEDs (2700 K) instead of cold white, which looked harsh next to the beds.",
        "",
        "## Parts",
        "",
        "| Part | Count |",
        "|---|---|",
        "| 6 V 1 W panel | 6 |",
        "| 18650 cell | 6 |",
        "| TP4056 with protection | 6 |",
        "",
        "Log: " + link2("Daily/2026-03-04"),
        ""
      ].join("\n")
    },
    {
      path: p("People/Priya Raman"),
      content: [
        "# Priya Raman",
        "",
        "Neighbour, electrical engineer, runs the repair caf\xE9 on the first Saturday of the month.",
        "",
        `- Helped me solder the battery holders for the ${link2("Projects/Solar garden lights")} on 2026-03-04.`,
        "- Suggested a protection board per 18650 cell: an unprotected cell left in a hot enclosure all summer is the one thing that could start a fire.",
        "- Lent me her temperature-controlled iron; give it back with a new tip.",
        ""
      ].join("\n")
    },
    {
      path: p("Daily/2026-03-04"),
      content: [
        "# 2026-03-04",
        "",
        "## Done",
        "",
        `- Soldered the battery holders with ${link2("People/Priya Raman")}; switched the lights to 18650 cells.`,
        "- Read chapter 3 of the biology reading.",
        "",
        "## Capture",
        "",
        "- Ask the hardware shop about weatherproof cable glands.",
        ""
      ].join("\n")
    },
    {
      path: p("Lectures/BIO 101 2026-02-10"),
      content: [
        "---",
        "course: BIO 101",
        "date: 2026-02-10",
        "---",
        "# BIO 101: Photosynthesis",
        "",
        "## Summary",
        "",
        "- Light reactions in the thylakoids make ATP and NADPH [3:15]",
        "- The Calvin cycle in the stroma fixes CO\u2082 with RuBisCO [12:40]",
        "- Exam: the two stages and where each happens [24:05]",
        "",
        "## Transcript",
        "",
        "**[0:05]** Good morning. Today is photosynthesis, which is really two processes glued together.",
        "",
        "**[3:15]** The light reactions happen in the thylakoid membranes. Light splits water, oxygen comes off as a by-product, and the energy ends up in ATP and NADPH.",
        "",
        "**[12:40]** The Calvin cycle runs in the stroma and does not need light directly. RuBisCO fixes carbon dioxide onto a five-carbon sugar, and it spends the ATP and NADPH from the light reactions. RuBisCO is slow and sometimes grabs oxygen instead, which is why plants make so much of it.",
        "",
        "**[24:05]** For the exam, know the two stages, where each happens, and what passes between them.",
        ""
      ].join("\n")
    }
  ];
}

// src/search.ts
var STOP2 = /* @__PURE__ */ new Set([
  "the",
  "a",
  "an",
  "and",
  "or",
  "of",
  "to",
  "in",
  "on",
  "for",
  "is",
  "are",
  "was",
  "were",
  "my",
  "me",
  "i",
  "it",
  "this",
  "that",
  "with",
  "about",
  "what",
  "which",
  "who",
  "how",
  "do",
  "does",
  "did",
  "from",
  "by",
  "at",
  "as",
  "be",
  "have",
  "has",
  "had",
  "not",
  "all",
  "any",
  "notes",
  "note"
]);
function tokenize2(text) {
  return text.toLowerCase().split(/[^\p{L}\p{N}_#-]+/u).map((t2) => t2.replace(/^[-_#]+|[-_#]+$/g, "")).filter((t2) => t2.length > 1);
}
function queryTerms(query) {
  const terms2 = tokenize2(query).filter((t2) => !STOP2.has(t2));
  return terms2.length ? Array.from(new Set(terms2)) : tokenize2(query);
}
function countOccurrences2(haystack, needle) {
  if (!needle) return 0;
  let count = 0;
  let idx = 0;
  while ((idx = haystack.indexOf(needle, idx)) >= 0) {
    count++;
    idx += needle.length;
  }
  return count;
}
function makeSnippet(content, terms2, width = 240) {
  const lower = content.toLowerCase();
  let best = -1;
  for (const t2 of terms2) {
    const i = lower.indexOf(t2);
    if (i >= 0 && (best < 0 || i < best)) best = i;
  }
  if (best < 0) best = 0;
  const start = Math.max(0, best - Math.floor(width / 3));
  const end = Math.min(content.length, start + width);
  let snippet = content.slice(start, end).replace(/\s+/g, " ").trim();
  if (start > 0) snippet = "\u2026" + snippet;
  if (end < content.length) snippet += "\u2026";
  return snippet;
}
async function keywordSearch(vault, query, limit, notes = vault.listNotes(), textOf) {
  const terms2 = queryTerms(query);
  if (terms2.length === 0) return [];
  const phrase = query.trim().toLowerCase();
  const scored = [];
  for (const note of notes) {
    const nameLower = note.basename.toLowerCase();
    const pathLower = note.path.toLowerCase();
    let score = 0;
    let content = null;
    for (const t2 of terms2) {
      if (nameLower.includes(t2)) score += 6;
      else if (pathLower.includes(t2)) score += 2;
    }
    if (phrase.length > 3 && nameLower.includes(phrase)) score += 10;
    content = textOf?.(note) ?? await vault.read(note.path);
    const lower = content.toLowerCase();
    let matchedTerms = 0;
    for (const t2 of terms2) {
      const n = countOccurrences2(lower, t2);
      if (n > 0) {
        matchedTerms++;
        score += Math.min(n, 8) * 1 + 1.5;
      }
    }
    if (phrase.length > 3 && lower.includes(phrase)) score += 8;
    if (matchedTerms === terms2.length && terms2.length > 1) score *= 1.5;
    score = score / Math.log2(8 + content.length / 2e3);
    if (score > 0) {
      scored.push({ path: note.path, score, snippet: makeSnippet(content, terms2) });
    }
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit);
}
function fuseRankings(lists, limit, k = 60) {
  const fused = /* @__PURE__ */ new Map();
  lists.forEach((list) => {
    list.forEach((hit, rank) => {
      const contribution = 1 / (k + rank + 1);
      const existing = fused.get(hit.path);
      if (existing) {
        existing.fused += contribution;
        if (!existing.snippet && hit.snippet) existing.snippet = hit.snippet;
      } else {
        fused.set(hit.path, { ...hit, fused: contribution });
      }
    });
  });
  return Array.from(fused.values()).sort((a, b) => b.fused - a.fused).slice(0, limit).map(({ fused: fused2, ...hit }) => ({ ...hit, score: Number(fused2.toFixed(5)) }));
}
function frontmatterText(frontmatter) {
  if (!frontmatter) return "";
  return Object.entries(frontmatter).filter(([k]) => k !== "position").map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(", ") : v !== null && typeof v === "object" ? JSON.stringify(v) : String(v)}`).join("\n");
}

// src/settings.ts
var SETTINGS_VERSION = 4;
var SAMPLING = { top_p: 0.9, top_k: 20, presence_penalty: 0.5 };
var DEFAULT_SETTINGS = {
  provider: "openai",
  ollamaUrl: "http://localhost:11434",
  openaiUrl: "http://127.0.0.1:18081/v1",
  openaiKey: "",
  answerLanguage: "Korean",
  interfaceLanguage: "ko",
  dnaEnginePath: "",
  dnaModelPath: "",
  setupShown: false,
  survey: "done",
  answeredTurns: 0,
  model: "DNA3.0-9B",
  embeddingModel: "nomic-embed-text",
  semanticSearch: false,
  numCtx: 8192,
  temperature: 0.2,
  // Off by default since 0.5.0: on the benchmark vault qwen3.5:9b passed as many checks without
  // thinking (92–94/96) as with it (90–91/96) in a third of the time and with fewer tool calls.
  thinking: "off",
  showThinking: true,
  maxIterations: 60,
  maxToolResultChars: 12e3,
  autoApproveEdits: false,
  autoContinue: true,
  keepAlive: "10m",
  excludedFolders: ["templates", "Templates"],
  extraSystemPrompt: "",
  conventionsNote: "AGENT.md",
  // Off by default since 0.5.3: the benchmark scored the same with gists off (114 vs 113), and the
  // pass runs the chat model once per note, which is an hour's work for a large vault on a modest GPU.
  gists: false,
  settingsVersion: SETTINGS_VERSION,
  dailyInboxHeading: "Capture",
  dailyTopicsFolder: "Topics",
  dailyMoveItems: true,
  citations: "headings",
  visionModel: "",
  conceptFolders: [...DEFAULT_CONCEPT_FOLDERS],
  quizQuestions: 5,
  quizReviewFolder: "Quiz reviews",
  nightlyDaily: false,
  nightlyTime: "02:00",
  weeklyDigest: false,
  digestDay: 0,
  digestTime: "18:00",
  digestFolder: "Digests",
  jobRuns: {}
};
function migrateSettings(data) {
  const saved = data ?? {};
  const version = typeof saved.settingsVersion === "number" ? saved.settingsVersion : 1;
  const settings = { ...DEFAULT_SETTINGS, ...saved, jobRuns: { ...saved.jobRuns ?? {} } };
  if (data && saved.setupShown === void 0) settings.setupShown = true;
  if (version < 2 && saved.temperature === 0.3) settings.temperature = DEFAULT_SETTINGS.temperature;
  if (version < 3 && saved.thinking === "auto") settings.thinking = "off";
  if (version < 4) {
    if (saved.gists === true) settings.gists = false;
    if (typeof saved.numCtx === "number" && saved.numCtx > 32768) settings.numCtx = 32768;
  }
  settings.settingsVersion = SETTINGS_VERSION;
  return settings;
}
function isExcluded(path, excluded) {
  const lower = path.toLowerCase();
  return excluded.some((f) => {
    const p = f.trim().replace(/\\/g, "/").replace(/^\/+|\/+$/g, "").toLowerCase();
    return p.length > 0 && (lower === p || lower.startsWith(p + "/"));
  });
}

// src/settings-tab.ts
var import_obsidian7 = require("obsidian");

// src/tune.ts
var MIN_NUM_CTX = 16384;
var MAX_NUM_CTX = 131072;
function genTokPerSec(m) {
  return m.genSeconds > 0 ? m.genTokens / m.genSeconds : 0;
}
function promptTokPerSec(m) {
  return m.promptSeconds > 0 ? m.promptTokens / m.promptSeconds : 0;
}
function spillFraction(m) {
  if (!m.sizeBytes || m.vramBytes === void 0) return void 0;
  return Math.max(0, Math.min(1, (m.sizeBytes - m.vramBytes) / m.sizeBytes));
}
function gb(bytes) {
  return `${(bytes / 1e9).toFixed(1)} GB`;
}
function roundCtx(n) {
  const steps = [16384, 24576, 32768, 49152, 65536, 98304, 131072];
  let best = steps[0];
  for (const s of steps) if (Math.abs(s - n) < Math.abs(best - n)) best = s;
  return best;
}
function recommend(m, installed = []) {
  const gen = genTokPerSec(m);
  const prefill = promptTokPerSec(m);
  const spill = spillFraction(m);
  const lines = [];
  const advice = { headline: "", lines };
  lines.push(`${m.model} at a ${fmtK(m.numCtx)} context: writes ${gen.toFixed(0)} tokens/s, reads ${prefill.toFixed(0)} tokens/s${m.loadSeconds > 1 ? `, took ${m.loadSeconds.toFixed(1)} s to load` : ""}.`);
  if (spill !== void 0 && m.sizeBytes) {
    lines.push(
      spill > 0.02 ? `${Math.round(spill * 100)}% of the ${gb(m.sizeBytes)} the model and its context need is in system RAM, not on the GPU.` : `All ${gb(m.sizeBytes)} the model and its context need fit on the GPU.`
    );
  }
  const coldSeconds = prefill > 0 ? m.numCtx / prefill : 0;
  const turnSeconds = gen > 0 ? 4e3 / gen : 0;
  if (coldSeconds > 0) lines.push(`A full ${fmtK(m.numCtx)} prompt takes about ${coldSeconds.toFixed(0)} s to read cold; a 40-call clean-up writes roughly 4k tokens, about ${turnSeconds.toFixed(0)} s of generation.`);
  const current2 = installed.find((i) => sameModel(i.name, m.model));
  if (current2?.capabilities && !current2.capabilities.includes("tools")) {
    advice.noTools = true;
    advice.headline = `${m.model} does not support tool calling; the agent cannot work with it.`;
  }
  const tooSlow = gen > 0 && gen < 8;
  const slow = gen > 0 && gen < 20;
  if (!advice.headline) {
    if (spill !== void 0 && spill > 0.02) {
      if (tooSlow) {
        advice.headline = "Too slow for agent turns: the model is spilling into system RAM. Use a smaller context or a smaller model.";
        advice.suggestedNumCtx = Math.max(MIN_NUM_CTX, roundCtx(m.numCtx / 2));
      } else {
        advice.headline = slow ? "Usable but slow: part of the model is in system RAM." : "Fast enough, although part of the model is in system RAM.";
        if (m.numCtx > MIN_NUM_CTX) advice.suggestedNumCtx = Math.max(MIN_NUM_CTX, roundCtx(m.numCtx / 2));
      }
      if (advice.suggestedNumCtx) lines.push(`A ${fmtK(advice.suggestedNumCtx)} context needs less memory and may fit on the GPU entirely; test again after changing it.`);
    } else if (spill !== void 0) {
      if (gen >= 30 && m.numCtx < MAX_NUM_CTX) {
        advice.headline = "Fully on the GPU with speed to spare: a larger context would let the agent read more per turn.";
        advice.suggestedNumCtx = Math.min(MAX_NUM_CTX, roundCtx(m.numCtx * 2));
        lines.push(`Try ${fmtK(advice.suggestedNumCtx)}; if the next test shows memory spilling into RAM or a big slowdown, come back to ${fmtK(m.numCtx)}.`);
      } else if (tooSlow) {
        advice.headline = "Fully on the GPU but slow; a smaller model would make the agent far more responsive.";
      } else {
        advice.headline = "Fully on the GPU at a good speed. Nothing to change.";
      }
    } else {
      advice.headline = tooSlow ? "Slow: under 8 tokens/s makes multi-step tasks painful." : slow ? "Usable." : "Fast enough for agent turns.";
    }
  }
  const toolModels = installed.filter((i) => !i.capabilities || i.capabilities.includes("tools")).filter((i) => !/embed/i.test(i.name));
  if (tooSlow || advice.noTools) {
    const smaller = toolModels.filter((i) => !current2 || i.size < current2.size).sort((a, b) => b.size - a.size);
    const pick = advice.noTools ? toolModels.sort((a, b) => b.size - a.size)[0] : smaller[0];
    if (pick && pick.name !== m.model) {
      advice.suggestedModel = pick.name;
      lines.push(`${pick.name} (${gb(pick.size)} on disk) is installed and supports tools; it should be noticeably faster.`);
    }
  }
  if (toolModels.length) {
    lines.push(`Installed models that can call tools: ${toolModels.slice().sort((a, b) => a.size - b.size).map((i) => `${i.name} (${gb(i.size)})${sameModel(i.name, m.model) ? " \u2190 current" : ""}`).join(", ")}.`);
  }
  return advice;
}
function fmtK(n) {
  return n >= 1024 ? `${Math.round(n / 1024)}k` : String(n);
}
function benchmarkPrompt(nonce) {
  const sentence = "The quick brown fox jumps over the lazy dog while the cat watches from the warm windowsill. ";
  return `Run ${nonce}. Read the text below, then answer with the single word OK.

${sentence.repeat(110)}`;
}
async function measure(client, model, numCtx, keepAlive = "10m", signal) {
  const res = await client.chat({
    model,
    messages: [{ role: "user", content: benchmarkPrompt(String(Date.now())) }],
    think: false,
    options: { num_ctx: numCtx, temperature: 0, num_predict: 48 },
    keep_alive: keepAlive,
    signal
  }).catch(async (err) => {
    if (/think/i.test(err.message)) {
      return client.chat({ model, messages: [{ role: "user", content: benchmarkPrompt(String(Date.now())) }], options: { num_ctx: numCtx, temperature: 0, num_predict: 48 }, keep_alive: keepAlive, signal });
    }
    throw err;
  });
  const m = {
    model,
    numCtx,
    promptTokens: res.promptTokens ?? 0,
    promptSeconds: (res.promptEvalDuration ?? 0) / 1e9,
    genTokens: res.completionTokens ?? 0,
    genSeconds: (res.evalDuration ?? 0) / 1e9,
    loadSeconds: (res.loadDuration ?? 0) / 1e9
  };
  try {
    const running = (await client.ps()).find((r) => sameModel(r.name, model));
    if (running) {
      m.sizeBytes = running.size;
      m.vramBytes = running.sizeVram;
    }
  } catch {
  }
  return m;
}

// src/settings-tab.ts
var LocalVaultAgentSettingTab = class extends import_obsidian7.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  getSettingDefinitions() {
    return this.groups().map((g) => ({
      type: "group",
      heading: g.heading,
      items: [
        ...g.about ? [{ name: g.heading, desc: g.about, render: () => {
        } }] : [],
        ...g.rows.map((r) => ({
          name: r.name,
          desc: r.desc,
          aliases: r.aliases,
          visible: r.visible,
          // A block body on purpose: Obsidian keeps whatever `render` returns as the row's cleanup
          // function, and most rows return their Setting, which is not callable.
          render: (setting) => {
            r.render(setting);
          }
        }))
      ]
    }));
  }
  /** Pre-1.13 Obsidian: the same rows, rendered by hand. */
  display() {
    const { containerEl } = this;
    containerEl.empty();
    for (const g of this.groups()) {
      new import_obsidian7.Setting(containerEl).setName(g.heading).setHeading();
      if (g.about) containerEl.createEl("p", { cls: "setting-item-description", text: g.about });
      for (const r of g.rows) {
        if (r.visible && !r.visible()) continue;
        const s = new import_obsidian7.Setting(containerEl).setName(r.name);
        if (r.desc) s.setDesc(r.desc);
        r.render(s);
      }
    }
  }
  /** Re-renders after a change that alters which rows exist or what they say. */
  refresh() {
    if ((0, import_obsidian7.requireApiVersion)("1.13.0")) {
      this.update();
      this.refreshDomState();
    } else this.display();
  }
  row(key, render, extra = {}) {
    const nameKey = `${key}.name`;
    const descKey = `${key}.desc`;
    return { name: hasKey(nameKey) ? t(nameKey) : key, desc: hasKey(descKey) ? t(descKey) : void 0, render, ...extra };
  }
  groups() {
    const p = this.plugin;
    const s = p.settings;
    const save = () => p.saveSettings();
    const isOllama = () => p.settings.provider === "ollama";
    return [
      {
        heading: t("set.h.server"),
        rows: [
          this.row("set.ui", (st) => st.addDropdown((d) => d.addOptions({ ko: "\uD55C\uAD6D\uC5B4", en: "English" }).setValue(s.interfaceLanguage).onChange(async (v) => {
            s.interfaceLanguage = v === "en" ? "en" : "ko";
            await save();
          }))),
          this.row(
            "set.provider",
            (st) => {
              st.settingEl.addClass("lva-path-setting");
              st.addDropdown(
                (d) => d.addOptions({ ollama: t("set.provider.ollama"), openai: t("set.provider.openai") }).setValue(s.provider).onChange(async (v) => {
                  s.provider = v;
                  await save();
                  void p.refreshVision();
                  this.refresh();
                })
              );
              if (!isOllama()) st.addText((box) => {
                box.inputEl.addClass("lva-path-input");
                box.setPlaceholder(ui("Engine path (default if empty)", "\uC5D4\uC9C4 \uACBD\uB85C \uC9C1\uC811 \uC9C0\uC815 (\uBBF8\uC9C0\uC815 \uC2DC \uAE30\uBCF8 \uACBD\uB85C)")).setValue(s.dnaEnginePath).onChange(async (value) => {
                  s.dnaEnginePath = value.trim();
                  await save();
                });
                box.inputEl.setAttribute("aria-label", ui("Engine path (default if empty)", "\uC5D4\uC9C4 \uACBD\uB85C \uC9C1\uC811 \uC9C0\uC815 (\uBBF8\uC9C0\uC815 \uC2DC \uAE30\uBCF8 \uACBD\uB85C)"));
                box.inputEl.title = ui("Empty uses engine/llama-server.exe in the plugin folder.", "\uBE44\uC6CC \uB450\uBA74 \uD50C\uB7EC\uADF8\uC778 \uD3F4\uB354\uC758 engine/llama-server.exe\uB97C \uC0AC\uC6A9\uD569\uB2C8\uB2E4.");
              });
            },
            { aliases: ["LM Studio", "llama.cpp", "Jan", "vLLM", "OpenAI"] }
          ),
          this.row(
            "set.url",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(DEFAULT_SETTINGS.ollamaUrl).setValue(s.ollamaUrl).onChange(async (v) => {
                s.ollamaUrl = v.trim() || DEFAULT_SETTINGS.ollamaUrl;
                await save();
              })
            ).addButton((b) => b.setButtonText(t("set.test.button")).onClick(() => void this.testConnection())),
            { visible: isOllama }
          ),
          this.row(
            "set.oaUrl",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(DEFAULT_SETTINGS.openaiUrl).setValue(s.openaiUrl).onChange(async (v) => {
                s.openaiUrl = v.trim() || DEFAULT_SETTINGS.openaiUrl;
                await save();
              })
            ).addButton((b) => b.setButtonText(t("set.test.button")).onClick(() => void this.testConnection())),
            { visible: () => !isOllama() }
          ),
          this.row(
            "set.oaKey",
            (st) => st.addText((tx) => {
              tx.inputEl.type = "password";
              tx.setValue(s.openaiKey).onChange(async (v) => {
                s.openaiKey = v.trim();
                await save();
              });
            }),
            { visible: () => !isOllama() }
          ),
          {
            name: t("set.lc.name"),
            // Only for Ollama: the copy writes an Ollama URL and model tag, which an OpenAI-compatible
            // server would not know.
            visible: () => isOllama() && p.lectureCompanion() !== null,
            render: (st) => {
              const lc = p.lectureCompanion();
              if (lc) st.setDesc(t("set.lc.desc", { url: lc.ollama().url, model: lc.ollama().model }));
              st.addButton(
                (b) => b.setButtonText(t("set.lc.name")).onClick(async () => {
                  await p.useLectureCompanionOllama();
                  new import_obsidian7.Notice(`${p.settings.ollamaUrl} \xB7 ${p.settings.model}`);
                  void p.refreshVision();
                  this.refresh();
                })
              );
            }
          },
          this.row("set.model", (st) => {
            st.settingEl.addClass("lva-path-setting");
            if (!isOllama()) st.addText((box) => {
              box.inputEl.addClass("lva-path-input");
              box.setPlaceholder(ui("Model path (default if empty)", "\uBAA8\uB378 \uACBD\uB85C \uC9C1\uC811 \uC9C0\uC815 (\uBBF8\uC9C0\uC815 \uC2DC \uAE30\uBCF8 \uACBD\uB85C)")).setValue(s.dnaModelPath).onChange(async (value) => {
                s.dnaModelPath = value.trim();
                if (s.dnaModelPath) {
                  s.model = s.dnaModelPath.split(/[\\/]/).pop()?.replace(/\.gguf$/i, "") || s.model;
                }
                await save();
              });
              box.inputEl.setAttribute("aria-label", ui("Model path (default if empty)", "\uBAA8\uB378 \uACBD\uB85C \uC9C1\uC811 \uC9C0\uC815 (\uBBF8\uC9C0\uC815 \uC2DC \uAE30\uBCF8 \uACBD\uB85C)"));
              box.inputEl.title = ui("Empty uses models/DNA3.0-9B.Q4_K_M.gguf in the plugin folder.", "\uBE44\uC6CC \uB450\uBA74 \uD50C\uB7EC\uADF8\uC778 \uD3F4\uB354\uC758 models/DNA3.0-9B.Q4_K_M.gguf\uB97C \uC0AC\uC6A9\uD569\uB2C8\uB2E4.");
            });
            st.addDropdown(async (d) => {
              d.addOption(s.model, s.model);
              d.setValue(s.model);
              try {
                const models = await p.client.listModels();
                d.selectEl.empty();
                const names = models.filter((m) => !/embed/i.test(m.name)).map((m) => m.name);
                if (!names.some((n) => sameModel(n, s.model))) names.unshift(s.model);
                for (const n of names) d.addOption(n, n);
                d.setValue(s.model);
              } catch {
              }
              d.onChange(async (v) => {
                s.model = v;
                await save();
                void p.refreshVision();
              });
            });
            st.addText(
              (tx) => tx.setPlaceholder(t("set.model.placeholder")).onChange(async (v) => {
                if (!v.trim()) return;
                s.model = v.trim();
                await save();
              })
            );
          }),
          this.row(
            "set.ctx",
            (st) => st.addText(
              (tx) => tx.setValue(String(s.numCtx)).onChange(async (v) => {
                const n = parseInt(v, 10);
                if (Number.isFinite(n) && n >= 2048 && n <= 262144) {
                  s.numCtx = n;
                  await save();
                }
              })
            )
          ),
          this.row(
            "set.temp",
            (st) => st.addSlider(
              (sl) => sl.setLimits(0, 1, 0.05).setValue(s.temperature).onChange(async (v) => {
                s.temperature = v;
                await save();
              })
            )
          ),
          this.row(
            "set.think",
            (st) => st.addDropdown(
              (d) => d.addOptions({ auto: t("set.think.auto"), on: t("set.think.on"), off: t("set.think.off") }).setValue(s.thinking).onChange(async (v) => {
                s.thinking = v;
                await save();
              })
            )
          ),
          this.row(
            "set.showThinking",
            (st) => st.addToggle(
              (tg) => tg.setValue(s.showThinking).onChange(async (v) => {
                s.showThinking = v;
                await save();
              })
            )
          ),
          this.row(
            "set.keepAlive",
            (st) => st.addText(
              (tx) => tx.setValue(s.keepAlive).onChange(async (v) => {
                s.keepAlive = v.trim() || DEFAULT_SETTINGS.keepAlive;
                await save();
              })
            ),
            { visible: isOllama }
          ),
          this.row(
            "set.vision",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(t("set.vision.placeholder")).setValue(s.visionModel).onChange(async (v) => {
                s.visionModel = v.trim();
                await save();
                void p.refreshVision();
              })
            ).addButton(
              (b) => b.setButtonText(t("set.vision.check")).onClick(async () => {
                await p.refreshVision();
                const model = await p.vision.model();
                new import_obsidian7.Notice(model ? `Images will be read with ${model}.` : "No vision model: the chat model cannot see and none is set. Install one, e.g. ollama pull qwen2.5vl:7b.", 8e3);
              })
            )
          ),
          this.row(
            "set.lang",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(t("set.lang.placeholder")).setValue(s.answerLanguage).onChange(async (v) => {
                s.answerLanguage = v.trim();
                await save();
              })
            ),
            { aliases: ["language", "translate"] }
          )
        ]
      },
      {
        heading: t("set.h.search"),
        rows: [
          this.row(
            "set.semantic",
            (st) => st.addToggle(
              (tg) => tg.setValue(s.semanticSearch).onChange(async (v) => {
                s.semanticSearch = v;
                await save();
                if (v) void p.index.syncAll();
                else p.index.cancel();
                this.refresh();
              })
            )
          ),
          this.row(
            "set.embed",
            (st) => st.addText(
              (tx) => tx.setValue(s.embeddingModel).onChange(async (v) => {
                s.embeddingModel = v.trim() || DEFAULT_SETTINGS.embeddingModel;
                await save();
              })
            ),
            { visible: () => p.settings.semanticSearch }
          ),
          {
            name: t("set.index.name"),
            visible: () => p.settings.semanticSearch,
            render: (st) => {
              const status = p.index.status();
              st.setDesc(
                status.building ? t("set.index.building", { done: status.indexedFiles, pending: status.pending }) : status.lastError ? t("set.index.error", { error: status.lastError }) : t("set.index.ready", { notes: status.indexedFiles, chunks: status.totalChunks })
              );
              st.addButton(
                (b) => b.setButtonText(t("set.index.update")).onClick(async () => {
                  await p.index.syncAll();
                  this.refresh();
                })
              ).addButton(
                (b) => b.setButtonText(t("set.index.rebuild")).onClick(async () => {
                  await p.index.syncAll(true);
                  this.refresh();
                })
              );
            }
          },
          this.row(
            "set.excluded",
            (st) => st.addTextArea(
              (tx) => tx.setValue(s.excludedFolders.join("\n")).onChange(async (v) => {
                s.excludedFolders = v.split("\n").map((l) => l.trim()).filter(Boolean);
                await save();
              })
            )
          ),
          this.row(
            "set.gists",
            (st) => st.addToggle(
              (tg) => tg.setValue(s.gists).onChange(async (v) => {
                s.gists = v;
                await save();
                if (v) void p.gists.syncAll();
              })
            ).addButton(
              (b) => b.setButtonText(t("set.gists.rebuild")).onClick(() => {
                void p.gists.syncAll(true);
              })
            )
          )
        ]
      },
      {
        heading: t("set.h.agent"),
        rows: [
          this.row(
            "set.autoApprove",
            (st) => st.addToggle(
              (tg) => tg.setValue(s.autoApproveEdits).onChange(async (v) => {
                s.autoApproveEdits = v;
                await save();
              })
            )
          ),
          this.row(
            "set.autoContinue",
            (st) => st.addToggle(
              (tg) => tg.setValue(s.autoContinue).onChange(async (v) => {
                s.autoContinue = v;
                await save();
              })
            )
          ),
          this.row(
            "set.maxIter",
            (st) => st.addSlider(
              (sl) => sl.setLimits(3, 150, 1).setValue(s.maxIterations).onChange(async (v) => {
                s.maxIterations = v;
                await save();
              })
            )
          ),
          this.row(
            "set.maxChars",
            (st) => st.addText(
              (tx) => tx.setValue(String(s.maxToolResultChars)).onChange(async (v) => {
                const n = parseInt(v, 10);
                if (Number.isFinite(n) && n >= 1e3 && n <= 2e5) {
                  s.maxToolResultChars = n;
                  await save();
                }
              })
            )
          ),
          this.row(
            "set.conventions",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(DEFAULT_SETTINGS.conventionsNote).setValue(s.conventionsNote).onChange(async (v) => {
                s.conventionsNote = v.trim() || DEFAULT_SETTINGS.conventionsNote;
                await save();
              })
            ).addButton(
              (b) => b.setButtonText(t("set.conventions.button")).onClick(async () => {
                let path = p.vault.resolve(s.conventionsNote);
                if (!path) {
                  path = (0, import_obsidian7.normalizePath)(/\.md$/i.test(s.conventionsNote) ? s.conventionsNote : `${s.conventionsNote}.md`);
                  await p.vault.create(path, conventionsTemplate());
                  new import_obsidian7.Notice(`Created ${path}. Edit it like any note.`);
                }
                await this.app.workspace.openLinkText(path, "", true);
              })
            )
          ),
          this.row(
            "set.inbox",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(DEFAULT_SETTINGS.dailyInboxHeading).setValue(s.dailyInboxHeading).onChange(async (v) => {
                s.dailyInboxHeading = v.trim() || DEFAULT_SETTINGS.dailyInboxHeading;
                await save();
              })
            )
          ),
          this.row(
            "set.topics",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(DEFAULT_SETTINGS.dailyTopicsFolder).setValue(s.dailyTopicsFolder).onChange(async (v) => {
                s.dailyTopicsFolder = v.trim();
                await save();
              })
            )
          ),
          this.row(
            "set.citations",
            (st) => st.addDropdown(
              (d) => d.addOptions({ blocks: t("set.citations.blocks"), headings: t("set.citations.headings"), off: t("set.citations.off") }).setValue(s.citations).onChange(async (v) => {
                s.citations = v;
                await save();
              })
            )
          ),
          this.row(
            "set.extra",
            (st) => st.addTextArea((tx) => {
              tx.setValue(s.extraSystemPrompt).onChange(async (v) => {
                s.extraSystemPrompt = v;
                await save();
              });
              tx.inputEl.rows = 5;
              tx.inputEl.addClass("lva-settings-textarea");
            })
          )
        ]
      },
      {
        heading: t("set.h.study"),
        rows: [
          this.row(
            "set.concepts",
            (st) => st.addTextArea((tx) => {
              tx.setValue(s.conceptFolders.join("\n")).onChange(async (v) => {
                s.conceptFolders = v.split("\n").map((l) => l.trim()).filter(Boolean);
                await save();
              });
              tx.inputEl.rows = 3;
            })
          ),
          this.row(
            "set.quizN",
            (st) => st.addSlider(
              (sl) => sl.setLimits(3, 15, 1).setValue(s.quizQuestions).onChange(async (v) => {
                s.quizQuestions = v;
                await save();
              })
            )
          ),
          this.row(
            "set.quizFolder",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(DEFAULT_SETTINGS.quizReviewFolder).setValue(s.quizReviewFolder).onChange(async (v) => {
                s.quizReviewFolder = v.trim();
                await save();
              })
            )
          ),
          {
            name: t("set.lcStatus.name"),
            // The static text keeps the row in settings search; `render` runs on every open and
            // says what is true now (the definitions are built once, at plugin load).
            desc: t("set.lcStatus.off"),
            render: (st) => {
              st.setDesc(p.lectureCompanion() ? t("set.lcStatus.on") : t("set.lcStatus.off"));
            }
          }
        ]
      },
      {
        heading: t("set.h.schedule"),
        about: t("set.schedule.about"),
        rows: [
          this.row(
            "set.nightly",
            (st) => st.addToggle(
              (tg) => tg.setValue(s.nightlyDaily).onChange(async (v) => {
                s.nightlyDaily = v;
                if (v) s.jobRuns.daily = Date.now();
                await save();
              })
            )
          ),
          this.row("set.nightlyTime", (st) => this.timeInput(st, () => s.nightlyTime, (v) => s.nightlyTime = v)),
          this.row(
            "set.digest",
            (st) => st.addToggle(
              (tg) => tg.setValue(s.weeklyDigest).onChange(async (v) => {
                s.weeklyDigest = v;
                if (v) s.jobRuns.digest = Date.now();
                await save();
              })
            )
          ),
          this.row(
            "set.digestDay",
            (st) => st.addDropdown(
              (d) => d.addOptions(Object.fromEntries([0, 1, 2, 3, 4, 5, 6].map((n) => [String(n), t(`day.${n}`)]))).setValue(String(s.digestDay)).onChange(async (v) => {
                s.digestDay = Number(v);
                await save();
              })
            )
          ),
          this.row("set.digestTime", (st) => this.timeInput(st, () => s.digestTime, (v) => s.digestTime = v)),
          this.row(
            "set.digestFolder",
            (st) => st.addText(
              (tx) => tx.setPlaceholder(DEFAULT_SETTINGS.digestFolder).setValue(s.digestFolder).onChange(async (v) => {
                s.digestFolder = v.trim();
                await save();
              })
            )
          ),
          {
            name: t("set.pending.name"),
            render: (st) => {
              const waiting = p.pending.size;
              st.setDesc(waiting ? t("set.pending.some", { n: waiting }) : t("set.pending.none"));
              st.addButton(
                (b) => b.setButtonText(t("set.pending.button")).setDisabled(waiting === 0).onClick(() => void p.reviewPending())
              );
            }
          }
        ]
      },
      {
        heading: t("set.h.help"),
        rows: [
          this.row("set.setup", (st) => st.addButton((b) => b.setButtonText(t("set.setup.button")).onClick(() => p.openSetup()))),
          this.row("set.sample", (st) => st.addButton((b) => b.setButtonText(t("set.sample.button")).onClick(() => void p.trySample()))),
          this.row("set.report", (st) => st.addButton((b) => b.setButtonText(t("set.report.button")).onClick(() => p.reportProblem())), { aliases: ["bug", "issue", "feedback"] })
        ]
      }
    ];
  }
  timeInput(st, get, set) {
    st.addText((tx) => {
      tx.inputEl.type = "time";
      tx.setValue(get()).onChange(async (v) => {
        if (!/^\d{1,2}:\d{2}$/.test(v)) return;
        set(v);
        await this.plugin.saveSettings();
      });
    });
  }
  /** A short generation at the configured context: connection, speed, memory split, advice. */
  async testConnection() {
    const p = this.plugin;
    const s = p.settings;
    let models;
    let connection = "";
    try {
      const version = await p.client.version();
      models = await p.client.listModels();
      const hasChat = models.some((m) => sameModel(m.name, s.model));
      const hasEmbed = models.some((m) => sameModel(m.name, s.embeddingModel));
      connection = `Connected to ${s.provider === "ollama" ? `Ollama ${version}` : version} (${models.length} models).` + (hasChat ? "" : ` Chat model "${s.model}" is not available${s.provider === "ollama" ? `: run \`ollama pull ${s.model}\`` : ""}.`) + (s.semanticSearch && !hasEmbed ? ` Embedding model "${s.embeddingModel}" is not available.` : "");
      if (!hasChat || s.provider !== "ollama") {
        new import_obsidian7.Notice(connection, 1e4);
        return;
      }
    } catch (err) {
      p.logError(`Connection test: ${err.message}`);
      new import_obsidian7.Notice(`Connection failed: ${err.message}`, 1e4);
      return;
    }
    const working = new import_obsidian7.Notice(`Measuring ${s.model} at a ${Math.round(s.numCtx / 1024)}k context\u2026 (loads the model if needed)`, 0);
    try {
      const measured = await measure(p.client, s.model, s.numCtx, s.keepAlive);
      working.hide();
      const advice = recommend(measured, models);
      const modal = new TuneModal(this.app, advice, connection);
      modal.open();
      const choice = await modal.result;
      if (!choice) return;
      if (choice.numCtx) s.numCtx = choice.numCtx;
      if (choice.model) s.model = choice.model;
      await p.saveSettings();
      this.refresh();
      new import_obsidian7.Notice(choice.numCtx ? `Context set to ${choice.numCtx}. Test again to confirm it still fits.` : `Chat model set to ${choice.model}.`);
    } catch (err) {
      working.hide();
      p.logError(`Speed test: ${err.message}`);
      new import_obsidian7.Notice(`${connection}
Speed test failed: ${err.message}`, 1e4);
    }
  }
};

// src/view.ts
var import_obsidian8 = require("obsidian");

// src/composer-suggest.ts
var ComposerSuggest = class {
  constructor(input, container, triggers) {
    this.input = input;
    this.triggers = triggers;
    this.el = container.createDiv({ cls: "lva-suggest" });
    this.el.hide();
    input.addEventListener("input", () => this.update());
    input.addEventListener("click", () => this.update());
    input.addEventListener("keydown", (e) => this.onKey(e));
    input.addEventListener("blur", () => {
      this.blurTimer = window.setTimeout(() => this.close(), 150);
    });
    input.addEventListener("focus", () => {
      if (this.blurTimer !== null) window.clearTimeout(this.blurTimer);
    });
  }
  el;
  items = [];
  selected = 0;
  active = null;
  blurTimer = null;
  get isOpen() {
    return this.active !== null;
  }
  close() {
    this.active = null;
    this.items = [];
    this.el.empty();
    this.el.hide();
  }
  update() {
    const caret = this.input.selectionStart ?? this.input.value.length;
    const before = this.input.value.slice(0, caret);
    for (const trigger of this.triggers) {
      const m = trigger.char === "/" ? /^\/(\S*)$/.exec(before) && !this.input.value.slice(caret).trim() ? /^\/(\S*)$/.exec(before) : null : /(?:^|\s)@([^\s@]*)$/.exec(before);
      if (!m) continue;
      const query = m[1];
      const start = caret - query.length - 1;
      this.items = trigger.items(query).slice(0, 8);
      if (this.items.length === 0) break;
      this.active = { trigger, start, end: caret };
      this.selected = 0;
      this.render();
      return;
    }
    this.close();
  }
  render() {
    this.el.empty();
    this.items.forEach((item, i) => {
      const row = this.el.createDiv({ cls: "lva-suggest-item" + (i === this.selected ? " is-selected" : "") });
      row.createSpan({ cls: "lva-suggest-title", text: item.title });
      if (item.detail) row.createSpan({ cls: "lva-suggest-detail", text: item.detail });
      row.addEventListener("mousedown", (e) => {
        e.preventDefault();
        this.pick(i);
      });
    });
    this.el.show();
  }
  onKey(e) {
    if (!this.active) return;
    switch (e.key) {
      case "ArrowDown":
        this.selected = (this.selected + 1) % this.items.length;
        break;
      case "ArrowUp":
        this.selected = (this.selected - 1 + this.items.length) % this.items.length;
        break;
      case "Enter":
      case "Tab":
        this.pick(this.selected);
        break;
      case "Escape":
        this.close();
        break;
      default:
        return;
    }
    e.preventDefault();
    e.stopImmediatePropagation();
    if (this.active) this.render();
  }
  pick(index) {
    const active = this.active;
    const item = this.items[index];
    if (!active || !item) return;
    const { start, end, trigger } = active;
    this.close();
    trigger.pick(item, (text) => {
      const v = this.input.value;
      this.input.value = v.slice(0, start) + text + v.slice(end);
      const caret = start + text.length;
      this.input.setSelectionRange(caret, caret);
      this.input.focus();
      this.input.dispatchEvent(new Event("input"));
    });
  }
};

// src/mentions.ts
var LINK = /\[\[([^\]|#]+)(?:[#|][^\]]*)?\]\]/g;
function findMentions(text, vault) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const m of text.matchAll(LINK)) {
    const path = vault.resolve(m[1].trim());
    if (!path || seen.has(path)) continue;
    seen.add(path);
    out.push({ raw: m[0], path });
  }
  return out;
}
async function attachMentions(text, vault, maxTotalChars) {
  const mentions = findMentions(text, vault);
  if (mentions.length === 0) return { message: text, attached: [] };
  let budget = maxTotalChars;
  const parts = [];
  const attached = [];
  for (const m of mentions) {
    if (budget <= 200) break;
    const content = await vault.read(m.path);
    const body = content.length > budget ? content.slice(0, budget) + "\n[\u2026 truncated; use read_note with an offset for the rest]" : content;
    budget -= body.length;
    parts.push(`--- Attached note: ${m.path} ---
${body}`);
    attached.push(m.path);
  }
  const message = `${text}

(The user attached the following note${attached.length === 1 ? "" : "s"} to this message. They are already read; do not read them again. If they do not fully answer the question, find the rest in the vault with search_passages or by following their wikilinks before saying it is not recorded.)

${parts.join("\n\n")}`;
  return { message, attached };
}
function matchNotes(query, notes, limit = 8) {
  const q = query.trim().toLowerCase();
  const scored = notes.map((n) => {
    const name = n.basename.toLowerCase();
    const path = n.path.toLowerCase();
    let score = 0;
    if (!q) score = 1;
    else if (name === q) score = 5;
    else if (name.startsWith(q)) score = 4;
    else if (name.split(/[\s_-]+/).some((w) => w.startsWith(q))) score = 3;
    else if (name.includes(q)) score = 2;
    else if (path.includes(q)) score = 1;
    return { n, score };
  }).filter((x) => x.score > 0).sort((a, b) => b.score - a.score || b.n.mtime - a.n.mtime);
  return scored.slice(0, limit).map((x) => x.n);
}
var SLASH_COMMANDS = [
  { id: "reformat", name: "/reformat", description: "Reformat the current note into clean markdown (diff-approved)" },
  { id: "summarize", name: "/summarize", description: "Summarize the current note in the chat" },
  { id: "edit", name: "/edit", description: "Rewrite the text selected in the open note from a one-line instruction (diff-approved)" },
  { id: "daily", name: "/daily", description: "Process my daily notes: compile inbox sections into topic notes, leave the timelines" },
  { id: "garden", name: "/garden", description: "Suggest vault improvements in the chat: broken links, full inboxes, unlinked mentions, duplicates, orphans, stubs (writes nothing)" },
  { id: "quiz", name: "/quiz", description: "Quiz me on a topic or course since a date; missed questions go to a review note (or type: quiz me on \u2026 since \u2026)" },
  { id: "concepts", name: "/concepts", description: "Suggest concept links for the open note: link the concept notes it mentions, optionally as parent/child properties" },
  { id: "history", name: "/history", description: "Change history: every approved change, with its diff and Undo" },
  { id: "review", name: "/review", description: "Review the changes scheduled jobs queued (nightly daily notes, weekly digest)" },
  { id: "undo", name: "/undo", description: "Undo the agent's last change" },
  { id: "undo-all", name: "/undo-all", description: "Undo every change from the agent's last message" },
  { id: "new", name: "/new", description: "Start a new chat" },
  { id: "gists", name: "/gists", description: "Rebuild the one-line gists of every note" },
  { id: "index", name: "/index", description: "Rebuild the semantic index" },
  { id: "help", name: "/help", description: "What the agent can do and how to use mentions and commands" }
];
function matchCommands(query) {
  const q = query.trim().replace(/^\//, "").toLowerCase();
  return SLASH_COMMANDS.filter((c) => c.id.startsWith(q) || c.id.includes(q));
}
function parseSlash(text) {
  const m = /^\/(\S+)/.exec(text.trim());
  if (!m) return null;
  return SLASH_COMMANDS.find((c) => c.id === m[1].toLowerCase()) ?? null;
}
var HELP_TEXT = [
  "**What I can do:** answer questions from your notes (with citations), compile topics into new notes, reformat, edit, move or delete notes and attachments, and clean up across many notes in one go. Every write is shown as a diff for approval and can be undone.",
  "",
  "**Mentions:** type `@` to pick a note; it is attached to your message as `[[Note]]` so I read it without a tool call.",
  "",
  "**Commands:** " + SLASH_COMMANDS.map((c) => `\`${c.name}\``).join(", "),
  "",
  "**Tips:** a conventions note (Settings \u2192 Conventions note) is given to me on every message; `Approve all in this chat` in the diff dialog lets a long clean-up run uninterrupted; the footer shows context use."
].join("\n");

// src/transcript.ts
function conversationToMarkdown(messages) {
  const out = [];
  for (const m of messages) {
    if (m.role === "user") {
      if (m.content === AUTO_CONTINUE_TEXT) out.push("_(auto-continued: the model asked for permission)_");
      else if (m.content.startsWith(GROUNDING_PREFIX)) out.push(`_(${m.content.trim()})_`);
      else out.push(`**You:** ${m.content.trim()}`);
    } else if (m.role === "assistant") {
      const parts = [];
      if (m.content.trim()) parts.push(m.content.trim());
      for (const call of m.tool_calls ?? []) {
        parts.push(`> tool: ${call.function.name} ${JSON.stringify(call.function.arguments ?? {})}`);
      }
      if (parts.length > 0) out.push(`**Agent:**
${parts.join("\n")}`);
    } else if (m.role === "tool") {
      const firstLine = m.content.split("\n").find((l) => l.trim().length > 0) ?? "";
      const summary = firstLine.length > 160 ? firstLine.slice(0, 160) + "\u2026" : firstLine;
      const more = m.content.length > firstLine.length ? ` (${m.content.length} chars)` : "";
      out.push(`> \u21B3 ${m.tool_name ?? "result"}: ${summary}${more}`);
    }
  }
  return out.join("\n\n");
}

// src/audio.ts
function downmix(channels) {
  if (channels.length === 0) return new Float32Array(0);
  if (channels.length === 1) return channels[0];
  const n = Math.min(...channels.map((c) => c.length));
  const out = new Float32Array(n);
  for (const c of channels) for (let i = 0; i < n; i++) out[i] += c[i] / channels.length;
  return out;
}
function resample(samples, fromRate, toRate = 16e3) {
  if (fromRate === toRate || samples.length === 0) return samples;
  const ratio = fromRate / toRate;
  const n = Math.floor(samples.length / ratio);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const start = i * ratio;
    if (ratio > 1) {
      const a = Math.floor(start);
      const b = Math.min(samples.length, Math.floor(start + ratio));
      let sum = 0;
      for (let j = a; j < b; j++) sum += samples[j];
      out[i] = b > a ? sum / (b - a) : samples[a];
    } else {
      const a = Math.floor(start);
      const t2 = start - a;
      out[i] = samples[a] * (1 - t2) + (samples[Math.min(a + 1, samples.length - 1)] ?? 0) * t2;
    }
  }
  return out;
}
function encodeWav(samples, rate = 16e3) {
  const buf = new ArrayBuffer(44 + samples.length * 2);
  const v = new DataView(buf);
  const str3 = (at, s) => {
    for (let i = 0; i < s.length; i++) v.setUint8(at + i, s.charCodeAt(i));
  };
  str3(0, "RIFF");
  v.setUint32(4, 36 + samples.length * 2, true);
  str3(8, "WAVE");
  str3(12, "fmt ");
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, rate, true);
  v.setUint32(28, rate * 2, true);
  v.setUint16(32, 2, true);
  v.setUint16(34, 16, true);
  str3(36, "data");
  v.setUint32(40, samples.length * 2, true);
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    v.setInt16(44 + i * 2, s < 0 ? s * 32768 : s * 32767, true);
  }
  return buf;
}
function toWav16k(channels, sampleRate) {
  return encodeWav(resample(downmix(channels), sampleRate, 16e3), 16e3);
}

// src/voice.ts
var VoiceRecorder = class {
  recorder = null;
  stream = null;
  chunks = [];
  get recording() {
    return this.recorder !== null;
  }
  async start() {
    if (this.recorder) return;
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.chunks = [];
    this.recorder = new MediaRecorder(this.stream);
    this.recorder.addEventListener("dataavailable", (e) => {
      if (e.data.size) this.chunks.push(e.data);
    });
    this.recorder.start();
  }
  /** Stops and returns the recording as WAV bytes (16 kHz, mono, 16-bit). */
  async stop() {
    const rec = this.recorder;
    if (!rec) throw new Error("Not recording.");
    const stopped = new Promise((res) => rec.addEventListener("stop", () => res(), { once: true }));
    rec.stop();
    await stopped;
    this.release();
    const data = await new Blob(this.chunks).arrayBuffer();
    this.chunks = [];
    const ctx = new AudioContext();
    try {
      const audio = await ctx.decodeAudioData(data);
      const channels = [];
      for (let i = 0; i < audio.numberOfChannels; i++) channels.push(audio.getChannelData(i));
      return toWav16k(channels, audio.sampleRate);
    } finally {
      void ctx.close();
    }
  }
  cancel() {
    try {
      this.recorder?.stop();
    } catch {
    }
    this.release();
    this.chunks = [];
  }
  release() {
    this.stream?.getTracks().forEach((t2) => t2.stop());
    this.stream = null;
    this.recorder = null;
  }
};

// src/view.ts
var VIEW_TYPE = "local-vault-agent-view";
var SUGGESTIONS = ["view.chip.written", "view.chip.compile", "view.chip.cleanup", "view.chip.reformat"];
var AgentView = class extends import_obsidian8.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
  }
  conversation = newConversation();
  messagesEl;
  inputEl;
  sendBtn;
  statusEl;
  modelSelect;
  abort = null;
  /** Turns (by their list of reported changes) that already show the partial-undo offer. */
  partialOffered = /* @__PURE__ */ new WeakSet();
  running = false;
  /** True while a mechanical /garden fix is being applied (its diffs are open). */
  gardening = false;
  /** Whether the next message gets the notes it links to attached; off for prompts that only list notes. */
  attachNext = true;
  unsubscribeStatus = null;
  unsubscribeGists = null;
  usage = null;
  suggest = null;
  /** The quiz in progress: while set, the composer's messages are answers, graded instead of sent to the agent. */
  quiz = null;
  quizSources = /* @__PURE__ */ new Map();
  quizBusy = false;
  micBtn = null;
  recorder = new VoiceRecorder();
  getViewType() {
    return VIEW_TYPE;
  }
  getDisplayText() {
    return t("view.title");
  }
  getIcon() {
    return "bot";
  }
  async onOpen() {
    const root = this.contentEl;
    root.empty();
    root.addClass("lva-root");
    const header = root.createDiv({ cls: "lva-header" });
    this.modelSelect = header.createEl("select", { cls: "dropdown lva-model-select", attr: { "aria-label": t("view.modelSelect") } });
    this.modelSelect.addEventListener("change", () => {
      this.plugin.settings.model = this.modelSelect.value;
      void this.plugin.saveSettings();
    });
    void this.populateModels();
    const newChat = header.createEl("button", { cls: "clickable-icon lva-icon-btn", attr: { "aria-label": t("view.newChat") } });
    (0, import_obsidian8.setIcon)(newChat, "plus");
    newChat.addEventListener("click", () => this.resetConversation());
    const copyChat = header.createEl("button", { cls: "clickable-icon lva-icon-btn", attr: { "aria-label": t("view.copyChat") } });
    (0, import_obsidian8.setIcon)(copyChat, "clipboard-copy");
    copyChat.addEventListener("click", () => {
      const md = conversationToMarkdown(this.conversation.messages);
      if (!md.trim()) {
        new import_obsidian8.Notice(ui("Nothing to copy yet.", "\uBCF5\uC0AC\uD560 \uB300\uD654\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4."));
        return;
      }
      void navigator.clipboard.writeText(md);
      new import_obsidian8.Notice(ui("Conversation copied as markdown.", "\uB300\uD654\uB97C Markdown\uC73C\uB85C \uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4."));
    });
    const refresh = header.createEl("button", { cls: "clickable-icon lva-icon-btn", attr: { "aria-label": t("view.refreshModels") } });
    (0, import_obsidian8.setIcon)(refresh, "refresh-cw");
    refresh.addEventListener("click", () => void this.populateModels(true));
    this.messagesEl = root.createDiv({ cls: "lva-messages", attr: { role: "log", "aria-live": "polite", "aria-label": t("view.messages") } });
    this.renderWelcome();
    void this.restoreChat();
    const composer = root.createDiv({ cls: "lva-composer" });
    this.inputEl = composer.createEl("textarea", {
      cls: "lva-input",
      attr: { placeholder: t("view.input.placeholder"), rows: "2", "aria-label": t("view.input.label") }
    });
    this.suggest = new ComposerSuggest(this.inputEl, composer, [
      {
        char: "@",
        items: (q) => matchNotes(q, this.plugin.vault.listNotes()).map((n) => ({ key: n.path, title: n.basename, detail: n.folder || "/" })),
        pick: (item, replace) => replace(`[[${item.key.replace(/\.md$/i, "")}]] `)
      },
      {
        char: "/",
        items: (q) => matchCommands(q).map((c) => ({ key: c.id, title: c.name, detail: c.description })),
        pick: (item, replace) => {
          replace("");
          void this.runSlash(item.key);
        }
      }
    ]);
    this.inputEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        void this.submit();
      }
    });
    this.inputEl.addEventListener("input", () => this.autoGrow());
    this.inputEl.addEventListener("focus", () => this.updateMic());
    this.micBtn = composer.createEl("button", { cls: "clickable-icon lva-mic", attr: { "aria-label": t("view.mic") } });
    (0, import_obsidian8.setIcon)(this.micBtn, "mic");
    this.micBtn.addEventListener("click", () => void this.toggleMic());
    this.updateMic();
    this.sendBtn = composer.createEl("button", { cls: "mod-cta lva-send" });
    this.setSendState(false);
    this.sendBtn.addEventListener("click", () => {
      if (this.running) this.stop();
      else void this.submit();
    });
    this.statusEl = root.createDiv({ cls: "lva-status" });
    if (!this.plugin.settings.setupShown) {
      this.plugin.settings.setupShown = true;
      void this.plugin.saveSettings();
      this.plugin.openSetup();
    }
    this.unsubscribeStatus = this.plugin.onIndexStatus(() => this.updateStatus());
    this.unsubscribeGists = this.plugin.onGistStatus(() => this.updateStatus());
    this.updateStatus();
  }
  async onClose() {
    this.stop();
    this.recorder.cancel();
    this.unsubscribeStatus?.();
    this.unsubscribeStatus = null;
    this.unsubscribeGists?.();
    this.unsubscribeGists = null;
  }
  /** Put text into the composer and focus it (used by commands). */
  prefill(text) {
    this.inputEl.value = text;
    this.autoGrow();
    this.inputEl.focus();
  }
  /** Send a message programmatically (used by commands). */
  async send(text, attachMentioned = true) {
    this.inputEl.value = text;
    this.attachNext = attachMentioned;
    await this.submit();
  }
  async populateModels(notify = false) {
    const current2 = this.plugin.settings.model;
    this.modelSelect.empty();
    try {
      const models = await this.plugin.client.listModels();
      const chatModels = models.filter((m) => !/embed/i.test(m.name));
      for (const m of chatModels) {
        this.modelSelect.createEl("option", { value: m.name, text: m.name });
      }
      if (!chatModels.some((m) => sameModel(m.name, current2))) {
        this.modelSelect.createEl("option", { value: current2, text: `${current2} (not installed)` });
      }
      if (notify) new import_obsidian8.Notice(`Found ${chatModels.length} chat model${chatModels.length === 1 ? "" : "s"}.`);
    } catch (err) {
      this.modelSelect.createEl("option", { value: current2, text: current2 });
      if (notify) new import_obsidian8.Notice(`Could not reach Ollama: ${err.message}`);
    }
    this.modelSelect.value = current2;
  }
  renderWelcome() {
    const el = this.messagesEl.createDiv({ cls: "lva-welcome" });
    el.createEl("p", { text: t("view.welcome") });
    el.createEl("p", { cls: "lva-welcome-hint", text: t("view.welcome.hint") });
    const list = el.createDiv({ cls: "lva-suggestions" });
    for (const key of SUGGESTIONS) {
      const s = t(key);
      const chip = list.createEl("button", { cls: "lva-chip", text: s });
      chip.addEventListener("click", () => this.prefill(s.endsWith("\u2026?") || s.endsWith("\u2026") ? s.replace(/…\??$/, "") : s));
    }
    const start = el.createDiv({ cls: "lva-suggestions lva-start" });
    const sample = start.createEl("button", { cls: "lva-chip mod-cta", text: t("view.welcome.sample") });
    sample.addEventListener("click", () => void this.plugin.trySample());
    const setup = start.createEl("button", { cls: "lva-chip", text: t("view.welcome.setup") });
    setup.addEventListener("click", () => this.plugin.openSetup());
  }
  /** Re-renders the saved conversation (if any) when the panel opens. */
  async restoreChat() {
    const messages = await this.plugin.loadChat();
    if (!messages || messages.length === 0 || this.conversation.messages.length > 0) return;
    this.conversation = { id: this.plugin.lastChatId ?? newConversation().id, messages, approveAll: false };
    this.messagesEl.querySelector(".lva-welcome")?.remove();
    await this.renderHistory(messages);
    this.scrollToBottom();
  }
  async renderHistory(messages) {
    for (let i = 0; i < messages.length; i++) {
      const m = messages[i];
      if (m.role === "user") {
        if (m.content === AUTO_CONTINUE_TEXT || m.content.startsWith(GROUNDING_PREFIX) || /^Your reply was empty/.test(m.content)) {
          this.messagesEl.createDiv({ cls: "lva-msg lva-note", text: ui("(auto-continued)", "(\uC790\uB3D9\uC73C\uB85C \uACC4\uC18D \uC9C4\uD589\uB428)") });
        } else {
          const user = this.messagesEl.createDiv({ cls: "lva-msg lva-user" });
          user.createDiv({ cls: "lva-bubble", text: m.content.split("\n\n(The user attached")[0] });
        }
      } else if (m.role === "assistant") {
        const root = this.messagesEl.createDiv({ cls: "lva-msg lva-assistant" });
        if (m.content.trim()) await this.renderMarkdown(m.content, root.createDiv({ cls: "lva-bubble lva-markdown" }));
        for (const call of m.tool_calls ?? []) {
          const candidate = messages[i + 1 + (m.tool_calls ?? []).indexOf(call)];
          const resultMsg = candidate?.role === "tool" ? candidate : void 0;
          const card = root.createEl("details", { cls: "lva-tool lva-tool-ok" });
          const summary = card.createEl("summary");
          const icon = summary.createSpan({ cls: "lva-tool-icon" });
          (0, import_obsidian8.setIcon)(icon, iconFor(call.function.name));
          summary.createSpan({ cls: "lva-tool-name", text: describeCall(call) });
          summary.createSpan({ cls: "lva-tool-args", text: resultMsg ? describeResult(call, resultMsg.content) : "" });
          const body = card.createDiv({ cls: "lva-tool-body" });
          body.createEl("pre", { cls: "lva-tool-pre", text: JSON.stringify(call.function.arguments, null, 2) });
          if (resultMsg) body.createEl("pre", { cls: "lva-tool-pre lva-tool-result", text: resultMsg.content.length > 3e3 ? resultMsg.content.slice(0, 3e3) + "\n\u2026" : resultMsg.content });
        }
      }
    }
    this.messagesEl.createDiv({ cls: "lva-msg lva-note", text: t("view.restored") });
  }
  resetConversation() {
    this.stop();
    this.quiz = null;
    this.quizSources.clear();
    void this.plugin.clearChat();
    this.conversation = newConversation();
    this.usage = null;
    this.messagesEl.empty();
    this.renderWelcome();
    this.inputEl.focus();
  }
  autoGrow() {
  }
  setSendState(running) {
    this.running = running;
    this.sendBtn.empty();
    (0, import_obsidian8.setIcon)(this.sendBtn, running ? "square" : "send-horizontal");
    this.sendBtn.setAttribute("aria-label", running ? t("view.stop") : t("view.send"));
    this.sendBtn.toggleClass("lva-stop", running);
  }
  stop() {
    this.abort?.abort();
    this.abort = null;
  }
  updateStatus(extra) {
    const s = this.plugin.index.status();
    const parts = [];
    if (extra) parts.push(extra);
    if (!s.enabled) parts.push(t("view.status.keyword"));
    else if (s.building) parts.push(t("view.status.indexing", { done: s.indexedFiles, pending: s.pending }));
    else if (s.lastError) parts.push(t("view.status.indexError", { error: s.lastError }));
    else parts.push(t("view.status.index", { notes: s.indexedFiles, chunks: s.totalChunks }));
    const g = this.plugin.gists.status();
    if (g.enabled) {
      if (g.lastError) parts.push(`Gists: ${g.lastError}`);
      else if (g.building || g.pending > 0) parts.push(`Gists ${g.done}/${g.total}\u2026`);
      else parts.push(`Gists ${g.done}/${g.total}`);
    }
    let warn = false;
    if (this.usage) {
      const used = this.usage.promptTokens + this.usage.completionTokens;
      const pct = Math.round(used / this.usage.numCtx * 100);
      warn = pct >= 85;
      parts.push(t("view.status.context", { used: fmtK2(used), total: fmtK2(this.usage.numCtx), pct }));
    }
    this.statusEl.setText(parts.join(" \xB7 "));
    this.statusEl.toggleClass("lva-ctx-warn", warn);
  }
  scrollToBottom() {
    this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
  }
  /** Runs a `/command` from the composer. */
  async runSlash(id) {
    this.suggest?.close();
    switch (id) {
      case "reformat":
        await this.plugin.reformatCurrentNote(this);
        break;
      case "summarize":
        await this.plugin.summarizeCurrentNote(this);
        break;
      case "edit":
        await this.plugin.editSelection(this);
        break;
      case "daily":
        await this.plugin.processDailyNotes(this);
        break;
      case "garden":
        await this.plugin.suggestImprovements(this);
        break;
      case "undo":
        await this.plugin.undoLast();
        break;
      case "quiz":
        await this.plugin.startQuiz(this);
        break;
      case "concepts":
        await this.plugin.suggestConceptLinks();
        break;
      case "history":
        this.plugin.showHistory();
        break;
      case "review":
        await this.plugin.reviewPending();
        break;
      case "undo-all":
        await this.plugin.undoLastTurn();
        break;
      case "new":
        this.resetConversation();
        break;
      case "gists":
        new import_obsidian8.Notice(ui("Regenerating gists in the background\u2026", "\uBC31\uADF8\uB77C\uC6B4\uB4DC\uC5D0\uC11C \uB178\uD2B8 \uD55C \uC904 \uC694\uC57D\uC744 \uB2E4\uC2DC \uB9CC\uB4DC\uB294 \uC911\u2026"));
        void this.plugin.gists.syncAll(true);
        break;
      case "index":
        new import_obsidian8.Notice(ui("Rebuilding the semantic index\u2026", "\uC758\uBBF8 \uAC80\uC0C9 \uC0C9\uC778\uC744 \uB2E4\uC2DC \uB9CC\uB4DC\uB294 \uC911\u2026"));
        void this.plugin.index.syncAll(true);
        break;
      case "help": {
        this.messagesEl.querySelector(".lva-welcome")?.remove();
        const el = this.messagesEl.createDiv({ cls: "lva-msg lva-assistant" });
        await this.renderMarkdown(HELP_TEXT, el.createDiv({ cls: "lva-bubble lva-markdown" }));
        this.scrollToBottom();
        break;
      }
      default:
        new import_obsidian8.Notice(`Unknown command /${id}. Type / to see the list.`);
    }
  }
  /** Adds a user line and an assistant reply that the plugin itself produced (no model call) to the chat and its history. */
  async appendExchange(userText, markdown) {
    this.messagesEl.querySelector(".lva-welcome")?.remove();
    const user = this.messagesEl.createDiv({ cls: "lva-msg lva-user" });
    user.createDiv({ cls: "lva-bubble", text: userText });
    const root = this.messagesEl.createDiv({ cls: "lva-msg lva-assistant" });
    await this.renderMarkdown(markdown, root.createDiv({ cls: "lva-bubble lva-markdown" }));
    this.conversation.messages.push({ role: "user", content: userText }, { role: "assistant", content: markdown });
    this.plugin.saveChat(this.conversation.messages, this.conversation.id);
    this.scrollToBottom();
    return root;
  }
  /**
   * Shows the gardener's report as an assistant message with one button per section. The report
   * joins the conversation, so "repoint the first three broken links" typed by hand works too.
   * Nothing is written to the vault until a button is used, and then each change is a diff.
   */
  async showGardenReport(markdown, fixes, report, legacyNote) {
    if (this.running || this.gardening) {
      new import_obsidian8.Notice(t("notice.wait"));
      return;
    }
    const root = await this.appendExchange("/garden", markdown);
    if (!fixes.length && !legacyNote) return;
    const row = root.createDiv({ cls: "lva-fixes" });
    for (const fix of fixes) {
      const btn = row.createEl("button", { cls: "lva-chip", text: fix.label });
      if (fix.prompt) btn.setAttribute("aria-label", "Asks the model for a proposal; this one takes a while on a slow machine.");
      btn.addEventListener("click", () => {
        if (this.running || this.gardening) return;
        btn.disabled = true;
        if (fix.prompt) void this.send(fix.prompt, false);
        else if (fix.action === "inboxes") void this.plugin.processDailyNotes(this);
        else void this.runGardenAction(fix, report);
      });
    }
    if (legacyNote) {
      const btn = row.createEl("button", { cls: "lva-chip", text: "Delete the old Vault Suggestions note" });
      btn.setAttribute("aria-label", "Earlier versions wrote this checklist note; its open checkboxes show up in task queries. Moves it to the trash.");
      btn.addEventListener("click", () => {
        btn.disabled = true;
        void this.plugin.deleteLegacySuggestions().then((done) => new import_obsidian8.Notice(done ? "Vault Suggestions moved to the trash." : "Vault Suggestions is already gone."));
      });
    }
    this.scrollToBottom();
  }
  /** A mechanical fix: the plugin plans the edits, shows each as a diff and reports. No model call. */
  async runGardenAction(fix, report) {
    this.gardening = true;
    try {
      const result = await this.plugin.applyGardenAction(fix.action, report, this.conversation.messages.length, this.conversation.id);
      if (result) await this.appendExchange(fix.label, result);
    } catch (err) {
      new import_obsidian8.Notice(err.message ?? String(err), 8e3);
    } finally {
      this.gardening = false;
    }
  }
  async submit() {
    const text = this.inputEl.value.trim();
    const attach = this.attachNext;
    this.attachNext = true;
    if (!text || this.running || this.gardening || this.quizBusy) return;
    const slash = parseSlash(text);
    if (slash) {
      this.inputEl.value = "";
      await this.runSlash(slash.id);
      return;
    }
    if (this.quiz) {
      this.inputEl.value = "";
      await this.answerQuiz(text);
      return;
    }
    if (parseQuizRequest(text, /* @__PURE__ */ new Date())) {
      this.inputEl.value = "";
      await this.startQuiz(text, this.plugin.settings.quizQuestions);
      return;
    }
    this.messagesEl.querySelector(".lva-welcome")?.remove();
    this.inputEl.value = "";
    this.autoGrow();
    const user = this.messagesEl.createDiv({ cls: "lva-msg lva-user" });
    user.createDiv({ cls: "lva-bubble", text });
    const { message, attached } = attach ? await attachMentions(text, this.plugin.vault, this.plugin.settings.maxToolResultChars * 2) : { message: text, attached: [] };
    if (attached.length) {
      user.createDiv({ cls: "lva-attached", text: `Attached: ${attached.map((p) => p.replace(/\.md$/i, "")).join(", ")}` });
    }
    this.scrollToBottom();
    this.abort = new AbortController();
    this.setSendState(true);
    this.plugin.agentBusy = true;
    const made = [];
    let turn = null;
    const started = Date.now();
    let calls = 0;
    const progress = () => this.updateStatus(t("view.status.working", { calls, secs: Math.round((Date.now() - started) / 1e3) }));
    let waitingForDna = this.plugin.usesBundledDnaServer;
    const ticker = window.setInterval(() => {
      if (!waitingForDna) progress();
    }, 1e3);
    try {
      const signal = this.abort.signal;
      if (waitingForDna) {
        this.updateStatus(ui("Connecting to the DNA server\u2026", "\uB85C\uCEEC \uBAA8\uB378 \uC11C\uBC84 \uC5F0\uACB0 \uC911\u2026"));
        await this.plugin.ensureDnaServer();
        waitingForDna = false;
        void this.populateModels();
        if (signal.aborted) return;
      }
      await this.plugin.agent.run(
        this.conversation,
        message,
        {
          onStatus: () => progress(),
          onAssistantStart: () => {
            turn = new TurnRenderer(this, this.messagesEl, this.plugin);
            this.scrollToBottom();
          },
          onThinkingDelta: (d) => {
            turn?.appendThinking(d);
            this.scrollToBottom();
          },
          onAssistantDelta: (d) => {
            turn?.appendContent(d);
            this.scrollToBottom();
          },
          onAssistantDone: (m) => {
            void turn?.finish(m);
            this.scrollToBottom();
          },
          onToolStart: (call) => {
            turn?.toolStart(call);
            this.scrollToBottom();
          },
          onToolDone: (call, result, ok) => {
            calls++;
            if (!ok) log.warn(`Tool ${call.function.name} returned an error`);
            turn?.toolDone(call, result, ok);
            this.scrollToBottom();
          },
          onChange: (change, call) => {
            made.push(change);
            turn?.attachUndo(call, change);
          },
          onUsage: (u) => {
            this.usage = u;
            progress();
          },
          onAutoContinue: (nudge) => {
            this.messagesEl.createDiv({
              cls: "lva-msg lva-note",
              text: nudge.startsWith(GROUNDING_PREFIX) ? t("view.groundingNudge") : t("view.autoContinued")
            });
            this.scrollToBottom();
          }
        },
        this.abort.signal
      );
      log.info(`Turn finished: ${calls} tool calls in ${Math.round((Date.now() - started) / 1e3)} s${this.abort?.signal.aborted ? " (stopped)" : ""}`);
      if (!this.abort?.signal.aborted && await this.plugin.countAnswer()) this.showSurvey();
    } catch (err) {
      if (!this.abort?.signal.aborted) {
        const message2 = err.message ?? String(err);
        log.error(`Chat turn failed: ${message2}`);
        const errEl = this.messagesEl.createDiv({ cls: "lva-msg lva-error", attr: { role: "alert" } });
        errEl.createDiv({ cls: "lva-bubble", text: message2 });
        const report = errEl.createEl("button", { cls: "lva-chip", text: t("view.report") });
        report.addEventListener("click", () => this.plugin.reportProblem(message2));
      }
      this.offerPartialUndo(made);
    } finally {
      window.clearInterval(ticker);
      if (this.abort?.signal.aborted) {
        this.offerPartialUndo(made);
        this.messagesEl.createDiv({ cls: "lva-msg lva-note", text: t("view.stopped") });
      }
      this.abort = null;
      this.setSendState(false);
      this.plugin.agentBusy = false;
      this.plugin.saveChat(this.conversation.messages, this.conversation.id);
      void this.plugin.checkPlacementOnce();
      this.updateStatus();
      this.scrollToBottom();
    }
  }
  /** Shows/hides the mic: it needs Lecture Companion's transcription. */
  updateMic() {
    if (!this.micBtn) return;
    this.micBtn.toggle(this.plugin.lectureCompanion() !== null);
  }
  async toggleMic() {
    const btn = this.micBtn;
    if (!btn) return;
    const lc = this.plugin.lectureCompanion();
    if (!lc) {
      new import_obsidian8.Notice("Voice input uses Lecture Companion's transcription; install and enable Lecture Companion to dictate.", 8e3);
      this.updateMic();
      return;
    }
    if (!this.recorder.recording) {
      try {
        await this.recorder.start();
      } catch (err) {
        new import_obsidian8.Notice(`Cannot use the microphone: ${err.message}`, 8e3);
        return;
      }
      btn.addClass("lva-mic-on");
      btn.setAttribute("aria-label", t("view.mic.stop"));
      return;
    }
    btn.removeClass("lva-mic-on");
    btn.addClass("lva-mic-busy");
    btn.disabled = true;
    btn.setAttribute("aria-label", t("view.mic.busy"));
    try {
      const wav = await this.recorder.stop();
      const text = (await lc.transcribe(wav)).trim();
      if (text) {
        const cur = this.inputEl.value;
        this.inputEl.value = cur && !/\s$/.test(cur) ? `${cur} ${text}` : cur + text;
        this.inputEl.focus();
      } else new import_obsidian8.Notice("Heard nothing to transcribe.");
    } catch (err) {
      new import_obsidian8.Notice(`Transcription failed: ${err.message}`, 8e3);
    } finally {
      btn.removeClass("lva-mic-busy");
      btn.disabled = false;
      btn.setAttribute("aria-label", t("view.mic"));
    }
  }
  /**
   * After a turn that failed or was stopped: the changes it had already made are complete (each was
   * one approved diff), but the task is half done, so offer to take them all back.
   */
  offerPartialUndo(made) {
    const changes = stillApplied(made);
    if (changes.length === 0 || this.partialOffered.has(made)) return;
    this.partialOffered.add(made);
    const note = this.messagesEl.createDiv({ cls: "lva-msg lva-note" });
    note.createSpan({ text: `${t("view.partial", { n: changes.length })} ` });
    const btn = note.createEl("button", { cls: "lva-chip", text: t("view.partial.undo") });
    btn.addEventListener("click", () => {
      btn.disabled = true;
      void (async () => {
        const pending = stillApplied(made);
        let done = 0;
        for (const change of pending) {
          if (change.undone) continue;
          if (!await this.plugin.revert(change)) break;
          done++;
        }
        if (pending.length > 1) new import_obsidian8.Notice(`Undid ${done} of ${pending.length} changes.`);
      })();
    });
  }
  /** The three sample questions as buttons, after "Try it on sample notes". */
  showSampleQuestions() {
    this.messagesEl.querySelector(".lva-welcome")?.remove();
    const root = this.messagesEl.createDiv({ cls: "lva-msg lva-assistant" });
    root.createDiv({ cls: "lva-bubble", text: "The sample notes are ready. Ask one of these; the answer cites the notes and links the paragraph:" });
    const row = root.createDiv({ cls: "lva-fixes" });
    for (const q of SAMPLE_QUESTIONS) {
      const chip = row.createEl("button", { cls: "lva-chip", text: q });
      chip.addEventListener("click", () => {
        if (this.running) return;
        void this.send(q);
      });
    }
    this.scrollToBottom();
  }
  /** The one-question survey, shown once after a few answers. Its buttons only open a GitHub page. */
  showSurvey() {
    const card = this.messagesEl.createDiv({ cls: "lva-msg lva-note lva-survey", attr: { role: "group", "aria-label": t("survey.question") } });
    card.createDiv({ text: t("survey.question") });
    const row = card.createDiv({ cls: "lva-fixes" });
    const answer = (label, problem = false) => {
      card.empty();
      card.createDiv({ text: label ? t("survey.thanks") : "" });
      if (problem) this.plugin.reportProblem();
      void this.plugin.finishSurvey(problem ? null : label);
    };
    row.createEl("button", { cls: "lva-chip", text: t("survey.great") }).addEventListener("click", () => answer(t("survey.great")));
    row.createEl("button", { cls: "lva-chip", text: t("survey.problems") }).addEventListener("click", () => answer(t("survey.problems"), true));
    row.createEl("button", { cls: "lva-chip", text: t("survey.notUseful") }).addEventListener("click", () => answer(t("survey.notUseful")));
    row.createEl("button", { cls: "lva-chip", text: t("survey.dismiss") }).addEventListener("click", () => answer(null));
    this.scrollToBottom();
  }
  addUser(text) {
    this.messagesEl.querySelector(".lva-welcome")?.remove();
    this.messagesEl.createDiv({ cls: "lva-msg lva-user" }).createDiv({ cls: "lva-bubble", text });
    this.scrollToBottom();
  }
  async addAssistant(markdown) {
    this.messagesEl.querySelector(".lva-welcome")?.remove();
    const root = this.messagesEl.createDiv({ cls: "lva-msg lva-assistant" });
    await this.renderMarkdown(markdown, root.createDiv({ cls: "lva-bubble lva-markdown" }));
    this.scrollToBottom();
  }
  remember(userText, markdown) {
    this.conversation.messages.push({ role: "user", content: userText }, { role: "assistant", content: markdown });
    this.plugin.saveChat(this.conversation.messages, this.conversation.id);
  }
  /**
   * Starts a quiz from "Quiz me on <topic> since <date>": picks the notes (Lecture Companion's
   * lectures of that course when it is installed, else notes named after the topic, else a search),
   * has the model write questions from them, and asks the first.
   */
  async startQuiz(text, count) {
    if (this.running || this.gardening || this.quizBusy) {
      new import_obsidian8.Notice(t("notice.wait"));
      return;
    }
    const req = parseQuizRequest(text, /* @__PURE__ */ new Date()) ?? { topic: text };
    this.addUser(text);
    this.quizBusy = true;
    this.setSendState(true);
    this.updateStatus("Writing quiz questions\u2026");
    const started = Date.now();
    try {
      const lc = this.plugin.lectureCompanion();
      let paths = selectQuizNotes(this.plugin.vault.listNotes(), req, lc?.lectures() ?? []);
      if (paths.length === 0 && req.topic) {
        const hits = await this.plugin.hybridSearch(req.topic, 10);
        const since = req.since ?? "0000-00-00";
        paths = hits.map((h) => h.path).filter((p) => {
          const n = this.plugin.vault.listNotes().find((x) => x.path === p);
          const date = /(\d{4}-\d{2}-\d{2})/.exec(p)?.[1] ?? (n ? new Date(n.mtime).toISOString().slice(0, 10) : "");
          return date >= since;
        });
      }
      if (paths.length === 0) {
        const md2 = `I found no notes${req.topic ? ` on ${req.topic}` : ""}${req.since ? ` since ${req.since}` : ""} to quiz you on. Try a course or folder name, or an earlier date.`;
        await this.addAssistant(md2);
        this.remember(text, md2);
        return;
      }
      this.quizSources.clear();
      for (const p of paths) this.quizSources.set(p, await this.plugin.vault.read(p));
      const questions = await this.plugin.quiz.questions(req.topic, Array.from(this.quizSources, ([path, content]) => ({ path, content })), count, this.abort?.signal);
      if (questions.length === 0) {
        const md2 = "The model did not write any questions I could check against your notes. Try again, or a narrower topic.";
        await this.addAssistant(md2);
        this.remember(text, md2);
        return;
      }
      this.quiz = new QuizSession(req.topic, questions, req.since);
      const from = paths.map((p) => `[[${p.replace(/\.md$/i, "")}]]`);
      const md = [
        `Quiz on ${req.topic || "your notes"}${req.since ? ` since ${req.since}` : ""}: ${questions.length} questions from ${paths.length} note${paths.length === 1 ? "" : "s"} (${from.slice(0, 6).join(", ")}${from.length > 6 ? ", \u2026" : ""}). Answer in your own words; type *skip* to pass or *stop* to end. Written in ${Math.round((Date.now() - started) / 1e3)} s.`,
        "",
        questionMarkdown(this.quiz)
      ].join("\n");
      await this.addAssistant(md);
      this.remember(text, md);
    } catch (err) {
      const message = err.message ?? String(err);
      this.messagesEl.createDiv({ cls: "lva-msg lva-error" }).createDiv({ cls: "lva-bubble", text: message });
    } finally {
      this.quizBusy = false;
      this.setSendState(false);
      this.updateStatus();
    }
  }
  /** Grades one answer against its source, shows the verdict with the citation, then the next question or the end. */
  async answerQuiz(text) {
    const quiz = this.quiz;
    const q = quiz?.current();
    if (!quiz || !q) return;
    this.addUser(text);
    if (/^(stop|quit|end( the)? quiz|cancel|done)[.!]*$/i.test(text.trim())) {
      await this.finishQuiz(text, "");
      return;
    }
    this.quizBusy = true;
    this.setSendState(true);
    this.updateStatus("Grading\u2026");
    try {
      const source = this.quizSources.get(q.source) ?? "";
      const grade = isNonAnswer(text) ? { verdict: "wrong", feedback: "Skipped." } : await this.plugin.quiz.grade(q, text, source.slice(0, 6e3));
      const result = quiz.record(text, grade.verdict, grade.feedback);
      const md = resultMarkdown(result);
      if (quiz.done()) {
        await this.finishQuiz(text, md);
        return;
      }
      const next = `${md}

${questionMarkdown(quiz)}`;
      await this.addAssistant(next);
      this.remember(text, next);
    } catch (err) {
      new import_obsidian8.Notice(`Grading failed: ${err.message}`, 8e3);
    } finally {
      this.quizBusy = false;
      this.setSendState(false);
      this.updateStatus();
    }
  }
  /** The score, and the missed questions written (after a diff) to the topic's review note. */
  async finishQuiz(userText, lastResult) {
    const quiz = this.quiz;
    this.quiz = null;
    if (!quiz) return;
    const missed = quiz.missed();
    const lines = [lastResult, lastResult ? "" : "", `**Quiz over: ${quiz.score()}.**`].filter((l, i) => l || i > 0);
    if (missed.length) {
      const path = reviewNotePath(this.plugin.settings.quizReviewFolder, quiz.topic);
      const existing = this.plugin.vault.exists(path) ? await this.plugin.vault.read(path) : null;
      const after = renderReview(existing, quiz.topic, (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), missed);
      const written = await this.plugin.writeWithApproval(
        { tool: existing === null ? "create_note" : "append_to_note", path, before: existing ?? "", after, summary: `Add ${missed.length} missed question${missed.length === 1 ? "" : "s"} to ${path}` },
        this.conversation.id ?? "plugin",
        this.conversation.messages.length
      );
      lines.push(written ? `The ${missed.length} question${missed.length === 1 ? "" : "s"} to review ${missed.length === 1 ? "is" : "are"} in [[${path.replace(/\.md$/i, "")}]].` : "The review note was not written.");
    } else if (quiz.results.length) lines.push("Nothing to review.");
    const md = lines.join("\n").trim();
    await this.addAssistant(md);
    this.remember(userText, md);
  }
  async renderMarkdown(markdown, el) {
    el.empty();
    await import_obsidian8.MarkdownRenderer.render(this.app, markdown, el, this.plugin.vault.getActiveNotePath() ?? "", this);
    el.querySelectorAll("a.internal-link").forEach((a) => {
      a.addEventListener("click", (e) => {
        e.preventDefault();
        const href = a.getAttribute("data-href") ?? a.getAttribute("href") ?? "";
        void this.app.workspace.openLinkText(href, "", e.ctrlKey || e.metaKey);
      });
    });
  }
  insertAtCursor(text) {
    const view = this.app.workspace.getActiveViewOfType(import_obsidian8.MarkdownView);
    if (!view) {
      new import_obsidian8.Notice(ui("Open a note in the editor first.", "\uD3B8\uC9D1\uAE30\uC5D0\uC11C \uB178\uD2B8\uB97C \uBA3C\uC800 \uC5EC\uC138\uC694."));
      return;
    }
    view.editor.replaceSelection(text);
    new import_obsidian8.Notice(ui("Inserted into the note.", "\uB178\uD2B8\uC5D0 \uC0BD\uC785\uD588\uC2B5\uB2C8\uB2E4."));
  }
};
var TurnRenderer = class {
  constructor(view, parent, plugin) {
    this.view = view;
    this.plugin = plugin;
    this.root = parent.createDiv({ cls: "lva-msg lva-assistant" });
    this.contentEl = this.root.createDiv({ cls: "lva-bubble lva-markdown lva-streaming" });
  }
  root;
  thinkingEl = null;
  thinkingBody = null;
  contentEl;
  content = "";
  thinking = "";
  renderTimer = null;
  toolCards = /* @__PURE__ */ new Map();
  appendThinking(delta) {
    this.thinking += delta;
    if (!this.plugin.settings.showThinking) return;
    if (!this.thinkingEl) {
      this.thinkingEl = this.root.createEl("details", { cls: "lva-thinking" });
      this.thinkingEl.open = true;
      this.thinkingEl.createEl("summary", { text: ui("Thinking\u2026", "\uCD94\uB860 \uC911\u2026") });
      this.thinkingBody = this.thinkingEl.createDiv({ cls: "lva-thinking-body" });
      this.root.insertBefore(this.thinkingEl, this.contentEl);
    }
    this.thinkingBody.setText(this.thinking);
  }
  appendContent(delta) {
    this.content += delta;
    if (this.renderTimer) return;
    this.renderTimer = window.setTimeout(() => {
      this.renderTimer = null;
      void this.view.renderMarkdown(this.content, this.contentEl);
    }, 120);
  }
  async finish(message) {
    if (this.renderTimer !== null) {
      window.clearTimeout(this.renderTimer);
      this.renderTimer = null;
    }
    if (this.thinkingEl) {
      this.thinkingEl.open = false;
      this.thinkingEl.querySelector("summary").setText(ui("Thinking (click to show)", "\uCD94\uB860 \uACFC\uC815 (\uD074\uB9AD\uD558\uC5EC \uBCF4\uAE30)"));
    }
    this.content = message.content;
    this.contentEl.removeClass("lva-streaming");
    if (this.content.trim()) {
      await this.view.renderMarkdown(this.content, this.contentEl);
      const actions = this.root.createDiv({ cls: "lva-actions" });
      const copy = actions.createEl("button", { cls: "clickable-icon lva-icon-btn", attr: { "aria-label": t("view.copy") } });
      (0, import_obsidian8.setIcon)(copy, "copy");
      copy.addEventListener("click", () => {
        void navigator.clipboard.writeText(this.content);
        new import_obsidian8.Notice(ui("Copied.", "\uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4."));
      });
      const insert = actions.createEl("button", { cls: "clickable-icon lva-icon-btn", attr: { "aria-label": t("view.insert") } });
      (0, import_obsidian8.setIcon)(insert, "file-input");
      insert.addEventListener("click", () => this.view.insertAtCursor(this.content));
    } else {
      this.contentEl.remove();
    }
  }
  toolStart(call) {
    const card = this.root.createEl("details", { cls: "lva-tool lva-tool-running" });
    const summary = card.createEl("summary");
    const icon = summary.createSpan({ cls: "lva-tool-icon" });
    (0, import_obsidian8.setIcon)(icon, iconFor(call.function.name));
    summary.createSpan({ cls: "lva-tool-name", text: describeCall(call) });
    summary.createSpan({ cls: "lva-tool-args", text: "" });
    const body = card.createDiv({ cls: "lva-tool-body" });
    body.createEl("pre", { cls: "lva-tool-pre", text: JSON.stringify(call.function.arguments, null, 2) });
    this.toolCards.set(call, card);
  }
  /** Adds an "Undo" button to the tool card whose write produced `change`. */
  attachUndo(call, change) {
    const card = this.toolCards.get(call);
    if (!card) return;
    const summary = card.querySelector("summary");
    if (!summary) return;
    const btn = summary.createEl("button", { cls: "lva-undo-btn", text: t("view.undo"), attr: { "aria-label": `${t("view.undo")}: ${change.path}` } });
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      void this.plugin.revert(change).then((done) => {
        if (done) {
          btn.disabled = true;
          btn.setText(t("view.undone"));
        }
      });
    });
  }
  toolDone(call, result, ok) {
    const card = this.toolCards.get(call);
    if (!card) return;
    card.removeClass("lva-tool-running");
    card.addClass(ok ? "lva-tool-ok" : "lva-tool-error");
    const args = card.querySelector(".lva-tool-args");
    if (args) args.setText(ok ? describeResult(call, result) : ui("failed", "\uC2E4\uD328"));
    const body = card.querySelector(".lva-tool-body");
    body.createEl("pre", {
      cls: "lva-tool-pre lva-tool-result",
      text: result.length > 3e3 ? result.slice(0, 3e3) + "\n\u2026" : result
    });
  }
};
function fmtK2(n) {
  return n >= 1e3 ? `${(n / 1e3).toFixed(n >= 1e4 ? 0 : 1)}k` : String(n);
}
function iconFor(tool) {
  switch (tool) {
    case "search_notes":
      return "search";
    case "read_note":
    case "get_active_note":
      return "file-text";
    case "list_notes":
    case "vault_overview":
      return "folder-tree";
    case "create_note":
      return "file-plus";
    default:
      return "pencil";
  }
}
function short(v, max = 48) {
  const s = typeof v === "string" ? v : v === void 0 ? "" : JSON.stringify(v);
  const noExt = s.replace(/\.md$/i, "");
  return noExt.length > max ? noExt.slice(0, max) + "\u2026" : noExt;
}
var toolLabelsKo = {
  "search_notes": "\uBB38\uC11C \uAC80\uC0C9",
  "search_passages": "\uAD00\uB828 \uBB38\uB2E8 \uAC80\uC0C9",
  "grep_vault": "\uC804\uCCB4 \uBB38\uC11C \uD0A4\uC6CC\uB4DC \uAC80\uC0C9",
  "read_note": "\uBB38\uC11C \uC77D\uAE30",
  "read_section": "\uBB38\uC11C \uC139\uC158 \uC77D\uAE30",
  "find_in_note": "\uBB38\uC11C \uB0B4 \uAC80\uC0C9",
  "list_sections": "\uBB38\uC11C \uC139\uC158 \uBAA9\uB85D",
  "list_notes": "\uBB38\uC11C \uBAA9\uB85D \uC870\uD68C",
  "list_files": "\uD30C\uC77C \uBAA9\uB85D \uC870\uD68C",
  "read_file": "\uCCA8\uBD80 \uD30C\uC77C \uC77D\uAE30",
  "create_note": "\uBB38\uC11C \uC0DD\uC131",
  "edit_note": "\uBB38\uC11C \uC218\uC815",
  "edit_notes": "\uC5EC\uB7EC \uBB38\uC11C \uC218\uC815",
  "append_to_note": "\uBB38\uC11C \uB0B4\uC6A9 \uCD94\uAC00",
  "replace_section": "\uBB38\uC11C \uC139\uC158 \uAD50\uCCB4",
  "replace_note": "\uBB38\uC11C \uB0B4\uC6A9 \uAD50\uCCB4",
  "move_note": "\uBB38\uC11C \uC774\uB3D9",
  "delete_file": "\uD30C\uC77C \uC0AD\uC81C",
  "get_active_note": "\uD604\uC7AC \uC5F4\uB9B0 \uBB38\uC11C \uC870\uD68C",
  "vault_overview": "Vault \uAD6C\uC870 \uC870\uD68C",
  "list_lectures": "\uAC15\uC758 \uBAA9\uB85D \uC870\uD68C",
  "lecture_transcript": "\uAC15\uC758 \uC790\uB9C9 \uC77D\uAE30",
  "read_image": "\uC774\uBBF8\uC9C0 \uC77D\uAE30"
};
function describeCall(call) {
  const a = call.function.arguments ?? {};
  const label = ui("", toolLabelsKo[call.function.name] ?? "");
  if (label) {
    const detail = short(a.path ?? a.query ?? a.pattern ?? a.folder);
    return detail ? `${label} \xB7 ${detail}` : label;
  }
  switch (call.function.name) {
    case "search_notes":
      return `Searched notes for \u201C${short(a.query)}\u201D`;
    case "search_passages":
      return `Searched passages for \u201C${short(a.query)}\u201D`;
    case "read_note":
      return `Read ${short(a.path)}${a.offset ? ` (from ${short(a.offset)})` : ""}`;
    case "read_section":
      return `Read ${short(a.path)} \u203A ${short(a.heading, 30)}`;
    case "find_in_note":
      return `Looked for \u201C${short(a.pattern, 30)}\u201D in ${short(a.path)}`;
    case "grep_vault":
      return `Grepped the vault for \u201C${short(a.pattern, 30)}\u201D${a.folder ? ` in ${short(a.folder)}` : ""}`;
    case "list_sections":
      return `Checked sections for ${Array.isArray(a.containing) ? a.containing.map((t2) => `\u201C${short(t2, 20)}\u201D`).join(" / ") : ""}`;
    case "list_notes":
      return `Listed notes${a.folder ? ` in ${short(a.folder)}` : ""}${a.tag ? ` tagged ${short(a.tag)}` : ""}${a.name_contains ? ` matching \u201C${short(a.name_contains)}\u201D` : ""}`;
    case "list_files":
      return `Listed attachments${a.extension ? ` (.${short(a.extension)})` : ""}${a.folder ? ` in ${short(a.folder)}` : ""}`;
    case "vault_overview":
      return "Looked at the vault overview";
    case "get_active_note":
      return "Read the open note";
    case "create_note":
      return `Created ${short(a.path)}`;
    case "edit_note":
      return `Edited ${short(a.path)}`;
    case "edit_notes": {
      const n = Array.isArray(a.edits) ? a.edits.length : 0;
      return `Applied ${n} edit${n === 1 ? "" : "s"} across notes`;
    }
    case "append_to_note":
      return `Appended to ${short(a.path)}`;
    case "replace_note":
      return `Rewrote ${short(a.path)}`;
    case "move_note":
      return `Moved ${short(a.path)} \u2192 ${short(a.new_path)}`;
    case "delete_file":
      return `Deleted ${short(a.path)}`;
    case "read_file":
      return `Read attachment ${short(a.path)}`;
    default:
      return call.function.name;
  }
}
function describeResult(call, result) {
  switch (call.function.name) {
    case "search_notes": {
      if (result.startsWith("No notes")) return "no results";
      const n = (result.match(/"path":/g) ?? []).length;
      return `${n} result${n === 1 ? "" : "s"}`;
    }
    case "search_passages": {
      const m = /^(\d+) passage/.exec(result);
      return m ? `${m[1]} passage${m[1] === "1" ? "" : "s"}` : result.startsWith("No passages") ? "no results" : "";
    }
    case "list_notes":
    case "list_files": {
      const m = /^(\d+) (note|file)/.exec(result);
      return m ? `${m[1]} ${m[2]}${m[1] === "1" ? "" : "s"}` : "none";
    }
    case "read_note":
    case "read_section":
    case "get_active_note":
    case "read_file": {
      const m = /length: (\d+) characters/.exec(result);
      return m ? `${Math.round(Number(m[1]) / 1e3)}k chars` : result.startsWith("(unchanged") ? "unchanged" : "";
    }
    case "find_in_note": {
      const m = /^(\d+) match/.exec(result);
      return m ? `${m[1]} match${m[1] === "1" ? "" : "es"}` : "no match";
    }
    case "grep_vault": {
      const m = /^(\d+) matching lines? in (\d+) note/.exec(result);
      return m ? `${m[1]} lines in ${m[2]} notes` : "no match";
    }
    case "list_sections": {
      const m = /^(\d+) sections?/.exec(result);
      return m ? `${m[1]} section${m[1] === "1" ? "" : "s"}` : "none";
    }
    default:
      return result.length > 70 ? result.slice(0, 70) + "\u2026" : result;
  }
}

// src/main.ts
var LocalVaultAgentPlugin = class extends import_obsidian9.Plugin {
  settings = { ...DEFAULT_SETTINGS };
  client;
  dnaServer = new DnaServer();
  vault;
  index;
  gists;
  agent;
  /** True while a chat turn is running; background gist generation pauses. */
  agentBusy = false;
  /** Every approved write, newest last; saved to history.json, so it survives "New chat" and restarts. */
  undo = new UndoStack();
  /** Changes scheduled jobs produced, waiting for the user's approval (pending.json). */
  pending = new PendingQueue();
  vision;
  quiz;
  /** True when a vision model can read images (read_image is offered to the model). */
  visionAvailable = false;
  /** This plugin's public API (see the README): other plugins open the chat about a note and share the Ollama settings. */
  api;
  statusBar = null;
  /** Last time the user typed or clicked in Obsidian (ms), to know they are present. */
  lastActivity = Date.now();
  jobRunning = false;
  pendingNotified = 0;
  statusListeners = /* @__PURE__ */ new Set();
  gistListeners = /* @__PURE__ */ new Set();
  get usesBundledDnaServer() {
    return import_obsidian9.Platform.isDesktop && import_obsidian9.Platform.isWin && this.settings.provider === "openai" && isDnaEndpoint(this.settings.openaiUrl);
  }
  async ensureDnaServer() {
    const adapter = this.app.vault.adapter;
    if (!(adapter instanceof import_obsidian9.FileSystemAdapter)) throw new Error("Vault filesystem is unavailable.");
    const directory = this.manifest.dir ?? `${this.app.vault.configDir}/plugins/${this.manifest.id}`;
    return this.dnaServer.ensureStarted(() => this.client.listModels(), {
      pluginDir: adapter.getFullPath(directory),
      engine: this.settings.dnaEnginePath.trim(),
      model: this.settings.dnaModelPath.trim(),
      alias: this.settings.model,
      context: Math.max(16384, this.settings.numCtx)
    });
  }
  async onload() {
    this.register(() => {
      this.dnaServer.stop();
    });
    await this.loadSettings();
    setLocale(this.settings.interfaceLanguage);
    log.info(`Local Vault Agent ${this.manifest.version} loaded (Obsidian ${import_obsidian9.apiVersion}, ${this.settings.provider})`);
    this.client = new OllamaClient(
      () => this.settings.provider === "openai" ? this.settings.openaiUrl : this.settings.ollamaUrl,
      // Streaming chat uses the client's own `fetch`; every other request goes through `requestUrl`.
      void 0,
      async (url, body) => {
        const res = await (0, import_obsidian9.requestUrl)({
          url,
          method: "POST",
          body: body || void 0,
          contentType: "application/json",
          throw: false
        });
        return { status: res.status, text: res.text };
      },
      async (url, method, body, headers) => {
        const res = await (0, import_obsidian9.requestUrl)({ url, method, body, headers, contentType: body ? "application/json" : void 0, throw: false });
        return { status: res.status, text: res.text };
      },
      // The key belongs to the OpenAI-compatible server only: an Ollama server never gets it.
      () => ({ kind: this.settings.provider, apiKey: this.settings.provider === "openai" ? this.settings.openaiKey : void 0 })
    );
    this.vault = new ObsidianVault(this.app, (p) => isExcluded(p, this.settings.excludedFolders));
    const pluginDir = this.manifest.dir ?? `${this.app.vault.configDir}/plugins/${this.manifest.id}`;
    const indexPath = `${pluginDir}/index.json`;
    const shardDir = `${pluginDir}/index-shards`;
    this.index = new SemanticIndex(
      this.client,
      this.vault,
      {
        load: async () => {
          if (!await this.app.vault.adapter.exists(indexPath)) return null;
          return JSON.parse(await this.app.vault.adapter.read(indexPath));
        },
        save: async (data) => {
          await this.app.vault.adapter.write(indexPath, JSON.stringify(data));
        },
        // The index lives in index-shards/NN.json plus the manifest in index.json: an edited note
        // rewrites one shard, and no single file has to hold every vector of a large vault.
        loadShard: async (i) => {
          const p = `${shardDir}/${String(i).padStart(2, "0")}.json`;
          if (!await this.app.vault.adapter.exists(p)) return null;
          return JSON.parse(await this.app.vault.adapter.read(p));
        },
        saveShard: async (i, files) => {
          if (!await this.app.vault.adapter.exists(shardDir)) await this.app.vault.adapter.mkdir(shardDir);
          await this.app.vault.adapter.write(`${shardDir}/${String(i).padStart(2, "0")}.json`, JSON.stringify(files));
        },
        saveManifest: async (m) => {
          await this.app.vault.adapter.write(indexPath, JSON.stringify(m));
        }
      },
      {
        getModel: () => this.settings.embeddingModel,
        isEnabled: () => this.settings.semanticSearch,
        shouldIndex: (p) => p.endsWith(".md") && !isExcluded(p, this.settings.excludedFolders),
        onStatus: (s) => this.statusListeners.forEach((l) => l(s))
      }
    );
    this.chatPath = `${pluginDir}/chat.json`;
    const gistPath = `${pluginDir}/gists.json`;
    this.gists = new GistCache(
      this.client,
      this.vault,
      {
        load: async () => {
          if (!await this.app.vault.adapter.exists(gistPath)) return null;
          return JSON.parse(await this.app.vault.adapter.read(gistPath));
        },
        save: async (data) => {
          await this.app.vault.adapter.write(gistPath, JSON.stringify(data));
        }
      },
      {
        getModel: () => this.settings.model,
        isEnabled: () => this.settings.gists,
        shouldIndex: (p) => p.endsWith(".md") && !isExcluded(p, this.settings.excludedFolders),
        isBusy: () => this.agentBusy,
        keepAlive: this.settings.keepAlive,
        onStatus: (s) => this.gistListeners.forEach((l) => l(s))
      }
    );
    const historyPath = `${pluginDir}/history.json`;
    const pendingPath = `${pluginDir}/pending.json`;
    const visionPath = `${pluginDir}/image-cache.json`;
    const readJson = async (path) => {
      try {
        if (!await this.app.vault.adapter.exists(path)) return null;
        return JSON.parse(await this.app.vault.adapter.read(path));
      } catch {
        return null;
      }
    };
    this.undo.load(await readJson(historyPath));
    this.pending.load(await readJson(pendingPath));
    let historyTimer = null;
    this.register(
      this.undo.onChange(() => {
        if (historyTimer !== null) window.clearTimeout(historyTimer);
        historyTimer = window.setTimeout(() => {
          historyTimer = null;
          void this.app.vault.adapter.write(historyPath, JSON.stringify(this.undo.toJSON()));
        }, 1e3);
      })
    );
    this.register(
      this.pending.onChange(() => {
        void this.app.vault.adapter.write(pendingPath, JSON.stringify(this.pending.toJSON()));
        this.updateStatusBar();
      })
    );
    this.vision = new ImageReader({
      client: this.client,
      getVisionModel: () => this.settings.visionModel,
      getChatModel: () => this.settings.model,
      keepAlive: () => this.settings.keepAlive,
      readBinary: async (path) => {
        const file = this.app.vault.getFileByPath((0, import_obsidian9.normalizePath)(path));
        if (!file) throw new Error(`File not found: ${path}`);
        return this.app.vault.readBinary(file);
      },
      renderPdfPage: (path, page) => this.renderPdfPage(path, page),
      load: async () => await readJson(visionPath),
      save: async (data) => {
        await this.app.vault.adapter.write(visionPath, JSON.stringify(data));
      }
    });
    this.quiz = new QuizEngine(this.client, () => ({ model: this.settings.model, numCtx: this.settings.numCtx, keepAlive: this.settings.keepAlive }));
    this.agent = new Agent({
      client: this.client,
      vault: this.vault,
      tools: ALL_TOOLS,
      search: (q, limit) => this.hybridSearch(q, limit),
      searchPassages: async (q, limit) => {
        if (!this.index.ready) return [];
        try {
          return await this.index.searchPassages(q, limit);
        } catch {
          return [];
        }
      },
      approve: (req) => {
        const modal = new ApprovalModal(this.app, req);
        modal.open();
        return modal.result;
      },
      getConfig: () => this.agentConfig(),
      configDir: this.app.vault.configDir,
      undo: this.undo,
      gist: (path) => this.settings.gists ? this.gists.get(path) : void 0,
      readAttachmentText: (path) => this.readAttachmentText(path),
      extraTools: () => this.extraTools(),
      lectures: () => this.lectureCompanion() ?? void 0,
      describeImage: () => this.visionAvailable ? (path, opts) => this.vision.describe(path, opts) : void 0,
      dailyNote: async () => {
        await this.loadDailyNoteSettings();
        return this.dailyNote();
      },
      readConventions: async () => {
        const path = this.vault.resolve(this.settings.conventionsNote);
        return path ? this.vault.read(path) : null;
      }
    });
    this.registerView(VIEW_TYPE, (leaf) => new AgentView(leaf, this));
    this.addRibbonIcon("bot", t("ribbon.open"), () => void this.activateView());
    this.addSettingTab(new LocalVaultAgentSettingTab(this.app, this));
    this.addCommand({
      id: "open-chat",
      name: t("cmd.openChat"),
      callback: () => void this.activateView()
    });
    this.addCommand({
      id: "ask-about-selection",
      name: t("cmd.askSelection"),
      editorCallback: async (editor) => {
        const sel = editor.getSelection();
        const view = await this.activateView();
        view?.prefill(sel ? `About this selected text:
"""
${sel}
"""

` : "");
      }
    });
    this.addCommand({
      id: "reformat-current-note",
      name: t("cmd.reformat"),
      checkCallback: (checking) => {
        if (!this.activeNote()) return false;
        if (!checking) void this.reformatCurrentNote();
        return true;
      }
    });
    this.addCommand({
      id: "summarize-current-note",
      name: t("cmd.summarize"),
      checkCallback: (checking) => {
        if (!this.activeNote()) return false;
        if (!checking) void this.summarizeCurrentNote();
        return true;
      }
    });
    this.addCommand({
      id: "edit-selection",
      name: t("cmd.editSelection"),
      editorCheckCallback: (checking, editor) => {
        if (!editor.getSelection().trim()) return false;
        if (!checking) void this.editSelection();
        return true;
      }
    });
    this.addCommand({
      id: "process-daily-notes",
      name: t("cmd.daily"),
      callback: () => void this.processDailyNotes()
    });
    this.addCommand({
      id: "suggest-improvements",
      name: t("cmd.garden"),
      callback: () => void this.suggestImprovements()
    });
    this.addCommand({
      id: "undo-last-change",
      name: t("cmd.undoLast"),
      checkCallback: (checking) => {
        if (!this.undo.latest()) return false;
        if (!checking) void this.undoLast();
        return true;
      }
    });
    this.addCommand({
      id: "undo-last-message",
      name: t("cmd.undoTurn"),
      checkCallback: (checking) => {
        if (!this.undo.latest()) return false;
        if (!checking) void this.undoLastTurn();
        return true;
      }
    });
    this.addCommand({
      id: "report-problem",
      name: t("cmd.report"),
      callback: () => this.reportProblem()
    });
    this.addCommand({
      id: "setup-checklist",
      name: t("cmd.setup"),
      callback: () => this.openSetup()
    });
    this.addCommand({
      id: "try-sample",
      name: t("cmd.sample"),
      callback: () => void this.trySample()
    });
    this.addCommand({
      id: "change-history",
      name: t("cmd.history"),
      callback: () => this.showHistory()
    });
    this.addCommand({
      id: "quiz-me",
      name: t("cmd.quiz"),
      callback: () => void this.startQuiz()
    });
    this.addCommand({
      id: "suggest-concept-links",
      name: t("cmd.concepts"),
      checkCallback: (checking) => {
        if (!this.activeNote()) return false;
        if (!checking) void this.suggestConceptLinks();
        return true;
      }
    });
    this.addCommand({
      id: "review-scheduled-changes",
      name: t("cmd.review"),
      checkCallback: (checking) => {
        if (this.pending.size === 0) return false;
        if (!checking) void this.reviewPending();
        return true;
      }
    });
    this.addCommand({
      id: "run-nightly-job",
      name: t("cmd.runNightly"),
      callback: () => void this.runJob("daily", true)
    });
    this.addCommand({
      id: "run-digest-job",
      name: t("cmd.runDigest"),
      callback: () => void this.runJob("digest", true)
    });
    this.addCommand({
      id: "rebuild-gists",
      name: t("cmd.gists"),
      callback: async () => {
        new import_obsidian9.Notice(ui("Regenerating gists for every note in the background\u2026", "\uBC31\uADF8\uB77C\uC6B4\uB4DC\uC5D0\uC11C \uBAA8\uB4E0 \uB178\uD2B8\uC758 \uD55C \uC904 \uC694\uC57D\uC744 \uB2E4\uC2DC \uB9CC\uB4DC\uB294 \uC911\u2026"));
        await this.gists.syncAll(true);
        const s = this.gists.status();
        new import_obsidian9.Notice(s.lastError ? `Gist error: ${s.lastError}` : `Gists ready for ${s.done} notes.`);
      }
    });
    this.addCommand({
      id: "rebuild-index",
      name: t("cmd.index"),
      callback: async () => {
        new import_obsidian9.Notice(ui("Rebuilding the semantic index\u2026", "\uC758\uBBF8 \uAC80\uC0C9 \uC0C9\uC778\uC744 \uB2E4\uC2DC \uB9CC\uB4DC\uB294 \uC911\u2026"));
        await this.index.syncAll(true);
        const s = this.index.status();
        new import_obsidian9.Notice(s.lastError ? `Index error: ${s.lastError}` : `Indexed ${s.indexedFiles} notes.`);
      }
    });
    const timers = /* @__PURE__ */ new Map();
    const changed = (file) => {
      const existing = timers.get(file.path);
      if (existing !== void 0) window.clearTimeout(existing);
      timers.set(
        file.path,
        window.setTimeout(() => {
          timers.delete(file.path);
          this.index.enqueue(file.path);
          this.gists.enqueue(file.path);
        }, 1e4)
      );
    };
    this.register(() => timers.forEach((t2) => window.clearTimeout(t2)));
    this.registerEvent(this.app.vault.on("modify", (f) => f instanceof import_obsidian9.TFile && f.extension === "md" && changed(f)));
    this.registerEvent(
      this.app.vault.on("delete", (f) => {
        if (!(f instanceof import_obsidian9.TFile)) return;
        this.index.remove(f.path);
        this.gists.remove(f.path);
      })
    );
    this.registerEvent(
      this.app.vault.on("rename", (f, old) => {
        if (!(f instanceof import_obsidian9.TFile)) return;
        this.index.rename(old, f.path);
        this.gists.rename(old, f.path);
      })
    );
    this.app.workspace.onLayoutReady(async () => {
      this.registerEvent(this.app.vault.on("create", (f) => f instanceof import_obsidian9.TFile && f.extension === "md" && changed(f)));
      await this.loadDailyNoteSettings();
      void this.checkOllamaOnce();
      await this.index.load();
      await this.gists.load();
      void (async () => {
        if (this.settings.semanticSearch) await this.index.syncAll();
        if (this.settings.gists) await this.gists.syncAll();
      })();
      void this.refreshVision();
      this.updateStatusBar();
      void this.tick();
    });
    this.api = {
      version: 1,
      openChatAbout: (path) => this.openChatAbout(path),
      // `provider` was added in 0.8.0. `url` and `model` stay Ollama's: callers from before 0.8.0 copy them into
      // their Ollama settings without looking at `provider`, so another server's model is not handed out (empty is skipped).
      ollama: () => ({ url: this.settings.ollamaUrl, model: this.settings.provider === "ollama" ? this.settings.model : "", provider: this.settings.provider })
    };
    this.statusBar = this.addStatusBarItem();
    this.statusBar.addClass("lva-pending-badge");
    this.registerDomEvent(this.statusBar, "click", () => void this.reviewPending());
    const seen = () => {
      const away = Date.now() - this.lastActivity > 5 * 6e4;
      this.lastActivity = Date.now();
      if (away) this.notifyPending();
    };
    this.registerDomEvent(activeDocument, "keydown", seen);
    this.registerDomEvent(activeDocument, "pointerdown", seen);
    this.registerInterval(window.setInterval(() => void this.tick(), 6e4));
  }
  onunload() {
    this.index.cancel();
    void this.index.flush();
    this.gists.cancel();
    void this.gists.flush();
  }
  chatPath = "";
  chatSaveTimer = null;
  /** The last conversation, so a chat survives closing the panel or restarting Obsidian. */
  async loadChat() {
    try {
      if (!this.chatPath || !await this.app.vault.adapter.exists(this.chatPath)) return null;
      const data = JSON.parse(await this.app.vault.adapter.read(this.chatPath));
      if (typeof data.id === "string") this.lastChatId = data.id;
      return Array.isArray(data.messages) ? data.messages : null;
    } catch {
      return null;
    }
  }
  /** The id of the chat restored from chat.json, so its changes stay grouped in the history. */
  lastChatId = null;
  saveChat(messages, id) {
    if (!this.chatPath) return;
    if (this.chatSaveTimer !== null) window.clearTimeout(this.chatSaveTimer);
    this.chatSaveTimer = window.setTimeout(() => {
      this.chatSaveTimer = null;
      const slim = messages.map((m) => m.thinking || m.images ? { ...m, thinking: void 0, images: void 0 } : m);
      void this.app.vault.adapter.write(this.chatPath, JSON.stringify({ id, messages: slim }));
    }, 500);
  }
  async clearChat() {
    if (!this.chatPath) return;
    try {
      if (await this.app.vault.adapter.exists(this.chatPath)) await this.app.vault.adapter.remove(this.chatPath);
    } catch {
    }
  }
  dailyFormat = "YYYY-MM-DD";
  dailyFolder = "";
  /** Reads the core Daily Notes plugin's folder/format so "today's note" means what the user's does. */
  async loadDailyNoteSettings() {
    try {
      const p = `${this.app.vault.configDir}/daily-notes.json`;
      if (!await this.app.vault.adapter.exists(p)) return;
      const cfg = JSON.parse(await this.app.vault.adapter.read(p));
      if (typeof cfg.format === "string" && cfg.format.trim()) this.dailyFormat = cfg.format.trim();
      if (typeof cfg.folder === "string") this.dailyFolder = cfg.folder.replace(/^\/+|\/+$/g, "");
    } catch {
    }
  }
  dailyNote() {
    try {
      const now = (0, import_obsidian9.moment)();
      const name = now.format(this.dailyFormat);
      const path = (0, import_obsidian9.normalizePath)(`${this.dailyFolder ? this.dailyFolder + "/" : ""}${name}.md`);
      return { path, exists: this.app.vault.getFileByPath(path) !== null };
    } catch {
      return null;
    }
  }
  ollamaChecked = false;
  /** One Notice per session when Ollama or the chosen model is not available, with the fix. */
  async checkOllamaOnce() {
    if (this.ollamaChecked) return;
    this.ollamaChecked = true;
    try {
      const models = await this.client.listModels();
      const missing = [];
      if (!models.some((m) => sameModel(m.name, this.settings.model))) missing.push(this.settings.model);
      if (this.settings.semanticSearch && !models.some((m) => sameModel(m.name, this.settings.embeddingModel))) missing.push(this.settings.embeddingModel);
      if (missing.length) {
        log.warn(`Models not installed: ${missing.join(", ")}`);
        this.notifyError(`Local Vault Agent: model${missing.length === 1 ? "" : "s"} not installed: ${missing.join(", ")}. Open the setup checklist to download ${missing.length === 1 ? "it" : "them"}, or pick another model in settings.`, { setup: true });
      }
    } catch (err) {
      log.error(`Server unreachable at load: ${err.message}`);
      this.notifyError(`Local Vault Agent cannot reach ${this.settings.provider === "ollama" ? "Ollama" : "the model server"} at ${this.client.baseUrl} (${err.message}). Start it or fix the URL in settings.`, { setup: true });
    }
  }
  placementChecked = false;
  /**
   * One Notice per session, after a turn, when the chat model is only partly on the GPU: the usual
   * reason the agent feels slow, and one the user cannot see from inside Obsidian.
   */
  async checkPlacementOnce() {
    if (this.placementChecked) return;
    try {
      const warning = placementWarning(await this.client.ps(), this.settings.model);
      if (!warning) return;
      this.placementChecked = true;
      new import_obsidian9.Notice(`Local Vault Agent: ${warning}`, 15e3);
    } catch {
    }
  }
  /** Text of a PDF (via Obsidian's bundled pdf.js) or a text-like attachment. */
  async readAttachmentText(path) {
    const file = this.app.vault.getFileByPath((0, import_obsidian9.normalizePath)(path));
    if (!file) throw new Error(`File not found: ${path}`);
    const ext = file.extension.toLowerCase();
    if (ext === "pdf") {
      const pdfjs = await (0, import_obsidian9.loadPdfJs)();
      const data = await this.app.vault.readBinary(file);
      const doc = await pdfjs.getDocument({ data }).promise;
      const pages = [];
      for (let i = 1; i <= doc.numPages; i++) {
        const page = await doc.getPage(i);
        const content = await page.getTextContent();
        const text = content.items.map((it) => it.str ?? "").join(" ").replace(/\s+/g, " ").trim();
        pages.push(`--- Page ${i} ---
${text}`);
      }
      return pages.join("\n\n");
    }
    if (["txt", "csv", "json", "html", "htm", "xml", "yaml", "yml", "log", "tsv", "org", "tex", "srt", "vtt"].includes(ext)) {
      return this.app.vault.read(file);
    }
    throw new Error(`Cannot extract text from .${ext} files.`);
  }
  activeNote() {
    const file = this.app.workspace.getActiveFile();
    return file && file.extension === "md" ? file : null;
  }
  /** Sends the reformat prompt for the open note (command and /reformat). */
  async reformatCurrentNote(view) {
    const file = this.activeNote();
    if (!file) {
      new import_obsidian9.Notice(ui("Open a markdown note first.", "\uBA3C\uC800 Markdown \uB178\uD2B8\uB97C \uC5EC\uC138\uC694."));
      return;
    }
    const content = await this.app.vault.cachedRead(file);
    const target = view ?? await this.activateView();
    await target?.send(reformatPrompt(file.path, content));
  }
  /** The markdown editor showing the active note, even when the chat panel has focus. */
  activeEditorView() {
    const direct = this.app.workspace.getActiveViewOfType(import_obsidian9.MarkdownView);
    if (direct) return direct;
    const path = this.activeNote()?.path;
    if (!path) return null;
    for (const leaf of this.app.workspace.getLeavesOfType("markdown")) {
      const view = leaf.view;
      if (view instanceof import_obsidian9.MarkdownView && view.file?.path === path) return view;
    }
    return null;
  }
  /** Asks for an instruction and has the agent rewrite the selected text (command and /edit). */
  async editSelection(view) {
    const editorView = this.activeEditorView();
    const selection = editorView?.editor.getSelection() ?? "";
    const file = editorView?.file;
    if (!file || !selection.trim()) {
      new import_obsidian9.Notice(ui("Select some text in a note first.", "\uB178\uD2B8\uC5D0\uC11C \uD14D\uC2A4\uD2B8\uB97C \uBA3C\uC800 \uC120\uD0DD\uD558\uC138\uC694."));
      return;
    }
    const modal = new InstructionModal(this.app, selection);
    modal.open();
    const instruction = await modal.result;
    if (!instruction) return;
    const target = view ?? await this.activateView();
    await target?.send(editSelectionPrompt(file.path, selection, instruction));
  }
  /** Asks for options and runs the daily-notes distillation (command and /daily). */
  async processDailyNotes(view) {
    const s = this.settings;
    const modal = new ProcessDailyModal(this.app, {
      folder: this.dailyFolder,
      heading: s.dailyInboxHeading,
      destination: s.dailyTopicsFolder,
      move: s.dailyMoveItems
    });
    modal.open();
    const opts = await modal.result;
    if (!opts) return;
    s.dailyInboxHeading = opts.heading;
    s.dailyTopicsFolder = opts.destination;
    s.dailyMoveItems = opts.move;
    await this.saveSettings();
    const target = view ?? await this.activateView();
    await target?.send(processDailyNotesPrompt(opts));
  }
  /**
   * The vault gardener: analyses the vault without a model and reports in the chat, with a
   * button per section. Nothing is written to the vault here.
   */
  async suggestImprovements(view) {
    const target = view ?? await this.activateView();
    if (!target) return;
    const hasIndex = this.settings.semanticSearch && this.index.ready;
    const conventions = this.settings.conventionsNote.trim() ? this.vault.resolve(this.settings.conventionsNote) : null;
    const report = await gardenVault(this.vault, {
      dailyFolder: this.dailyFolder,
      inboxHeading: this.settings.dailyInboxHeading,
      // The conventions note is read on every message; it needs no links to be in use.
      exclude: (p) => isExcluded(p, this.settings.excludedFolders) || p === conventions,
      noteVectors: hasIndex ? this.index.noteVectors() : void 0
    });
    await target.showGardenReport(renderGardenChat(report, { hasIndex }), gardenFixes(report), report, this.app.vault.getFileByPath(LEGACY_SUGGESTIONS_NOTE) !== null);
  }
  /**
   * Carries out one of the gardener's mechanical fixes (repoint moved links, link mentions, remove
   * identical copies) without the model: the edits are worked out from the notes as they are now,
   * each is shown as a diff and recorded for undo under `turn`, exactly like an agent edit. Returns
   * the report for the chat, or null when the action is not a mechanical one.
   */
  async applyGardenAction(action, report, turn, chat) {
    const plan = await planGardenAction(this.vault, action, report);
    if (!plan) return null;
    const applied = [];
    let approveAll = this.settings.autoApproveEdits;
    let stopped = false;
    for (const change of plan.changes) {
      if (!approveAll) {
        const modal = new ApprovalModal(this.app, { tool: change.tool, path: change.path, before: change.before, after: change.after, summary: change.summary });
        modal.open();
        const decision = await modal.result;
        if (decision === "reject") {
          stopped = true;
          break;
        }
        if (decision === "approve-all") approveAll = true;
      }
      if (change.tool === "delete_file") await this.vault.trash(change.path);
      else await this.vault.modify(change.path, change.after);
      this.undo.push({ tool: change.tool, path: change.path, before: change.before, after: change.after, time: Date.now(), turn, chat, summary: change.summary });
      applied.push(change);
    }
    return renderPlanResult(applied, plan, stopped);
  }
  /** Moves the checklist note older versions wrote to the trash (its open checkboxes show up in task queries). */
  async deleteLegacySuggestions() {
    const file = this.app.vault.getFileByPath(LEGACY_SUGGESTIONS_NOTE);
    if (!file) return false;
    await this.app.fileManager.trashFile(file);
    return true;
  }
  /** Sends the summarize prompt for the open note (command and /summarize). */
  async summarizeCurrentNote(view) {
    const file = this.activeNote();
    if (!file) {
      new import_obsidian9.Notice(ui("Open a markdown note first.", "\uBA3C\uC800 Markdown \uB178\uD2B8\uB97C \uC5EC\uC138\uC694."));
      return;
    }
    const target = view ?? await this.activateView();
    await target?.send(summarizePrompt(file.path));
  }
  async undoLast() {
    const latest = this.undo.latest();
    if (!latest) {
      new import_obsidian9.Notice(ui("Nothing to undo.", "\uC2E4\uD589 \uCDE8\uC18C\uD560 \uBCC0\uACBD\uC774 \uC5C6\uC2B5\uB2C8\uB2E4."));
      return;
    }
    await this.revert(latest);
  }
  async undoLastTurn() {
    const latest = this.undo.latest();
    if (!latest) {
      new import_obsidian9.Notice(ui("Nothing to undo.", "\uC2E4\uD589 \uCDE8\uC18C\uD560 \uBCC0\uACBD\uC774 \uC5C6\uC2B5\uB2C8\uB2E4."));
      return;
    }
    await this.revertTurn(latest.turn, latest.chat);
  }
  /**
   * Undo one recorded change. The restore is shown as a diff (current → restored) and only
   * applied when approved, exactly like the change itself was. A note edited since is restored
   * only where the change was, keeping the later edits; when they overlap it, the undo is refused.
   * The undo is itself recorded, so it can be undone in turn.
   */
  async revert(change) {
    let plan;
    try {
      plan = await planRevert(change, this.vault);
    } catch (err) {
      new import_obsidian9.Notice(err.message, 8e3);
      if (err instanceof RevertError && err.kind === "nothing") this.undo.markUndone(change.id);
      return false;
    }
    const modal = new ApprovalModal(this.app, plan);
    modal.open();
    const decision = await modal.result;
    if (decision === "reject") return false;
    try {
      await plan.apply();
    } catch (err) {
      log.error(`Undo failed for ${change.path}: ${err.message}`);
      this.notifyError(`Undo failed: ${err.message}`);
      return false;
    }
    this.undo.markUndone(change.id);
    const base = { time: Date.now(), turn: change.turn, chat: change.chat, summary: plan.summary };
    if (change.tool === "create_note") this.undo.push({ ...base, tool: "delete_file", path: change.path, before: plan.before, after: "" });
    else if (change.tool === "delete_file") {
      if (/\.md$/i.test(change.path)) this.undo.push({ ...base, tool: "create_note", path: change.path, before: "", after: change.before });
    } else if (change.tool === "move_note") this.undo.push({ ...base, tool: "move_note", path: change.before, before: change.after, after: change.before });
    else this.undo.push({ ...base, tool: "undo", path: change.path, before: plan.before, after: plan.after });
    log.info(`Undone: ${describeChange(change)}`);
    new import_obsidian9.Notice(`Undone: ${describeChange(change)}.`);
    return true;
  }
  /** Undo every change of one agent turn, newest first, stopping at the first rejection. */
  async revertTurn(turn, chat) {
    const changes = this.undo.forTurn(turn, chat);
    if (changes.length === 0) {
      new import_obsidian9.Notice(ui("Nothing to undo.", "\uC2E4\uD589 \uCDE8\uC18C\uD560 \uBCC0\uACBD\uC774 \uC5C6\uC2B5\uB2C8\uB2E4."));
      return;
    }
    let done = 0;
    for (const change of changes) {
      if (!await this.revert(change)) break;
      done++;
    }
    if (changes.length > 1) new import_obsidian9.Notice(`Undid ${done} of ${changes.length} changes.`);
  }
  /** Records an error in the log the problem report shows. */
  logError(message) {
    log.error(message);
  }
  /** A notice for something that went wrong, with a "Report" link (and "Setup checklist" when that is the likely fix). */
  notifyError(message, opts = {}) {
    const frag = createFragment();
    frag.createSpan({ text: `${message} ` });
    if (opts.setup) {
      const setup = frag.createEl("a", { text: t("cmd.setup"), href: "#" });
      setup.addEventListener("click", (e) => {
        e.preventDefault();
        this.openSetup();
      });
      frag.createSpan({ text: " \xB7 " });
    }
    const report = frag.createEl("a", { text: t("view.report"), href: "#" });
    report.addEventListener("click", (e) => {
      e.preventDefault();
      this.reportProblem(message);
    });
    new import_obsidian9.Notice(frag, 15e3);
  }
  /** Absolute vault folder and home folder, so the report can replace them by <vault> and ~. */
  reportPaths() {
    const adapter = this.app.vault.adapter;
    const vault = adapter instanceof import_obsidian9.FileSystemAdapter ? adapter.getBasePath() : void 0;
    let home;
    if (import_obsidian9.Platform.isDesktopApp) {
      const env = window.process?.env;
      home = env?.USERPROFILE || env?.HOME || void 0;
    }
    home ??= vault ? /^(?:[A-Za-z]:[\\/]Users[\\/][^\\/]+|\/(?:Users|home)\/[^/]+)/.exec(vault)?.[0] : void 0;
    return { vault, home };
  }
  /** Everything the report needs that is not secret, collected live (the model list only when the server answers). */
  async reportInfo() {
    const s = this.settings;
    let serverVersion = null;
    let installed = null;
    try {
      serverVersion = await this.client.version();
      installed = (await this.client.listModels()).map((m) => m.name);
    } catch (err) {
      log.warn(`Report: server not reachable (${err.message})`);
    }
    const idx = this.index.status();
    const plugins = this.app.plugins?.enabledPlugins;
    return {
      pluginVersion: this.manifest.version,
      obsidianVersion: import_obsidian9.apiVersion,
      platform: import_obsidian9.Platform.isWin ? "Windows" : import_obsidian9.Platform.isMacOS ? "macOS" : import_obsidian9.Platform.isLinux ? "Linux" : import_obsidian9.Platform.isAndroidApp ? "Android" : import_obsidian9.Platform.isIosApp ? "iOS" : "unknown",
      mobile: import_obsidian9.Platform.isMobile,
      provider: s.provider === "ollama" ? "Ollama" : "OpenAI-compatible",
      serverVersion,
      chatModel: s.model,
      embeddingModel: s.embeddingModel,
      visionModel: s.visionModel,
      installedModels: installed,
      notes: this.vault.listNotes().length,
      index: !s.semanticSearch ? "semantic search off" : idx.building ? `building (${idx.indexedFiles} done, ${idx.pending} pending)` : idx.lastError ? `error: ${idx.lastError}` : `${idx.indexedFiles} notes, ${idx.totalChunks} chunks`,
      otherPlugins: plugins ? Array.from(plugins).filter((id) => id !== this.manifest.id).sort() : [],
      settings: { ...s },
      log: log.tail(50)
    };
  }
  /** Opens the "Report a problem" dialog; `description` pre-fills what happened (e.g. the error message). */
  reportProblem(description = "") {
    void (async () => {
      const info = await this.reportInfo();
      const paths = this.reportPaths();
      const chat = await this.loadChat() ?? [];
      new ReportModal(this.app, (desc, includeChat) => buildReport(info, desc, { paths, chat: includeChat ? chatTranscript(chat) : void 0 }), (desc) => reportTitle(desc, log.lastError()?.message, paths), description).open();
    })();
  }
  /** The setup checklist: server, models, index, each with a fix. */
  openSetup() {
    const deviceMemory = navigator.deviceMemory;
    new SetupModal(this.app, {
      initialTier: guessTier(deviceMemory),
      configuredModel: this.settings.provider === "openai" ? this.settings.model : void 0,
      evaluate: async (tier) => {
        let models = null;
        let serverError;
        try {
          models = await this.client.listModels();
        } catch (err) {
          serverError = err.message;
          log.warn(`Setup: ${serverError}`);
        }
        return evaluateSetup({ provider: this.settings.provider, models, serverError, chatModel: this.settings.model, embeddingModel: this.settings.embeddingModel, semanticSearch: this.settings.semanticSearch, index: this.index.status(), notes: this.vault.listNotes().length, tier });
      },
      pull: async (model, onProgress) => {
        log.info(`Pulling ${model}`);
        await this.client.pull(model, onProgress);
        log.info(`Pulled ${model}`);
      },
      use: async (model, role) => {
        if (role === "chat") this.settings.model = model;
        else this.settings.embeddingModel = model;
        await this.saveSettings();
        void this.refreshVision();
        if (role === "embed" && this.settings.semanticSearch) void this.index.syncAll();
      },
      buildIndex: async () => {
        await this.index.syncAll();
      },
      openSettings: () => {
        const setting = this.app.setting;
        setting?.open();
        setting?.openTabById(this.manifest.id);
      },
      trySample: () => this.trySample()
    }).open();
  }
  /**
   * Creates the sample notes (once) and opens the chat with three questions to try. The notes are
   * the user's own request, so they are written without a diff, and recorded in the change history.
   */
  async trySample() {
    const notes = sampleNotes(SAMPLE_FOLDER);
    let created = 0;
    for (const n of notes) {
      if (this.vault.exists(n.path)) continue;
      const folder = n.path.slice(0, n.path.lastIndexOf("/"));
      if (!this.app.vault.getFolderByPath(folder)) await this.app.vault.createFolder(folder);
      await this.vault.create(n.path, n.content);
      this.undo.push({ tool: "create_note", path: n.path, before: "", after: n.content, time: Date.now(), turn: 0, chat: "plugin", summary: `Sample note ${n.path}` });
      this.index.enqueue(n.path);
      created++;
    }
    new import_obsidian9.Notice(created ? t("notice.sampleCreated", { n: created, folder: SAMPLE_FOLDER }) : t("notice.sampleExists", { folder: SAMPLE_FOLDER }));
    log.info(`Sample notes: ${created} created`);
    const view = await this.activateView();
    view?.showSampleQuestions();
  }
  /** Called after each answered message: shows the one-question survey once, after the fifth answer. */
  async countAnswer() {
    if (this.settings.survey !== "ask") return false;
    this.settings.answeredTurns++;
    const ask = this.settings.answeredTurns >= 5;
    if (ask) this.settings.survey = "done";
    await this.saveSettings();
    return ask;
  }
  /** The survey was answered or dismissed: never asked again. `answer` opens a prefilled discussion. */
  async finishSurvey(answer) {
    this.settings.survey = "done";
    await this.saveSettings();
    if (answer) window.open(surveyUrl(answer, this.manifest.version));
  }
  /** Lecture Companion's API (version 1), or null when it is not installed or enabled. */
  lectureCompanion() {
    return lectureCompanionApi(this.app);
  }
  /** Tools that depend on other plugins and models: Lecture Companion's lectures, the vision model. */
  extraTools() {
    return [...this.lectureCompanion() ? LECTURE_TOOLS : [], ...this.visionAvailable ? [readImage] : []];
  }
  /** Re-checks whether a vision model is available (after settings change and on load). */
  async refreshVision() {
    this.vision.reset();
    this.visionAvailable = await this.vision.model() !== null;
  }
  /** Copies Lecture Companion's Ollama URL and model into these settings. */
  async useLectureCompanionOllama() {
    const lc = this.lectureCompanion();
    if (!lc) return false;
    const { url, model } = lc.ollama();
    if (url) this.settings.ollamaUrl = url;
    if (model) this.settings.model = model;
    await this.saveSettings();
    return true;
  }
  /** The public API's openChatAbout: the chat with the note attached and a prompt to ask about it. */
  async openChatAbout(path) {
    const resolved = this.vault.resolve(path);
    if (!resolved) {
      new import_obsidian9.Notice(`Local Vault Agent: no note ${path}.`);
      return;
    }
    const view = await this.activateView();
    view?.prefill(`About [[${resolved.replace(/\.md$/i, "")}]]: `);
  }
  /** Shows the diff, writes on approval, records the change. Returns whether it was written. */
  async writeWithApproval(req, chat = "plugin", turn = 0) {
    if (!this.settings.autoApproveEdits) {
      const modal = new ApprovalModal(this.app, req);
      modal.open();
      if (await modal.result === "reject") return false;
    }
    const existed = this.vault.exists(req.path);
    if (existed) {
      if (await this.vault.read(req.path) !== req.before) {
        new import_obsidian9.Notice(`${req.path} changed while the diff was open; nothing written.`, 8e3);
        return false;
      }
      await this.vault.modify(req.path, req.after);
    } else {
      const folder = req.path.includes("/") ? req.path.slice(0, req.path.lastIndexOf("/")) : "";
      if (folder && !this.app.vault.getFolderByPath(folder)) await this.app.vault.createFolder(folder);
      await this.vault.create(req.path, req.after);
    }
    this.undo.push({ tool: existed ? req.tool : "create_note", path: req.path, before: existed ? req.before : "", after: req.after, time: Date.now(), turn, chat, summary: req.summary });
    return true;
  }
  showHistory() {
    new HistoryModal(
      this.app,
      () => this.undo.list(),
      (c) => this.revert(c),
      (path) => void this.app.workspace.openLinkText(path, "", false),
      (l) => this.undo.onChange(l)
    ).open();
  }
  /** "Quiz me": asks for the topic and starts the quiz in the chat. */
  async startQuiz(view) {
    const lc = this.lectureCompanion();
    const modal = new QuizModal(this.app, lc?.courses() ?? [], this.settings.quizQuestions);
    modal.open();
    const opts = await modal.result;
    if (!opts) return;
    const target = view ?? await this.activateView();
    const text = `Quiz me${opts.topic ? ` on ${opts.topic}` : ""}${opts.since ? ` since ${opts.since}` : ""}`;
    await target?.startQuiz(text, opts.count);
  }
  /** "Suggest concept links for this note": concept notes it mentions or is close to, as one diff. */
  async suggestConceptLinks() {
    const file = this.activeNote();
    if (!file) {
      new import_obsidian9.Notice(ui("Open a note first.", "\uBA3C\uC800 \uB178\uD2B8\uB97C \uC5EC\uC138\uC694."));
      return;
    }
    const content = await this.app.vault.read(file);
    const folders = this.settings.conceptFolders;
    const concepts = this.vault.listNotes().filter((n2) => n2.path !== file.path).map((n2) => ({ n: n2, meta: this.vault.getMetadata(n2.path) })).filter(({ n: n2, meta }) => isConceptNote(n2, folders, meta)).map(({ n: n2, meta }) => ({ note: n2, names: conceptNames(n2, meta.frontmatter.aliases) }));
    if (concepts.length === 0) {
      new import_obsidian9.Notice(`No concept notes found. Put them in ${folders.join(" or ") || "a concept folder"} (Settings \u2192 Concept folders), or tag them #concept.`, 1e4);
      return;
    }
    let related = [];
    if (this.settings.semanticSearch && this.index.ready) {
      const vectors = this.index.noteVectors();
      const mine = vectors.get(file.path);
      if (mine) {
        const conceptPaths = new Set(concepts.map((c) => c.note.path));
        related = Array.from(vectors).filter(([p]) => conceptPaths.has(p)).map(([p, v]) => ({ path: p, score: cosine(mine, v) })).filter((r) => r.score >= 0.6);
      }
    }
    const suggestions = suggestConcepts({ path: file.path, content }, concepts, related);
    if (suggestions.length === 0) {
      new import_obsidian9.Notice(`${file.basename} mentions none of your ${concepts.length} concept notes that it does not already link.`, 8e3);
      return;
    }
    const modal = new ConceptModal(this.app, file.path, suggestions);
    modal.open();
    const picked = await modal.result;
    if (!picked) return;
    const current2 = await this.app.vault.read(file);
    const after = applyConceptLinks(current2, picked.chosen, picked.property);
    if (after === current2) {
      new import_obsidian9.Notice(ui("Nothing to change.", "\uBCC0\uACBD\uD560 \uB0B4\uC6A9\uC774 \uC5C6\uC2B5\uB2C8\uB2E4."));
      return;
    }
    const n = picked.chosen.length;
    const ok = await this.writeWithApproval({ tool: "edit_note", path: file.path, before: current2, after, summary: `Link ${n} concept${n === 1 ? "" : "s"} in ${file.basename}` });
    if (ok) new import_obsidian9.Notice(`Linked ${n} concept${n === 1 ? "" : "s"}.`);
  }
  /** Runs due scheduled jobs (at most one at a time) and reminds a present user of waiting changes. */
  async tick() {
    if (!this.jobRunning && !this.agentBusy) {
      const due = dueJobs(/* @__PURE__ */ new Date(), this.settings, this.settings.jobRuns);
      for (const job of due) await this.runJob(job, false);
    }
    this.notifyPending();
  }
  /**
   * Runs one scheduled job against an overlay of the vault: whatever it would write is queued for
   * review, nothing is written. `manual` when the user ran it from the command palette.
   */
  async runJob(job, manual) {
    if (this.jobRunning) {
      if (manual) new import_obsidian9.Notice(ui("A scheduled job is already running.", "\uC608\uC57D \uC791\uC5C5\uC774 \uC774\uBBF8 \uC2E4\uD589 \uC911\uC785\uB2C8\uB2E4."));
      return;
    }
    this.jobRunning = true;
    this.settings.jobRuns[job] = Date.now();
    await this.saveSettings();
    if (manual) new import_obsidian9.Notice(`${JOB_NAMES[job]}: running in the background; the changes will wait for your review.`);
    try {
      const changes = job === "daily" ? await this.runDailyJob() : await this.runDigestJob();
      const added = this.pending.add(job, changes);
      if (added.length) {
        this.pendingNotified = 0;
        this.notifyPending(manual);
      } else if (manual) new import_obsidian9.Notice(`${JOB_NAMES[job]}: nothing to change.`);
    } catch (err) {
      log.error(`${JOB_NAMES[job]} failed: ${err.message}`);
      this.notifyError(`${JOB_NAMES[job]} failed: ${err.message}`);
    } finally {
      this.jobRunning = false;
    }
  }
  async runDailyJob() {
    await this.loadDailyNoteSettings();
    const overlay = new OverlayVault(this.vault);
    const since = localDate(new Date(Date.now() - 2 * 864e5));
    const agent = new Agent({
      client: this.client,
      vault: overlay,
      tools: ALL_TOOLS.filter((t2) => t2.name !== "move_note" && t2.name !== "delete_file"),
      search: (q, limit) => this.hybridSearch(q, limit),
      approve: async () => "approve",
      getConfig: () => ({ ...this.agentConfig(), autoApprove: true, autoContinue: true, citations: "off" }),
      configDir: this.app.vault.configDir,
      readConventions: async () => {
        const path = this.vault.resolve(this.settings.conventionsNote);
        return path ? this.vault.read(path) : null;
      }
    });
    const s = this.settings;
    const prompt = processDailyNotesPrompt({ folder: this.dailyFolder, heading: s.dailyInboxHeading, destination: s.dailyTopicsFolder, move: s.dailyMoveItems, since });
    this.agentBusy = true;
    try {
      await agent.run({ id: "scheduled", messages: [], approveAll: true }, prompt, {});
    } finally {
      this.agentBusy = false;
    }
    return overlay.changes();
  }
  async runDigestJob() {
    const now = /* @__PURE__ */ new Date();
    const weekOf = localDate(now);
    const path = digestPath(this.settings.digestFolder, weekOf);
    const notes = recentNotes(this.vault.listNotes(), now, 7).filter((n) => !n.path.startsWith(this.settings.digestFolder.replace(/\/+$/, "") + "/"));
    if (notes.length === 0) return [];
    const texts = [];
    let budget = 4e4;
    for (const n of notes.slice(0, 40)) {
      if (budget <= 500) break;
      const text = (await this.vault.read(n.path)).slice(0, Math.min(4e3, budget));
      budget -= text.length;
      texts.push({ path: n.path, text });
    }
    const res = await this.client.chat({
      model: this.settings.model,
      messages: [{ role: "user", content: digestPrompt(weekOf, texts) }],
      think: false,
      options: { num_ctx: this.settings.numCtx, temperature: 0.4 },
      keep_alive: this.settings.keepAlive
    });
    const content = renderDigest(weekOf, res.message.content, notes);
    if (this.vault.exists(path)) return [{ path, tool: "edit_note", before: await this.vault.read(path), after: content }];
    return [{ path, tool: "create_note", before: "", after: content }];
  }
  /** A notice (once per batch, when the user is at the keyboard) and the status-bar badge for waiting changes. */
  notifyPending(force = false) {
    this.updateStatusBar();
    const n = this.pending.size;
    if (n === 0) return;
    const present = Date.now() - this.lastActivity < 2 * 6e4;
    if (!force && (!present || this.pendingNotified === n)) return;
    this.pendingNotified = n;
    const frag = createFragment();
    frag.createSpan({ text: `Local Vault Agent: ${n} change${n === 1 ? "" : "s"} from scheduled jobs wait for your review. ` });
    const btn = frag.createEl("button", { text: "Review now" });
    btn.addEventListener("click", () => void this.reviewPending());
    new import_obsidian9.Notice(frag, 15e3);
  }
  updateStatusBar() {
    if (!this.statusBar) return;
    const n = this.pending.size;
    this.statusBar.setText(n ? `\u{1F916} ${n} to review` : "");
    this.statusBar.toggle(n > 0);
    this.statusBar.setAttribute("aria-label", n ? `${n} change${n === 1 ? "" : "s"} from scheduled jobs: click to review` : "");
  }
  /** Walks the queued changes as diffs: approve writes, reject drops, a change that no longer fits is dropped with a notice. */
  async reviewPending() {
    if (this.pending.size === 0) {
      new import_obsidian9.Notice(ui("No scheduled changes waiting.", "\uAC80\uD1A0 \uB300\uAE30 \uC911\uC778 \uC608\uC57D \uBCC0\uACBD\uC774 \uC5C6\uC2B5\uB2C8\uB2E4."));
      return;
    }
    let approveAll = false;
    let applied = 0;
    for (const item of [...this.pending.list()]) {
      const plan = await planPending(item, this.vault);
      if (!plan.ok) {
        new import_obsidian9.Notice(`Skipped: ${plan.reason}`, 8e3);
        this.pending.remove(item.id);
        continue;
      }
      if (!approveAll) {
        const modal = new ApprovalModal(this.app, { tool: item.tool, path: item.path, before: plan.before, after: plan.after, summary: `${item.summary} (${new Date(item.time).toLocaleString()})` });
        modal.open();
        const decision = await modal.result;
        if (decision === "reject") {
          this.pending.remove(item.id);
          continue;
        }
        if (decision === "approve-all") approveAll = true;
      }
      try {
        if (item.tool === "create_note") {
          const folder = item.path.includes("/") ? item.path.slice(0, item.path.lastIndexOf("/")) : "";
          if (folder && !this.app.vault.getFolderByPath(folder)) await this.app.vault.createFolder(folder);
          await this.vault.create(item.path, plan.after);
        } else await this.vault.modify(item.path, plan.after);
        this.undo.push({ tool: item.tool, path: item.path, before: plan.before, after: plan.after, time: Date.now(), turn: item.time, chat: "scheduled", summary: item.summary });
        applied++;
      } catch (err) {
        new import_obsidian9.Notice(`Could not write ${item.path}: ${err.message}`, 8e3);
      }
      this.pending.remove(item.id);
    }
    if (applied) new import_obsidian9.Notice(`Applied ${applied} scheduled change${applied === 1 ? "" : "s"}.`);
  }
  /** One page of a PDF as a PNG, for the vision model (scanned pages have no text layer). */
  async renderPdfPage(path, pageNumber) {
    const file = this.app.vault.getFileByPath((0, import_obsidian9.normalizePath)(path));
    if (!file) throw new Error(`File not found: ${path}`);
    const pdfjs = await (0, import_obsidian9.loadPdfJs)();
    const doc = await pdfjs.getDocument({ data: await this.app.vault.readBinary(file) }).promise;
    if (pageNumber > doc.numPages) throw new Error(`${path} has ${doc.numPages} pages.`);
    const page = await doc.getPage(pageNumber);
    const viewport = page.getViewport({ scale: 2 });
    const canvas = createEl("canvas");
    canvas.width = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Cannot render the PDF page here.");
    await page.render({ canvasContext: ctx, viewport }).promise;
    const blob = await new Promise((res) => canvas.toBlob(res, "image/png"));
    if (!blob) throw new Error("Cannot render the PDF page here.");
    return blob.arrayBuffer();
  }
  /** Subscribe to gist generation status. Returns an unsubscribe function. */
  onGistStatus(listener) {
    this.gistListeners.add(listener);
    return () => this.gistListeners.delete(listener);
  }
  /** Subscribe to index status changes. Returns an unsubscribe function. */
  onIndexStatus(listener) {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }
  agentConfig() {
    const s = this.settings;
    return {
      model: s.model,
      numCtx: s.numCtx,
      temperature: s.temperature,
      sampling: SAMPLING,
      think: s.thinking === "auto" ? void 0 : s.thinking === "on",
      keepAlive: s.keepAlive,
      maxIterations: s.maxIterations,
      maxToolResultChars: s.maxToolResultChars,
      autoApprove: s.autoApproveEdits,
      autoContinue: s.autoContinue,
      extraSystemPrompt: s.extraSystemPrompt,
      citations: s.citations,
      answerLanguage: s.answerLanguage
    };
  }
  async hybridSearch(query, limit) {
    const notes = this.vault.listNotes();
    const textOf = (n) => {
      const body = this.index.textFor(n.path, n.mtime);
      if (body === void 0) return void 0;
      const head = frontmatterText(this.app.metadataCache.getCache(n.path)?.frontmatter);
      return head ? `${head}
${body}` : body;
    };
    const keyword = await keywordSearch(this.vault, query, limit * 2, notes, notes.length > 2e3 ? textOf : void 0);
    if (!this.index.ready) return keyword.slice(0, limit);
    try {
      const semantic = await this.index.search(query, limit * 2);
      return fuseRankings([semantic, keyword], limit);
    } catch {
      return keyword.slice(0, limit);
    }
  }
  async activateView() {
    const { workspace } = this.app;
    let leaf = workspace.getLeavesOfType(VIEW_TYPE)[0] ?? null;
    if (!leaf) {
      leaf = workspace.getRightLeaf(false);
      if (!leaf) return null;
      await leaf.setViewState({ type: VIEW_TYPE, active: true });
    }
    await workspace.revealLeaf(leaf);
    return leaf.view instanceof AgentView ? leaf.view : null;
  }
  async loadSettings() {
    const data = await this.loadData();
    this.settings = migrateSettings(data);
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
};
